---
name: Khaem
aliases: []
source_extracts: [30]
---

# Khaem

## Identity
- No role, title, or faction affiliation established
- Known only as the namesake of the Lost Tomb of Khaem; has not appeared as a living NPC

## Personality & Motivations
- Insufficient information to establish.

## History with the Party
- The party has referenced the Lost Tomb of Khaem as a planned destination, intending to secure a weapon there before proceeding to the Neverlight Grove. Khaem has not been encountered directly.

## Current Status
- Presumably deceased; associated with a tomb
- The party has not yet visited the location
- What remains hidden: identity, history, nature of the weapon, and contents of the tomb are entirely unknown

## Relationships
- No relationships established

## Arc Score Events
- None recorded
