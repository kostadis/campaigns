---
name: Fuurm Coppernose (Copper)
aliases: []
source_extracts: [31]
---

# Fuurm Coppernose ("Copper")

## Identity
- **Role:** Civilian survivor / rescued captive; no adventuring background — a farmer by trade
- **Faction:** None
- **First Appearance:** Day 9, 1st Tenday of Myrkhul — discovered by the party in a Faerzress crystal cave in the Underdark

## Personality & Motivations
- **Core Drive:** Finding his missing sister, whose disappearance led him into the Underdark and ultimately into Drow captivity
- Defensive and frightened on first contact, but not without resolve — he armed himself with a crystal shard and challenged the party rather than cowering
- Visibly shaken but responsive to kindness; his mood lifted noticeably after being fed and in the company of others

## History with the Party
- **Day 9, 1st Tenday of Myrkhul:** Party encountered Fuurm alone in a Faerzress crystal cave, malnourished and dressed in rags, wielding a crystal as a weapon. He explained he had followed his sister into the Underdark and was captured by the Drow. Daz, impressed he survived at all, invited him to join the group. He was later seen talking nervously with Baedora, spirits somewhat recovered after being given food.

## Current Status
- **Last Known Location:** With the party, following rescue from the crystal cave
- **Active Concerns:** His sister remains missing somewhere in the Underdark
- **What the Party Knows:** He is a non-combatant farmer with no adventuring skills who survived Drow captivity while searching for his sister
- **What Remains Hidden:** The fate or whereabouts of his sister; any details about how he actually survived captivity

## Relationships
- **Daz:** Invited Fuurm to join the group; expressed genuine astonishment at his survival — likely a point of connection
- **Baedora:** Shared nervous conversation after the rescue; early rapport forming
- **His Sister (unnamed):** The sole reason he entered the Underdark; still missing

## Arc Score Events
*No arc score events recorded.*
