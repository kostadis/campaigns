---
name: Topsy and Turvy
aliases: []
source_extracts: [17]
---

# Topsy and Turvy

## Identity
- Role: Escaped slaves, fellow refugees sheltering at Ghohlbrorn's Lair
- Faction: None known
- First appearance: Encountered at Ghohlbrorn's Lair alongside other escapees

## Personality & Motivations
- No personality traits recorded in session notes.

## History with the Party
- Present at Ghohlbrorn's Lair as part of a group of escapees. They stand out because, unlike the other escaped slaves, they have not gone missing.

## Current Status
- Last known location: Ghohlbrorn's Lair
- No active plans recorded
- **What the party knows:** They are notable for being the only escapees who haven't disappeared.
- **What remains hidden:** Daz suspects they are wererats, which may explain why the others have gone missing (and Topsy and Turvy have not).

## Relationships
- **The party:** Fellow escapees; presence noted but relationship depth not recorded
- **Missing escapees:** Their fate is connected — Daz suspects Topsy and Turvy's wererat nature may be responsible for the disappearances

## Arc Score Events
- None recorded.
