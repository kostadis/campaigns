---
name: Gorg'Bahamut (Grog'Bahamut)
aliases: []
source_extracts: [12]
---

# Gorg'Bahamut

## Identity
- Role: Mentor and spiritual teacher; implied connection to Bahamut's faith or traditions
- Faction: Unknown — likely aligned with Bahamut in some capacity
- First appearance: Referenced only in Grygum's memories; has not appeared in person

## Personality & Motivations
- Appears to be a teacher and lore-keeper, passing down knowledge of both divine and demonic forces to his students.
- Instilled in Grygum an understanding of Demogorgon as the antithesis of Bahamut, suggesting a worldview grounded in cosmic opposition between order/good and chaos/evil.

## History with the Party
- **Pre-campaign (Grygum's backstory):** Gorg'Bahamut served as Grygum's mentor. He taught Grygum detailed lore about Demogorgon — his twin heads (one whispering lies, one roaring with fury), his chaos-venom tentacles, and his nature as the inverse of Bahamut. He also imparted the belief that "a hoard is always a valuable thing and a blessing from Bahamut."

## Current Status
- **Last known location:** Unknown; has not appeared in play
- **Active plans:** None known
- **What the party knows:** Exists as a figure from Grygum's past. His teachings have shaped Grygum's knowledge and values.
- **What remains hidden:** His current whereabouts, whether he is alive, and the full extent of his relationship with Grygum.

## Relationships
- **Grygum:** Mentor. Shaped Grygum's theological worldview and knowledge of demonic lore.
- **Bahamut (deity):** Appears to revere or serve Bahamut in some capacity, based on his name and teachings.

## Arc Score Events
- No arc score events recorded.
