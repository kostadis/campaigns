---
name: Tarvis Ulain
aliases: []
source_extracts: [56]
---

# Tarvis Ulain

## Identity
- Paladin of Bahamut; affiliated with the Order of the Gauntlet (witnessed and recorded by Milo Goodbarrel)
- **Deceased** — died in Daggerford three years prior to current campaign events
- First encountered indirectly: the party discovered his monument in Daggerford's market square upon arrival

## Personality & Motivations
- No direct interactions; character known only through monument and testimonial inscriptions
- Died breaking up a Cult of the Dragon recruitment operation within Daggerford itself, suggesting proactive, frontline commitment to his faith
- Monument framing places him among many across the North who died in a war that touched even towns that escaped other threats (e.g., Uthgardt hordes)

## History with the Party
- **Session [arrival in Daggerford]:** Party encountered Tarvis's monument — a bronze-cast severed forearm on a stone pillar — as their first landmark in town. They examined three inscriptions:
  - **Primary (Common):** Identifies him as a paladin of Bahamut killed breaking a Cult of the Dragon recruitment operation; monument funded by the Metalworkers Guild two years after the war
  - **Secondary (Dwarven):** *The move is yours* — party identified this as Stroudite language; the village priest confirmed it was a gift whose original inscription was retained
  - **Tertiary (back, Common):** "Witnessed and recorded for the Gauntlet," signed by **Milo Goodbarrel**
- Grygum purchased a pewter miniature reproduction of Tarvis's hand, sold by the village priest as charitable fundraising for the Order of the Gauntlet

## Current Status
- **Dead.** Monument stands in Daggerford's market square.
- No active plans or operations.
- **What the party knows:** Cause of death, faction affiliation, Stroudite connection via monument inscription, link to Milo Goodbarrel and the Order of the Gauntlet
- **What remains hidden:** Details of the Cult recruitment operation he broke up; nature of his Stroudite connection; circumstances of the gift that carried the inscription

## Relationships
- **Milo Goodbarrel:** Witnessed and formally recorded Tarvis's death for the Order of the Gauntlet; suggests a direct working relationship
- **Order of the Gauntlet:** Affiliated faction; the village priest fundraises in his name for the Order
- **Metalworkers Guild (Daggerford):** Funded the monument two years after the war
- **Stroudites:** Connected via the Dwarven inscription — origin and nature of this relationship unknown
- **Grygum (party):** Purchased the pewter hand memorial; personal connection established

## Arc Score Events
- N/A — NPC is deceased and has not directly interacted with the party
