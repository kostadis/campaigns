---
name: Daz
aliases: []
source_extracts: [7, 40]
---

# Daz

## Identity
- Role: Party member (wizard); no formal faction affiliation noted
- First appearance: Present during the spider retreat (exact session not specified); part of the core group throughout the Underdark arc

## Personality & Motivations
- Core goal: Escaping the Underdark; willing to accept accountability and take decisive action to move things forward
- Pragmatic and results-driven to the point of impatience with bureaucracy and political maneuvering
- Capable of ruthless thinking (viewing goblin guides as potential "fodder") but channels this into functional leadership rather than cruelty
- Takes on personal accountability as a negotiating tool—an unusual and striking quality that disarms counterparts

## History with the Party
- **Spider Retreat:** Used magic missiles during the fighting withdrawal.
- **Spectator Fight:** Delivered the killing blow with magic missiles described as "glowing teardrops of blue-white force."
- **Silken Paths:** Muttered that the goblin guides "might prove useful as fodder in a battle"—overheard by Buppido.
- **Blingdenstone Political Crisis:** Grew frustrated with bureaucratic debate and took decisive control of proceedings. Pushed through a direct plan targeting the Pudding King; secured support from Chief Dorbo and Senni. Plan involved the Gold Whisker clan as a distraction while the party handled the Pudding King directly.
- **Meeting with Chief Chipgrin:** Clarified the party's purpose plainly and refused to enable political maneuvering. Accepted personal vengeance as the consequence if the plan led to casualties—a move that visibly surprised Chipgrin.
- **Grand Moot:** Led the meeting at Senni's request. Presented the covert-extraction plan and exposed the gnome leaders' attempt to exploit the party for side quests. The leaders backed down; the party chose to pursue some quests voluntarily anyway.

## Current Status
- **Last known location:** Blingdenstone, following the grand moot
- **Active plans:** Coordinating the assault on the Pudding King—gnome army creates a distraction at the ooze amphitheater while the party covertly extracts the Pudding King using magic
- **What the party knows:** Full plan as presented at the moot
- **What remains hidden:** His casual remark about goblin fodder is known to Buppido but may not have been shared with the rest of the party

## Relationships
- **Chief Dorbo & Senni:** Earned their respect and cooperation; they agreed to support his plan
- **Chief Chipgrin:** Tense but functional working relationship; Chipgrin is impressed and unsettled; has been given explicit license to seek vengeance against Daz personally if the plan fails
- **Buppido:** Buppido overheard Daz's comment about the goblin guides—nature of that relationship and whether Buppido will use this information is unresolved
- **Goblin guides:** Viewed instrumentally; Daz has privately considered them expendable

## Arc Score Events
- No arc score changes recorded in source notes.
