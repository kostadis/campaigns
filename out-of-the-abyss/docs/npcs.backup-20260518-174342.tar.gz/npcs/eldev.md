---
name: Eldev
aliases: []
source_extracts: [40]
---

# Eldev

## Identity
- Role/affiliation unknown from available notes; assigned to work alongside Glabbagool and Jimjar
- First appearance: assigned as part of a splinter group tasked with assisting the Barrow Warden ghosts

## Personality & Motivations
- Insufficient information in source notes to characterize personality or motivations.

## History with the Party
- Was assigned alongside Glabbagool and Jimjar to assist the Barrow Warden ghosts with their quest, while the main party handled the Rock Blight and Neverlight Grove tasks. No further interaction details recorded.

## Current Status
- Last known status: working with Glabbagool and Jimjar on the Barrow Warden ghost quest
- Active involvement: assisting the Barrow Warden ghosts (nature and progress of quest not detailed in notes)
- What the party knows: Eldev was assigned this task; no further details recorded
- What remains hidden: nearly everything — background, capabilities, current situation, and quest outcome are undocumented

## Relationships
- **Glabbagool & Jimjar:** Assigned companions on the Barrow Warden task
- **Barrow Warden Ghosts:** The group Eldev is tasked with assisting
- **Main Party:** Separated from them during split-task session; no individual relationships noted

## Arc Score Events
- No arc score events recorded in source notes.
