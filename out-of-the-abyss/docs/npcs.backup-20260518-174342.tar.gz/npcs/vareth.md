---
name: Vareth
aliases: []
source_extracts: [56]
---

# Vareth

## Identity
- Role: Candlekeep handler assigned to Grygum by the First Reader
- Faction: Candlekeep
- First appearance: Named in session notes; has not appeared directly at the table yet

## Personality & Motivations
- Insufficient information to characterize at this time

## History with the Party
- Has not directly interacted with the party yet
- Grygum intends to bring Vareth a theological puzzle related to Tarvis Ulain's monument

## Current Status
- Last known location: Presumably Candlekeep
- Grygum is flagging the open questions surrounding Tarvis Ulain's monument as material to share with Vareth

## Relationships
- **Grygum:** Assigned handler; Grygum views Vareth as a resource for theological inquiry
- **First Reader:** Superior who made the handler assignment

## Arc Score Events
- None recorded

---
*Note to GM: Vareth has not appeared in play. All information is secondhand. Consider establishing their personality and availability before Grygum seeks them out.*
