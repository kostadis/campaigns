---
name: Hepbobe (also referred to as Hepbode)
aliases: []
source_extracts: [33]
---

# Hepbobe (also recorded as Hepbode)

## Identity
- **Role:** Leader of the Circle of Growers; responsible for food production for the Myconid colony
- **Faction:** Aligned with Phylo's new organizational structure; not allied with Basidia
- **First Appearance:** The party met Hepbobe during a tour of the colony's irrigation tunnels and growing areas

## Personality & Motivations
- **Core Goals:** Feed the colony efficiently; support Phylo's vision of specialized circles over communal meld governance
- Pragmatic and pro-progress; believes the old communal meld was unfocused and wasteful
- Patient and informative when answering questions, even awkward ones (e.g., Grygum's question about mushrooms eating mushrooms)
- Dismissive of Basidia's concerns, framing them as alarmist rather than legitimate

## History with the Party
- Gave the party a tour of irrigation tunnels and various cultivated fungi
- Explained Myconid biology and diet to Grygum — sentient fungus, herbivores, individual food preferences and cooking styles
- Defended Phylo's circle system as a genuine improvement over the old communal meld
- Downplayed Basidia's warnings about Phylo's leadership

## Current Status
- **Last Known Location:** Circle of Growers' growing areas within the colony
- **Active Operations:** Managing food supply for the colony under Phylo's structure
- **Party Knowledge:** The party (via Zalthir confirming with Basidia) has verified that Hepbobe's food supply is **not contaminated with evil spores**
- **Hidden:** Whether Hepbobe is knowingly complicit in anything Phylo is doing, or simply a true believer, remains unknown

## Relationships
- **Phylo:** Friend and ideological ally; supports Phylo's restructuring of the colony
- **Basidia:** Dismissive; views Basidia's concerns as exaggerated
- **The Party:** Cooperative and informative; no apparent hostility

## Arc Score Events
- No arc score changes recorded
