---
name: Ebonmire (Princess Ebonmire)
aliases: []
source_extracts: [55]
---

# Princess Ebonmire

## Identity
- Role/Title: Princess (title and faction affiliation unknown from available notes)
- First Appearance: Not recorded in available session notes

## Personality & Motivations
- Insufficient data from available notes to characterize personality or motivations.

## History with the Party
- The party came into possession of Ebonmire's spellbook at some point prior to the recorded notes.
- Her spellbook was among five books the party donated to Candlekeep.

## Current Status
- **Last known location:** Not present in available notes; does not appear in person.
- **Active plans:** Unknown.
- **Party knowledge:** The party held her spellbook. What they know of Ebonmire herself is not recorded in available notes.

## Relationships
- Insufficient data from available notes.

## Arc Score Events
- No arc score events recorded in available notes.

---
*⚠️ Note to GM: Available session notes on this NPC are minimal. Dossier will expand as more source material is provided.*
