---
name: Topsy and Turvy
aliases: []
---

# Topsy and Turvy

## Identity
- Deep gnome twins; fellow escapees from captivity
- Part of the group that escaped alongside the party

## Personality & Motivations
- Keep to themselves. Little is known about their personal goals or drives beyond survival.

## History with the Party
- Escaped captivity along with the party and other NPCs.
- Remained at Ghohlbrorn's Lair while other escapees have gone missing one by one.
- They are the only other escapees besides the party still present at the Lair.

## Current Status
- **Location:** Ghohlbrorn's Lair
- **Activity:** Still present and accounted for, unlike the other missing escapees
- **Hidden information:** Daz suspects Topsy and Turvy are **wererats**, and that this is the reason they haven't disappeared like the others.

## Relationships
- **Daz (party member):** Views them with suspicion; believes they are wererats.
- **Other escapees:** The rest have vanished from the Lair — Topsy and Turvy's continued presence is conspicuous.

## Arc Score Events
None recorded.
