---
name: Brannam
aliases: []
---

# Brannam

## Identity
- Duergar delivery courier
- First appeared on the evening of the 10th of Myrtul, arriving at the party's location to deliver magical weapons and items ordered by Thorin and Zalthir

## Personality & Motivations
- No personality details observed; appeared only in a brief transactional role.

## History with the Party
- **10th of Myrtul (evening):** Arrived at the party's location and delivered the magical weapons and items that Thorin and Zalthir had previously requested.

## Current Status
- Last seen completing his delivery on the 10th of Myrtul
- No known ongoing involvement with the party
- Nothing hidden or unresolved is indicated in the notes

## Relationships
- **Thorin:** One of the two who ordered the magical items Brannam delivered
- **Zalthir:** The other party member who placed the order
