---
name: Shuushar the Awakened
aliases: []
---

# Shuushar the Awakened

## Identity
- Kuo-Toa, fellow prisoner at Velkynvelve
- Claims to have "found enlightenment" and discovered a way to resist the madness common to his people
- First encountered as one of the captives in the drow prison at Velkynvelve

## Personality & Motivations
- Speaks in a soothing manner; projects calm and serenity. His core claim is that he has transcended the inherent madness of the Kuo-Toa. He seeks to return to his home settlement of Sloobludop near the Darklake, and has offered his knowledge of the Underdark's winding roads as value to the party.

## History with the Party
- **Velkynvelve:** Met as a fellow prisoner. Offered to guide the group to Sloobludop, citing his familiarity with Underdark routes. Daz expressed cautious interest but remained uncertain about trusting a Kuo-Toa.

## Current Status
- **Last known location:** Prisoner at Velkynvelve
- **Active plans:** Wants to travel to Sloobludop near the Darklake; has offered to serve as the party's guide
- **Known vs. hidden:** The party knows his stated goal (return to Sloobludop) and his claim of enlightenment. Whether his enlightenment is genuine or his guidance trustworthy remains unverified.

## Relationships
- **Daz:** Cautiously interested in Shuushar's offer but not yet fully trusting.
- **Other Velkynvelve prisoners:** Fellow captive; no specific alliances or tensions noted.
- **Sloobludop Kuo-Toa:** Claims it as his home settlement; nature of his standing there is unknown.

## Arc Score Events
None recorded yet.
