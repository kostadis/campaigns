---
name: Ilvara Mizzrym
aliases: []
---

# Ilvara Mizzrym

## Identity
- High Priestess of House Mizzrym, corrupted vessel of the demon lord Zuggtmoy
- Primary antagonist of the battle in the fungal cavern at the center of Velkynvelve's fungal infestation
- By the time of the confrontation, she was no longer a person aided by Zuggtmoy but rather Zuggtmoy's work "walking around in a drow priestess's bones"

## Personality & Motivations
Ilvara was a true believer — not a reluctant servant but someone who had fully accepted Zuggtmoy's vision of "the bride" and "the chaos and mayhem to come." She delivered prophecy mid-combat not as threats or intimidation but as sincere expressions of faith. She fought with tactical intelligence and focused fury even while gravely wounded, never begging or offering surrender. Whatever drow ambition she once possessed had been subsumed entirely by demonic purpose.

## History with the Party
**The Fungal Cavern Battle (Final Encounter):**
- Stationed in the cavern above the heart fungus at the center of Velkynvelve's infestation.
- Zalthir opened the fight by grappling her with his Eldritch Claw Tattoo, dragging her forty feet into the air, landing two critical hits (sixteen-plus damage), and dropping her to the stone floor.
- Despite the punishment, she used a legendary reaction to frighten Zalthir (DC-14 Wisdom save, failed), completely neutralizing his close-range combat for a full round.
- Cast Insect Plague at the cavern entrance, killing her own fungal minions (thirteen HP each) and dealing twenty-six damage to Glabbagool.
- Called down divine fire on Daz and Nym Duskryn; conjured fungal growth to reshape the battlefield.
- When Thorin destroyed the bridge beneath her, she leapt clear and survived the fall.
- Jorlan Duskryn charged her through the insect swarm, screaming her name — their broken romantic history driving his fury. They traded blows on the cavern floor.
- Killed by Grygum's Guiding Bolt. Her body erupted in a massive cloud of poisonous spores, catching Zalthir and Thorin in the blast. She was still muttering prophecy when she died.

## Current Status
- **Dead.** Her body dissolved into a cloud of poisonous spores upon death — nothing of her remained.
- Her death confirmed the totality of Zuggtmoy's corruption: she was fully consumed, not merely influenced.
- The broader threat she prophesied — Zuggtmoy, "the bride," and the coming chaos — remains unresolved.

## Relationships
- **Jorlan Duskryn:** Former romantic partner. She discarded him after his scarring, per drow society's values. He charged her in a rage during the final battle, screaming her name. Their relationship fueled his attack.
- **Nym Duskryn:** Targeted with divine fire during the battle (relationship to Jorlan likely relevant).
- **Zuggtmoy:** Ilvara was the demon lord's vessel — no longer a willing servant but a fully subsumed instrument.
- **Zalthir:** Opened the fight against her; she specifically countered him with the Frightened condition, neutralizing his monk combat style.
- **Grygum:** Landed the killing blow with Guiding Bolt; was fortunately standing back when the spore cloud erupted.
- **Thorin:** Destroyed the bridge beneath her; was caught in her death spore explosion.
- **Daz:** Targeted by her divine fire during the battle.
- **Glabbagool:** Took heavy damage (twenty-six HP) from her Insect Plague.
