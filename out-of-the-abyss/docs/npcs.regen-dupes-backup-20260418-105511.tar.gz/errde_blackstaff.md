---
name: Errde Blackstaff
aliases: []
---

# Errde Blackstaff

## Identity
- Faction leader in Gracklstugh (specific faction/title not specified)
- Has not appeared directly to the party; known through secondhand references and dealings via intermediaries (notably Daz)

## Personality & Motivations
- Core goal: Obtain evidence of Demogorgon's influence among the Derro, likely to justify action against them
- Pragmatic and ruthless — according to Daz, "if she doesn't get evidence, she'll invent it," indicating a predetermined agenda and willingness to fabricate justification to achieve her ends

## History with the Party
- **Pre-contact:** Was one of the Gracklstugh faction leaders anxious to recruit non-Duergar outsiders to venture into the Derro slums to find Droki. The Derro district is too dangerous for Duergar — sending them in would trigger a bloodbath.
- **Indirect contact via Daz:** Daz relayed that the books and papers recovered from Narrak's ritual cavern would likely serve as sufficient evidence of Demogorgon's influence to satisfy Errde Blackstaff's demands.

## Current Status
- **Last known location:** Gracklstugh (exact location unspecified)
- **Active plans:** Seeking evidence of demonic corruption among the Derro; intends to act on this evidence (or manufacture it if none is provided)
- **Party knowledge:** The party knows she wants evidence and that she is willing to fabricate it. They have materials from Narrak's cavern that could satisfy her. They have not yet met her directly.

## Relationships
- **Daz:** Serves as an intermediary between Errde Blackstaff and the party; familiar enough with her methods to comment on her willingness to fabricate evidence
- **The Derro:** Clearly adversarial; she views them as a threat or target, and the evidence-gathering effort suggests she is building a case for action against them
- **The Party:** Has not met them directly but recruited them (through faction channels) as useful outsiders who can operate in areas Duergar cannot

## Arc Score Events
None explicitly noted.
