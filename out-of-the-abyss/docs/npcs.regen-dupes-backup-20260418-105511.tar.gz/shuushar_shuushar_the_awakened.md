---
name: Shuushar (Shuushar the Awakened)
aliases: []
---

# Shuushar the Awakened

## Identity
- Kuo-toan pacifist and self-styled philosopher
- Fellow prisoner / traveling companion of the party
- First appeared as part of the group escaping the Underdark; already established with the party by these sessions

## Personality & Motivations
- Deeply committed to nonviolence and open-mindedness, to the point of frustrating his companions. Reacts with dismay to unnecessary conflict and advocates dialogue over combat. Has a tendency to lecture and drone on about philosophy before mercifully wandering off. Considered a troublemaker and "visionary" by his own people, suggesting his pacifist worldview is abnormal among kuo-toans.

## History with the Party
- **Ambush at the Kuo-Toan Party:** Explained the tactical role of a kuo-toan monitor to the group (a leader who manages outbreaks of insanity; defeating one demoralizes the rest). After the battle, lamented it as unnecessary.
- **Approach to Sloobludop:** Affirmed the group should continue toward Sloobludop. About an hour out, he excitedly encountered another kuo-toan party and introduced the group to **Ploopploopeen**, archpriest of the Sea Mother.
- **Meeting with Ploopploopeen:** Followed Ploopploopeen in her surreal school-of-fish formation, wandering loosely rather than staying at her side. Ploopploopeen cast a pointed glance at him when mentioning troublesome "visionaries," suggesting a strained relationship.
- **Debate Over Killing Ploopploopeen's Party:** Passionately argued against violence, insisting the Sea Mother is an old god and does not demand humanoid sacrifices—that is the **Deep Father's** domain. Urged the party to speak with Ploopploopeen's daughter **Bloppblippodd** before making judgments.

## Current Status
- **Last Known Location:** With the party, near or at Sloobludop.
- **Current Activity:** Advocating for diplomacy with Ploopploopeen's faction and the Sea Mother worshippers.
- **Party Knowledge:** The party knows he is considered an oddity among kuo-toans and that he distinguishes between the Sea Mother (benign) and the Deep Father (demands sacrifices). No hidden information indicated beyond Ploopploopeen's apparent wariness of him.

## Relationships
- **Ploopploopeen** – Knows her and facilitated introductions, but she views him with suspicion as a disruptive "visionary."
- **Bloppblippodd** – Knows of her; recommended the party speak with her, implying some familiarity or respect.
- **The Party** – Serves as cultural guide and mediator regarding kuo-toan affairs; his pacifism and long-windedness test their patience.
- **Sethir (PC)** – Responded to Sethir's prompt about whether to continue, suggesting a functional rapport.

## Arc Score Events
- No explicit arc score changes noted in the source material.
