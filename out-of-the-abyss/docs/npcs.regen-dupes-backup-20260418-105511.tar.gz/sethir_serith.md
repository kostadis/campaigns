---
name: Sethir (Serith)
aliases: []
---

# Sethir (Serith)

## Identity
- Guide / navigator for the party
- Knowledgeable about the Underdark, particularly the Darklake region
- First appeared during the party's journey from Velkynvelve, helping plan the route forward

## Personality & Motivations
- Core goal: Lead the group to the tomb of Brysis of Khaem
- Practically minded and cooperative — willing to draw maps, share knowledge, and collaborate on travel plans. Doesn't take well to having his competence questioned, as shown by his glare at Thorin over the map criticism.

## History with the Party
- Spoke with **Fargas** to learn the tomb of Brysis of Khaem's general location on the eastern edge of the Darklake.
- Drew a map for the group using **Ormu** (ink/material collected by **Zalthir**), charting the route from **Velkynvelve** through the **Silken Paths** toward **Sloobludop**, also marking the **Darklake**, **Gracklstugh**, and the tomb's approximate location.
- Explained that the Darklake is not a conventional body of water but a "large water balloon" of intersecting caverns, caves, and tunnels.
- Agreed with **Buppido's** suggestion to visit **Gracklstugh** after Sloobludop, noting it as a large Derro city where they could acquire weapons and gear, and that the tomb lies along the way.
- Estimated three days' travel to Sloobludop.
- Glared at **Thorin** when the dwarf criticized his map's accuracy.

## Current Status
- **Last known location:** Traveling with the party, en route to Sloobludop (estimated three days out)
- **Active plans:** Guiding the group along the route: Sloobludop → Gracklstugh → Tomb of Brysis of Khaem
- **Hidden information:** None indicated in available notes

## Relationships
- **Fargas** — Source of information about the tomb's location; consulted him before mapping the route
- **Zalthir** — Provided Ormu (material) that Sethir used to draw the map
- **Buppido** — Collaborative relationship; Sethir endorsed Buppido's suggestion to visit Gracklstugh
- **Thorin** — Minor tension; Sethir visibly bristled at Thorin's criticism of his cartography
