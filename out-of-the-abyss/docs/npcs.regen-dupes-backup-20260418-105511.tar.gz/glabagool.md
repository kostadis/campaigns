---
name: Glabagool
aliases: []
---

# Glabagool

## Identity
- Sentient gelatinous cube; companion to the party
- First encountered prior to arriving at Blingdenstone (details of initial meeting not in these notes); formally introduced to Blingdenstone's deep gnome guards at the city gate

## Personality & Motivations
- Curious and communicative — speaks aloud, which is extraordinary for an ooze. Glabagool is aware of its own unusual nature and can reflect on how it gained sentience. It seems motivated by a desire to understand itself and the world around it, and it has demonstrated loyalty to the party by traveling with them.

## History with the Party
- **Arrival at Blingdenstone:** The party brought Glabagool to the city gate, where guards panicked and prepared to attack. The party intervened, vouching for Glabagool as a friendly companion who had helped them on their journey. Glabagool spoke aloud, astonishing the guards, and explained that it gained the ability to think and speak after an unknown event. It also reported observing an unusual increase in agitated oozes in the area, coining the term "oozapalooza." The guards were particularly alarmed given Blingdenstone's existing ooze problem and directed the party to seek full permissions from Chief Dorbo Diggermattock and Quartermaster Senni, especially regarding Glabagool's presence.

## Current Status
- **Last known location:** Gate of Blingdenstone, awaiting permission to enter the city.
- **Active concerns:** The party needs approval from Chief Dorbo Diggermattock and Quartermaster Senni before Glabagool can be granted access.
- **What the party knows:** Glabagool is sentient and verbal; it became so after an unknown event; there is a surge in agitated ooze activity in the region ("oozapalooza"); Blingdenstone already has a serious ooze problem.
- **What remains hidden:** The cause of Glabagool's sentience; the root cause of the regional ooze agitation.

## Relationships
- **The Party:** Trusted companion; the party actively advocates for Glabagool and considers it an ally.
- **Blingdenstone Guards:** Viewed with fear and suspicion; its presence is a source of tension given the city's ooze troubles.
- **Chief Dorbo Diggermattock & Quartermaster Senni:** Have not yet met Glabagool; their approval is required for it to enter the city.

## Arc Score Events
- No arc score events noted in source material.
