---
name: Sarith (also referred to as "Sathir" in the text)
aliases: []
---

# Sarith

## Identity
- Drow NPC, fellow escapee from Velkynvelve
- Serves as the group's primary Underdark guide and navigator
- First appearance context not detailed in these notes, but he is an established member of the escaped prisoner group

## Personality & Motivations
- Core goal: Survive the Underdark and stay ahead of the drow pursuit from Velkynvelve
- Pragmatic and survival-focused — immediately recognized a slain creature as a food source. Keeps the group oriented on practical needs: movement, water, covering tracks.
- Proud and somewhat prickly about his competence; visibly annoyed when Grygum spotted a route before he did, though he grudgingly acknowledged the help.
- Takes a natural leadership role regarding navigation and tactical decisions, issuing directives to other NPCs like Eldeth.

## History with the Party
- **Rockfall encounter:** Survived unscathed. Buppido shouted that Sarith was supposed to rescue him per "the divine plan."
- **Giant centipede fight:** Fought alongside the group using hand-held crossbow bolts; helped kill the creature. Immediately called out "Rations!" to harvest it for food.
- **Drow pursuit revelation:** Provided critical intelligence when the group realized drow scouts from Velkynvelve were following them. Explained how Underdark tunnels twist and change unpredictably, warned that non-flying surface dwellers ("Overbriters") are the easiest prey, and stressed the need to keep moving.
- **Faerzess cave navigation:** Was actively searching for the next tunnel route. Grygum found it first, which visibly irritated him, though he accepted the help and rushed down the discovered path.
- **End-of-day assessment:** Gave a cautiously optimistic report on their progress but raised the alarm about lack of water. Ordered Eldeth to cover their trail the following day. Revealed that Ilvara has found and caught up with them, urging the group to increase their lead or actively obscure their tracks.

## Current Status
- **Last known location:** Traveling through Underdark tunnels with the escaped group, one day out from the Faerzess cave
- **Active concerns:** No water supply; Ilvara and drow scouts closing in; ordered a slower pace with trail-covering the next day
- **Known to the party:** His Underdark expertise, his assessment of the drow threat, and his warning about Ilvara's proximity
- **Potentially hidden:** His deeper background, reasons for being a prisoner in Velkynvelve, and any personal agenda beyond survival remain unstated

## Relationships
- **Buppido:** Buppido considers Sarith part of his "divine plan" and expected rescue from him during the rockfall — the nature of this dynamic is unclear but notable.
- **Grygum:** Mild competitive friction; Sarith was annoyed when Grygum found the route first but accepted it.
- **Eldeth:** Sarith directs her tactically (ordered her to cover their trail), suggesting he exercises authority over at least some NPCs in the group.
- **Topsy & Turvy:** Fought alongside them during the centipede battle; no friction noted.
- **Ilvara / Velkynvelve drow:** Knowledgeable about their pursuit capabilities and tactics; clearly fears recapture.

## Arc Score Events
- No explicit arc score changes noted in these sessions.
