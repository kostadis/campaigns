---
name: Chief Dorbo
aliases: []
---

# Chief Dorbo

## Identity
- Leader of the mining coalition in Blingdenstone
- Based in Diggermattock Hall
- First encountered during a heated discussion with Senni about the settlement's future

## Personality & Motivations
- Primarily driven by mining operations and economic concerns for Blingdenstone. Territorial about his personal space (annoyed when Thorin intruded into his private kitchen). His obsession with money has been noted as excessive given the existential threats facing the settlement—Chipgrin suggested this is due to demonic corruption from the Pudding King amplifying greed and aggression in the community's leadership.

## History with the Party
1. **Diggermattock Hall (First Meeting):** Engaged in a heated argument with Senni. Explained that ooze infestations were blocking mining and housing construction. After Senni confronted him about his failure to address the ooze problem, he agreed the party would need to deal with the ooze threat before he could assist them with their concerns. Revealed suspicions that the Gold Whisker clan are wererats and refused to cooperate with them.
2. **Planning Meeting:** Agreed to support Daz's plan. Was annoyed when Thorin entered his private kitchen quarters, directing the party to eat at the Foaming Bug inn instead.
3. **Grand Moot:** Suggested using the Temple of the Steadfast Stone as a staging area to attack oozes, keeping them away from main population centers. Offered a **Stone of Controlling Earth Elementals** as reward for dealing with Ogremoch's Bane and cleansing the temple.
4. **Elemental Debate:** Present when the party argued against enslaving Earth Elementals for labor, comparing it to Drow slavery. Witnessed religious leaders side with the party's position.

## Current Status
- **Last known location:** Diggermattock Hall, Blingdenstone
- **Active concerns:** Mining operations stalled by ooze infestations; waiting on the party to deal with Ogremoch's Bane and cleanse the temple
- **Hidden from party:** The extent to which demonic corruption may be influencing his judgment and leadership decisions

## Relationships
- **Senni:** Frequent disagreements; she confronts him on his failures and pushes back on his refusal to work with the Gold Whiskers
- **Gold Whisker Clan:** Refuses cooperation; suspects them of being wererats
- **Chipgrin:** Chipgrin theorizes Dorbo's greed is amplified by demonic corruption
- **Thorin:** Minor friction (kitchen intrusion incident)
- **The Party:** Transactional relationship; leveraging their need for help against the ooze threat

## Arc Score Events
- Chipgrin's observation that demonic corruption is amplifying Dorbo's greed and aggression suggests an ongoing negative influence arc tied to the Pudding King's presence.
