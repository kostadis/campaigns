---
name: Bloppblippodd
aliases: []
---

# Bloppblippodd

## Identity
- Archpriest of the Deep Father (Leemoogoogon) faction in Sloobludop
- Daughter of Ploopploopeen; sister of Glooglugogg
- Has not yet appeared in person

## Personality & Motivations
Bloppblippodd experienced a powerful vision of "Leemooggoogoon the Deep Father" several weeks ago and proclaimed him the new god of the kuo-toan people. She backs her claims with a tremendous increase in magical power, which has drawn followers and split Sloobludop into two factions. She has refused diplomatic overtures from her father, including a "white flag" attempt. Her brother Glooglugogg considers her mad and disrespectful of kuo-toan ways.

## History with the Party
- The party has not yet met or seen Bloppblippodd directly.
- She is the central target of Ploopploopeen's plan: the party is to be presented to her as sacrificial offerings in the morning, at which point they are expected to disrupt her rituals so the Sea Mother faction can launch an ambush.

## Current Status
- **Location:** Sloobludop, leading the Deep Father faction
- **Active operations:** Her followers are making increasing numbers of blood sacrifices—killing humanoid offerings and casting bloody chum into the Darklake, where something unknown consumes it.
- **Known to the party:** She is a rival archpriest, Ploopploopeen's daughter, and the target of the planned ambush. Her faction demands blood sacrifices.
- **Hidden from the party:** The true nature of Leemoogoogon and what exactly is consuming the sacrificial chum in the Darklake.

## Relationships
- **Ploopploopeen** (father) — Opposed factions; he plans to ambush her. He has attempted diplomacy and been rebuffed.
- **Glooglugogg** (brother) — Holds her in deep contempt; views her as mad and disrespectful of tradition. Also blames their father for being too deferential toward her.
- **The Party** — No direct contact yet. They are pawns in Ploopploopeen's plan against her.
- **Deep Father followers** — Hardcore supporters are few in number, but broader village allegiance is uncertain.

## Arc Score Events
None yet — no direct interaction has occurred.
