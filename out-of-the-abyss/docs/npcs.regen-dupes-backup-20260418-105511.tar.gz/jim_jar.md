---
name: Jim Jar
aliases: []
---

# Jim Jar

## Identity
- NPC companion traveling with the party
- No specific role, title, or faction affiliation noted

## Personality & Motivations
- Shows visible concern for the party's safety, as evidenced by his worried expression when asked to stay behind. Core goals and drives beyond companionship are not yet established.

## History with the Party
- Accompanied the party as one of several NPC companions.
- Was instructed by Daz to wait outside a final cavern entrance — one that reeked of brimstone and chemicals — along with other companions.
- Visibly worried when given the order to stay behind.

## Current Status
- **Last known location:** Waiting outside a cavern entrance that smells of brimstone and chemicals.
- **Activity:** Standing by with other NPC companions while the party ventures inside.
- **Hidden information:** None noted.

## Relationships
- **Daz:** Follows Daz's instructions; Daz directed him to stay behind.
- **The Party:** Traveling companion; appears to care about the party's well-being.
- **Other NPC companions:** Part of a group of companions asked to wait together outside the cavern.

## Arc Score Events
No arc score events noted.
