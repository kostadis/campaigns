---
name: Grunik Tapfinger
aliases: []
---

# Grunik Tapfinger

## Identity
- Cleric, associated with Diggermattock Hall
- First appeared as the quest-giver who sent the party to hallow Ogremoch's temple

## Personality & Motivations
- Supportive of efforts to cleanse or sanctify corrupted holy sites. Greeted the party warmly upon their return, suggesting he is genuinely appreciative and not coldly transactional. Generous with rewards — offered a rare and valuable spell gem for the party's service.

## History with the Party
1. **Quest Assignment:** Tasked the party with hallowing Ogremoch's temple.
2. **Quest Completion & Reward:** Welcomed the party back to Diggermattock Hall upon their successful return. Presented them with an empty fourth-level spell gem as a reward. The party chose to imbue it with a healing spell for emergencies.

## Current Status
- **Last Known Location:** Diggermattock Hall
- **Active Plans:** None currently known; the quest he issued has been completed.
- **Party Knowledge:** The party knows him as a reliable cleric and quest-giver based in Diggermattock Hall who rewards good work generously.

## Relationships
- **The Party:** Positive relationship; grateful for their service in hallowing Ogremoch's temple.
- **Diggermattock Hall:** Appears to be a resident or affiliate, operating out of the hall.
