---
name: Nomi Pathshutter
aliases: []
---

# Nomi Pathshutter

## Identity
- Major leader of Blingdenstone
- First appeared at the grand moot as part of Blingdenstone's leadership delegation

## Personality & Motivations
- Core goal: Cleansing the Temple of the Steadfast Stone to enable the safe summoning of Earth Elementals, free from the corrupting influence of Ogremoch's Bane.
- Appears politically coordinated and prepared — delivered what seemed to be a rehearsed presentation alongside Gurnik Tapfinger, suggesting she values careful planning and unified messaging.

## History with the Party
- **Grand Moot:** Presented jointly with Gurnik Tapfinger before the assembled leaders. Their proposal outlined a plan to cleanse the Temple of the Steadfast Stone, which would allow Earth Elementals to be summoned and shielded from being driven insane by Ogremoch's Bane. The presentation appeared rehearsed and coordinated.

## Current Status
- **Last known location:** The grand moot in Blingdenstone.
- **Active plans:** Seeking support for the cleansing of the Temple of the Steadfast Stone.
- **Party knowledge:** The party is aware of her proposal and her partnership with Gurnik Tapfinger. The full extent of what cleansing the temple would entail, or what obstacles exist, remains unclear.

## Relationships
- **Gurnik Tapfinger:** Close political ally; they coordinate and present jointly on matters of Blingdenstone's defense and restoration.
- **Blingdenstone:** One of the settlement's major leaders.
- **The Party:** No direct personal interaction noted beyond witnessing her moot presentation.
