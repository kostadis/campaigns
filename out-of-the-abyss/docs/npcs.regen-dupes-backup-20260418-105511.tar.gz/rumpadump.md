---
name: Rumpadump
aliases: []
---

# Rumpadump

## Identity
- Myconid sprout, member of Stool's circle
- First spotted by Zalthir looking upset and not dancing among the other myconids; Stool identified him by description and became frantic to rescue him

## Personality & Motivations
- A young myconid sprout who wants to be with his own kind. He was visibly distressed when separated from his circle, standing apart from the dancing myconids. Upon returning to Neverlight Grove, he was overjoyed, running in with delight and shouting "We're home!"

## History with the Party
1. **Discovery**: Zalthir spotted Rumpadump looking upset and not participating in the dancing myconids. Stool recognized the description and became frantic to rescue him, believing Rumpadump could explain what was happening with the dancing myconids.
2. **Rescue & Travel**: The party rescued Rumpadump. He traveled with the group, chatting with Stool as they left the Whorlestone Caves and passed through the Derro slums.
3. **Arrival at Neverlight Grove**: Rumpadump ran into the Grove alongside Stool, shouting "We're home!" with delight. Basidia assured the party that Rumpadump is happy among his kind.

## Current Status
- **Location**: Neverlight Grove, living among the myconid community
- **Status**: Happy and settled, per Basidia's assurance
- Grygum expressed concern about the safety of both sprouts (Rumpadump and Stool), suggesting they might be safer continuing with the party — but for now, both remain at the Grove

## Relationships
- **Stool**: Close companion; fellow sprout from the same circle. The two chatted together during travel and arrived home together with shared excitement.
- **Basidia**: Myconid elder/leader at Neverlight Grove who vouched for Rumpadump's happiness.
- **Grygum**: Expressed protective concern, asking whether both sprouts should continue traveling with the party rather than staying behind.
- **The Party**: Rescued him and escorted him safely to Neverlight Grove. He was a traveling companion but does not appear to have had deep individual bonds with specific party members beyond Stool.
