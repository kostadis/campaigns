---
name: Senni
aliases: []
---

# Senni

## Identity
- Quartermaster of Blingdenstone; represents the non-mining population of the city
- First mentioned by city guards as someone the party should speak with (alongside Chief Dorbo Diggermattock) about full permissions and Glabagool's presence in the city

## Personality & Motivations
- Advocates for the broader civilian population of Blingdenstone, not just the mining interests. She is pragmatic and willing to confront Chief Dorbo publicly when she feels he is failing the community — particularly on the ooze infestation problem. She appears more open-minded than Dorbo, notably regarding potential reconciliation with the Gold Whisker clan (whom Dorbo suspects of being wererats).

## History with the Party
1. **Initial mention:** City guards recommended the party speak with Senni and Chief Dorbo about gaining full permissions in Blingdenstone, especially regarding Glabagool.
2. **Diggermattock Hall confrontation:** The party witnessed Senni clash with Chief Dorbo over his inadequate response to the ooze infestation. She also showed openness to reconciling with the Gold Whisker clan.
3. **Grand Moot:** Senni had agreed to support Daz's plan beforehand. At the grand moot, she asked Daz to lead the meeting and call it to order, present among the major leaders during the planning session.

## Current Status
- **Last known location:** Diggermattock Hall / the grand moot in Blingdenstone
- **Active concerns:** The ooze infestation; broader city governance and relations with the Gold Whisker clan
- **Party knowledge:** The party knows she is a key political figure who is more flexible than Dorbo and has thrown her support behind Daz's plan

## Relationships
- **Chief Dorbo Diggermattock:** Political counterpart and frequent source of friction; they clash on the ooze problem and on the Gold Whisker clan issue
- **Daz (party member):** Supportive — she backed Daz's plan and deferred to him to lead the grand moot
- **Gold Whisker clan:** More open to reconciliation than Dorbo
- **The party generally:** Cooperative; recommended as a point of contact by the city guards
