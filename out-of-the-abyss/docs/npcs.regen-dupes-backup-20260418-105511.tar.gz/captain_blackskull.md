---
name: Captain Blackskull
aliases: []
---

# Captain Blackskull

## Identity
- Referenced by title "Captain"; no faction affiliation explicitly stated beyond a connection to the Deepking's court/domain
- Has not appeared directly; known only through a stolen contract found on Eldgrim's desk

## Personality & Motivations
- Alleged to have harbored ambitions for the Deepking's throne since she was young. No direct personality traits have been observed in play.

## History with the Party
- The party discovered a contract on Eldgrim's desk that references Captain Blackskull by name. The contract, written or ordered by the Deepking, accuses her of long-standing treasonous ambitions and calls for her to "receive what's coming to her" — implying an assassination or punishment order.

## Current Status
- **Last known location:** Unknown
- **Active plans:** The Deepking has apparently sanctioned action against her via the contract found with Eldgrim, suggesting Eldgrim may be tasked with carrying out or facilitating her punishment
- **Party knowledge:** The party knows the Deepking suspects her of treason and wants her dealt with. They do not appear to have met her or know her location. Whether Eldgrim has acted on the contract is unknown.

## Relationships
- **The Deepking:** Views her as a traitor and rival for his throne; has suspected her since her youth. Has issued orders against her.
- **Eldgrim:** The contract was found on his desk, implying he is involved in executing the Deepking's orders regarding Blackskull.
- **The Party:** No direct relationship. They are aware of her existence only through the stolen contract.

## Arc Score Events
None recorded.
