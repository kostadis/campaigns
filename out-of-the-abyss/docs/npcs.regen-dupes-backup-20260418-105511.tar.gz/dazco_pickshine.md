---
name: Dazco Pickshine
aliases: []
---

# Dazco Pickshine

## Identity
- Representative of the Miners Guild
- First appeared during a council meeting where the party brokered a compromise on mining operations

## Personality & Motivations
- Core goal: Secure funding for city repairs through mining revenue
- Pragmatic and economically driven; initially pushed for aggressive strip mining as the fastest path to needed funds. Willing to compromise when presented with a viable alternative, suggesting he prioritizes results over ideology.

## History with the Party
- **Council Meeting:** Advocated for immediate strip mining to fund city repairs. The party brokered a sustainable mining compromise that balanced the Miners Guild's economic needs with respect for ghosts' sacred grounds. Dazco agreed to the terms.

## Current Status
- Last known status: Operating under the sustainable mining compromise agreed upon at the council meeting
- Presumably overseeing Miners Guild operations within the boundaries of the new agreement
- No hidden agendas indicated in available notes

## Relationships
- **Miners Guild:** Serves as their representative; speaks on their behalf in political matters
- **The Party:** Accepted their compromise proposal; relationship is cooperative but likely transactional
- **Ghosts / Sacred Grounds:** Was initially willing to disregard their claims; now bound by the compromise to respect sacred sites

## Arc Score Events
- None noted.
