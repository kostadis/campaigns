---
name: Pliinki
aliases: []
---

# Pliinki

## Identity
- Derro devotee of Demogorgon; cult authority figure and experimentalist
- Faction ties: Cult of Demogorgon, coordinated with the Gray Ghosts and the Council of Savants
- Never encountered alive by the party; her death was confirmed when they passed through the guard post near the obelisk chamber. Her journal and letters were discovered posthumously by Zalthir.

## Personality & Motivations
- Core goal: Conquer Gracklstugh and offer it as a sacrificial gift to Demogorgon, using the Obelisk ("The Stone of Diirinka") as the instrument of conquest.
- Secondary goal: Mutate a stolen red dragon egg into a two-headed wyrmling intended as a mount for Demogorgon.
- She was a charismatic ideologue who inspired loyalty in lower-ranking Derro by promising liberation from Duergar bondage. Both Skiit and Ulnara sought her approval and believed in her vision of Derro empowerment through Demogorgon's favor.

## History with the Party
1. **Obelisk Chamber Discovery**: The party found Pliinki already dead. Zalthir recovered her journal and letters from a desk in the northwest corner of the obelisk chamber, revealing the full scope of her plans.
2. **Guard Post Confirmation**: Her death was confirmed when the party passed through the guard post at the double doors — the same guards she had promised freedom from Duergar bondage.
3. **Indirect References**: Before the obelisk chamber, the party encountered Skiit (who cited Pliinki's promises of a better job and Derro glory) and Ulnara (who hoped the party would tell Pliinki she had been helpful).

## Current Status
- **Dead.** Killed before or during the party's incursion.
- Her conspiracy network remains partially intact: Uskvil (Gray Ghosts), Aliinka (Council of Savants/Gray Ghosts), and Narrak (cult leader) were her co-conspirators.
- The party knows the full scope of her plans via her journal: the dragon egg mutation, the obelisk repair attempts with Thrazgad ore (which failed), the assassination lists, and the Gracklstugh destabilization campaign.

## Relationships
- **Uskvil** — Gray Ghosts leader; co-conspirator in destabilizing Gracklstugh.
- **Aliinka** — Council of Savants member / Gray Ghosts affiliate; co-conspirator.
- **Narrak** — Cult leader; co-conspirator.
- **Skiit** — Derro subordinate who believed in her promises of empowerment and a better position.
- **Ulnara** — Derro subordinate who sought Pliinki's approval and wanted credit for helping the party.
- **Derro Guards (double doors)** — Promised them freedom from Duergar bondage through her plan.
- **Zalthir** (party member) — Discovered her journal and letters; primary source of intelligence on her operations.
