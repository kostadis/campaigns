---
name: Fargus Rumblefoot
aliases: []
---

# Fargus Rumblefoot

## Identity
- Role and faction affiliation unknown from available notes
- First appearance predates the sessions covered; met the party prior to their exploration of the Lost Tomb of Khaem

## Personality & Motivations
- Insufficient data to establish personality traits or core motivations beyond a willingness to share knowledge about dangerous locations with the party.

## History with the Party
- **Pre-session (referenced):** Warned the party about a "secret room" or "false tomb" within the Lost Tomb of Khaem. This intel proved accurate — the party recalled his warning when they discovered a hidden passage beneath the northeast sarcophagus during their exploration of the tomb.

## Current Status
- Last known location and current activities unknown
- Not present during the tomb exploration
- The party has confirmed his information was reliable, which may affect their trust in future tips from him

## Relationships
- Has an established rapport with the party sufficient to share dungeon intelligence with them
- No other NPC or faction relationships noted

## Arc Score Events
None recorded.
