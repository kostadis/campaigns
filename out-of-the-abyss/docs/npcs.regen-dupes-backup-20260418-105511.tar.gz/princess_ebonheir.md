---
name: Princess Ebonheir
aliases: []
---

# Princess Ebonheir

## Identity
- One of the Pudding King's two ooze henchmen
- Present in the Pudding King's throne room

## Personality & Motivations
- Serves the Pudding King as a loyal enforcer/companion. No independent personality traits observed beyond her role as his henchman.

## History with the Party
- **Throne Room Encounter:** Present when the Pudding King monologued about victory. During the ensuing fight, she was separated from the Pudding King when Zalthir grappled him and dragged him fifteen feet south.

## Current Status
- Last known location: the Pudding King's throne room
- Separated from the Pudding King during combat; presumably still an active combatant
- No hidden information noted

## Relationships
- **The Pudding King:** Loyal ooze henchman; one of two serving him directly
- **Zalthir (party member):** Opposed in combat; Zalthir's grapple of the Pudding King created distance between Ebonheir and her master
