---
name: Themberchaude
aliases: []
---

# Themberchaude

## Identity
- Red dragon residing in Gracklstugh
- Associated with the Keepers of the Flame faction
- Has not appeared in person; referenced only through NPC dialogue (Daz's political analysis and Thorin's comments)

## Personality & Motivations
- Paranoid about his standing — suspects the Keepers of the Flame have their own agenda and may be undermining his authority. Wants intelligence on what is truly happening in the city. Uncertain whether he holds genuine power or is being manipulated.

## History with the Party
- **Mentioned by Daz** during his breakdown of Gracklstugh's political landscape. Daz described Themberchaude's suspicions about the Keepers of the Flame and his desire for information.
- **Mentioned by Thorin**, who floated a plan to escape Gracklstugh by riding on Themberchaude's back.

## Current Status
- **Location:** Gracklstugh (exact lair location unspecified)
- **Activity:** Seeking information about the machinations of the Keepers of the Flame; questioning whether his position of power is genuine
- **Party knowledge:** The party knows he exists, knows he's suspicious of the Keepers, and knows he wants intel. They have not met him directly.
- **Hidden:** The full truth of his relationship with the Keepers and whether he is truly in control remains unclear.

## Relationships
- **Keepers of the Flame:** Distrustful; believes they have secret plans and may be working against his interests
- **Daz:** Source of information about Themberchaude's situation
- **Thorin:** Views Themberchaude as a potential escape route out of Gracklstugh
- **The Party:** No direct contact yet

## Arc Score Events
None recorded.
