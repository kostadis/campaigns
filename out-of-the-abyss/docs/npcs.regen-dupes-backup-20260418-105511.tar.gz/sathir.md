---
name: Sathir
aliases: []
---

# Sathir

## Identity
- No specific role, title, or faction affiliation mentioned in the notes.
- Context suggests Sathir is a companion or fellow traveler with the party, present after fleeing Sloopbludop.

## Personality & Motivations
- Appears pragmatic and forward-looking, immediately turning attention to the group's next move rather than dwelling on what they fled from.

## History with the Party
- Was present with the group after their escape from Sloopbludop and participated in the discussion about where to go next.

## Current Status
- Last known location: With the party, somewhere after fleeing Sloopbludop.
- No active plans or operations noted beyond the group's ongoing journey.

## Relationships
- Traveling companion of the party. No other specific NPC or faction relationships noted.

## Arc Score Events
None noted.
