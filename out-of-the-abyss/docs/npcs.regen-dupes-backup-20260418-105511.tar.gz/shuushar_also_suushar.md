---
name: Shuushar (also "Suushar")
aliases: []
---

# Shuushar

## Identity
- Fellow captive/companion of the party
- No specific faction affiliation noted

## Personality & Motivations
- Appears sensitive to magical or environmental phenomena, particularly Faerzess. His comment about Faerzess shifting from "just a light" to feeling like "a poison" suggests he has prior familiarity with the Underdark and its ambient magic, and is disturbed by the change he's perceiving.

## History with the Party
1. **Rockfall incident:** Grygum directed Stool to go help Shuushar after a rockfall, indicating Shuushar was injured or trapped.
2. **Faerzess cave passage:** While the group ran through a cave suffused with Faerzress, Shuushar was visibly uncomfortable. Afterward, he remarked that it was the first time Faerzress had affected him this way — previously it had been benign ("just a light"), but now it felt like "a poison."

## Current Status
- Traveling with the party through the Underdark
- Physically okay after the rockfall (received help from Stool)
- Noticeably unsettled by the changed nature of Faerzress — this may indicate a broader corruption spreading through the Underdark

## Relationships
- **Grygum:** Grygum showed concern for Shuushar's well-being, ordering Stool to assist him after the rockfall.
- **Stool:** Sent to help Shuushar; appears to be a willing helper in the group dynamic.

## Arc Score Events
- None explicitly noted.
