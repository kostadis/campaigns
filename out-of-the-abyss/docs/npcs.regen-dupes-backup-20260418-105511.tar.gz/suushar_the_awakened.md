---
name: Suushar the Awakened
aliases: []
---

# Suushar the Awakened

## Identity
- Kuo-Toan prisoner held in the slave pen at the Drow outpost
- Serves as translator and cultural guide for party members who don't speak Undercommon
- First encountered as a fellow prisoner; became a key communication link for Gyrgum

## Personality & Motivations
- Claims a spiritual practice centered on balance and coping with what he calls "the madness of my race." Wants to share "enlightenment" with his people.
- Eager to guide the group to Darklake to visit the Kuo-Toa. This appears to be his primary personal goal.
- Humorously unreliable as a diplomatic translator — professes to omit offensive words as part of his spiritual practice, then translates every insult anyway.
- Enthusiastic and somewhat flattering; told Gyrgum his cooking might lead the Kuo-Toa to "imagine a god like you."

## History with the Party
- **Prison life:** Reassured Gyrgum when Ront and Prince Derendil were taken for chores, calmly identifying each Drow taskmaster by name (Beremil — water duty, Balok — winch duty, Guldor — chamber pots, Imbros — cooking) and explaining the routine.
- **Kitchen duty:** Relayed Topsy and Turvy's request for Gyrgum to create a distraction so they could steal food. Translated for Drow overseers during this time.
- **Escape planning:** Advocated for traveling to Darklake first, warning that the direct route to Blingdenstone passes through Menzoberranzan. Pushed for the group to visit his people.

## Current Status
- **Location:** Slave pen at the Drow outpost.
- **Active plans:** Lobbying for the escape route to go through Darklake so the party can meet the Kuo-Toa.
- **Known vs. hidden:** The party knows his stated spiritual motivations and his knowledge of the Drow guards' routines. His deeper agenda regarding his people and "enlightenment" remains vague.

## Relationships
- **Gyrgum:** Primary communication partner; acts as his translator and guide. Flatters Gyrgum's cooking skill.
- **Topsy & Turvy:** Cooperates with them; served as go-between for their food-theft scheme.
- **Ront & Prince Derendil:** Aware of their movements and concerned enough to explain their absence to Gyrgum.
- **Drow taskmasters (Beremil, Balok, Guldor, Imbros):** Knows them by name and their assigned duties, suggesting he has been observant or imprisoned for some time.
