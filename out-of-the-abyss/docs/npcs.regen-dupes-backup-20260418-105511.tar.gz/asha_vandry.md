---
name: Asha Vandry
aliases: []
---

# Asha Vandry

## Identity
- Drow priestess, devout follower of Lolth
- Unaffiliated with Ilvara's faction; actively opposes the "bride heresy" (the belief that Zuggtmoy's influence is a manifestation of Lolth)
- First encountered in the fungal cavern, one of only three individuals not yet enslaved by Ilvara's spores

## Personality & Motivations
- Core goal: the death of Ilvara and the destruction of her mushroom artifact. She cannot accomplish this herself and has allied with the party to see it done.
- Paranoid, sharp-witted, and deeply contemptuous of those she considers beneath her. She treats most of the party with open disdain, directing conversation exclusively toward Daz. She refuses all physical contact out of an intense fear of fungal contamination. Despite her harshness, she shows flashes of weary, exasperated humanity — particularly when complaining about Jorlan and Ilvara's romantic drama.

## History with the Party
- **Fungal Cavern Encounter:** The party found Asha uninfected and hostile to Ilvara. Daz attempted to deceive her with a staged divine visitation from Lolth (Dancing Lights + spider familiar). Asha saw through the ruse but reframed it as a divine test of her own discernment, concluding she had passed Lolth's test by identifying Daz as a charlatan.
- **Tactical Briefing:** She provided critical intelligence — the Heart Fungus itself does not cause the spore illness; only Ilvara's spores and her mushroom artifact do. She warned that Thorin and Grygum specifically should not approach the artifact due to a marker acquired in the Whorlstone Caverns of Gracklstugh. She advised the party to target the Heart Fungus with their most powerful spell rather than Ilvara directly.
- **Alliance Formed:** A tentative deal was struck — the party kills Ilvara and destroys the mushroom artifact; in exchange, the party receives everything Ilvara had accumulated.
- **Glabbagool Moment:** Briefly alarmed when Glabbagool's eyes became visible, but was impressed when Thorin introduced the ooze as Daz's familiar.

## Current Status
- **Location:** Fungal cavern, waiting for the party to carry out the assault on Ilvara.
- **Active plans:** Entirely dependent on the party fulfilling the alliance terms. She cannot or will not act against Ilvara directly.
- **Known to party:** Heart Fungus vs. Ilvara's spores distinction; the Whorlstone marker danger for Thorin and Grygum; the three uninfected survivors (Asha, Jorlan, and one other implied); the spore servants were willing converts.
- **Hidden:** Her full capabilities, the identity of the implied third uninfected individual, and the precise nature of the Whorlstone marker are not fully explained. Her tactical advice ("I believe") was self-qualified, suggesting she may not be entirely certain of her own intelligence.

## Relationships
- **Daz:** The only party member she treats with any respect. Directs all conversation toward him. Saw through his deception but chose a self-serving interpretation rather than hostility.
- **Zalthir & Grygum:** Open disdain. Dismissed Grygum's Phantasmal Killer suggestion with cutting contempt. Largely ignores Zalthir.
- **Thorin:** Warned him away from the artifact due to the Whorlstone marker. Warmed slightly after the Glabbagool introduction.
- **Ilvara:** Deep, bitter hatred. Wants her butchered and sent to "an unearthly grave."
- **Jorlan:** One of the three uninfected survivors. Asha is exhausted by his unresolved romantic entanglement with Ilvara, which she has been forced to mediate.
- **Lolth:** Genuinely devout. Her faith is part of what has kept her free of infection. Rejects the bride heresy completely.
- **Glabbagool:** Initially alarmed, then impressed.

## Arc Score Events
- No explicit arc score changes noted in source material.
