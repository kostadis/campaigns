---
name: Asha
aliases: []
---

# Asha

## Identity
- Drow cleric stationed at Velkynvelve
- Subordinate to Ilvara, the outpost's commander
- First mentioned by Jimjar as part of the power dynamics at Velkynvelve

## Personality & Motivations
- Ambitious — actively positioning herself to challenge or replace Ilvara as commander of Velkynvelve. Beyond this core drive, little else has been revealed about her personality through play.

## History with the Party
- The party has not directly interacted with Asha. Her existence and ambitions were relayed to them by Jimjar while at Velkynvelve.

## Current Status
- **Last known location:** Velkynvelve
- **Active plans:** Angling for Ilvara's position as outpost commander
- **Party knowledge:** The party knows only what Jimjar told them — that Asha is a Drow cleric gunning for the top job. The specifics of her plans, her capabilities, and the extent of any internal faction tension with Ilvara remain unknown.

## Relationships
- **Ilvara:** Rival / superior. Asha seeks to supplant her as commander.
- **Jimjar:** Aware of Asha's ambitions; served as the party's source of information about her.
- **The Party:** No direct relationship established.
