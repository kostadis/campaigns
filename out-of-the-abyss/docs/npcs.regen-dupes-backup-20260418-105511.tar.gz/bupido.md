---
name: Bupido
aliases: []
---

# Bupido

## Identity
- Derro prisoner, fellow captive during the party's imprisonment
- First appeared during the prison escape, where he helped lead the other prisoners

## Personality & Motivations
- Initially appeared cooperative and willing to fight alongside the party during the escape. However, he was secretly treacherous — a worshipper of some demonic power who ultimately betrayed the group. His true nature was revealed when he murdered a member of the party's group.

## History with the Party
1. **Prison Escape:** Bupido led the other prisoners in rushing the guard chamber and armory during the distraction created by Thorin, Zalthir, and Daz's confrontation with the guards. He participated in the crossbow volley against Imbros but missed his shot.
2. **Betrayal and Death:** At some point after the escape, Bupido betrayed the party and killed one of their group. He maintained a lair containing dead bones and an altar to a demonic power. He was ultimately killed by the party (details not recorded in these notes).

## Current Status
- **Dead.** His former lair — a grim bone-filled space with a demonic altar — was later used by the party as a resting point before their assault on a cultist cavern.
- His betrayal left a lasting mark on the party's trust; Daz specifically cites Bupido as the reason they now restrain unfamiliar allies at night.

## Relationships
- **The Party (general):** Initially an ally of convenience during the escape; became an enemy through betrayal. His treachery is now a cautionary reference point for the group.
- **Daz:** Particularly vocal about the lesson learned from Bupido's betrayal; uses it to justify caution with new companions.
- **Pelek/Derro ghost:** No direct relationship, but Bupido's betrayal is the explicit reason the party ties this entity up at night.

## Arc Score Events
- No arc score events recorded in the source notes.
