---
name: The Pudding King
aliases: []
---

# The Pudding King

## Identity
- Small deep gnome, now transformed/corrupted; self-styled ruler of an ooze kingdom
- Allied with **Juiblex** (the Faceless Lord, demon lord of oozes); also in communication with **Zuggtmoy**
- Central source of the ooze infestation plaguing **Blingdenstone**
- First encountered as a disembodied voice welcoming visitors to the ooze-filled caverns south of Blingdenstone; later observed via Daz's bat familiar on a slime-covered throne

## Personality & Motivations
- Driven by vengeance, pride, and madness, all amplified by Juiblex's demonic influence. He seeks to convert all of Blingdenstone's biomass into ooze biomass—consuming everyone. He holds court like a deranged king, monologuing to his ooze henchmen and gloating over the city's destruction. He is territorial even among his demon patrons, ranting that Zuggtmoy will not take "his kingdom" because Juiblex promised it to him.

## History with the Party
1. **Disembodied voice**: The party first heard him proclaiming the coming of the Faceless Lord as they explored the ooze-filled caverns south of Blingdenstone.
2. **Scouted via familiar**: Daz's bat familiar located him on a slime-covered throne in a phosphorescent cave, surrounded by green slime pools and hundreds of oozes. The party assessed that killing him without coordination could unleash the uncontrolled ooze army on the city.
3. **Background from Chipgrin**: Chief Chipgrin revealed he had known the Pudding King as a gnome tunnel worker before his transformation. The party learned that his demonic corruption is bleeding outward, amplifying greed and aggression throughout Blingdenstone's population.
4. **Zuggtmoy connection**: A psychic message from Zuggtmoy was intercepted, revealing she was speaking to the Pudding King about using oozes to "soften the shell" so her garden could "take root in the flesh beneath."
5. **Final confrontation**: The party executed their plan—army distraction at the ooze amphitheater, covert strike on the Pudding King. He was observed monologuing to **Princess Ebonheir** and **Prince Livid** about Blingdenstone's defeat. When **Zalthir** reached and grappled him, he transformed into an amorphous ooze form, but Zalthir maintained his grip and dragged him 15 feet south, isolating him from his henchmen.

## Current Status
- **Last known**: Grappled by Zalthir in his throne room, separated from Princess Ebonheir and Prince Livid; in ooze form
- **Active operations**: His ooze army is engaged with the Blingdenstone army at the amphitheater; green slime on the ceiling remains a throne-room hazard
- **Hidden from party**: The full extent of the Zuggtmoy–Juiblex rivalry playing out through him; whether his ooze transformation is reversible

## Relationships
- **Juiblex**: Primary patron; promised the Pudding King dominion over Blingdenstone
- **Zuggtmoy**: Secondary demon lord contact; she views his oozes as tools to prepare ground for her fungal garden — he resents her encroachment
- **Princess Ebonheir & Prince Livid**: His two ooze "henchmen," serving as lieutenants in his throne room
- **Chief Chipgrin**: Knew him before his transformation; a former acquaintance from the tunnels
- **Blingdenstone**: His demonic influence is corrupting the entire gnome community, not just generating oozes
- **Zalthir**: Currently grappling him in combat
- **Daz**: Scouted his throne room via bat familiar

## Arc Score Events
- Discovery that his corruption is bleeding into and destabilizing Blingdenstone's community (escalation of threat)
- Interception of Zuggtmoy's psychic message revealing a second demon lord's involvement (escalation)
- Zalthir successfully grappling and isolating him from his henchmen (potential turning point toward resolution)
