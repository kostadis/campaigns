---
name: Thermbechaud
aliases: []
---

# Thermbechaud

## Identity
- Referenced as a landmark/location ("Thermbechaud's cave")
- No direct interaction with the party; known only as a geographic reference point

## Personality & Motivations
- No information available from session notes.

## History with the Party
- Thermbechaud's cave served as the starting point for the party's journey to the Cairngorm Cavern. No direct encounter or interaction occurred.

## Current Status
- Last known location: Thermbechaud's cave
- No further details available

## Relationships
- None established in session notes.

## Arc Score Events
- None.
