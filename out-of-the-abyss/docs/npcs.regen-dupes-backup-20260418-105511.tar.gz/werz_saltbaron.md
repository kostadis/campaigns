---
name: Werz Saltbaron
aliases: []
---

# Werz Saltbaron

## Identity
- Duergar merchant operating near the piers of Ghohlbrorn's Lair
- First encountered when the party found him unconscious after being attacked by two assassins on the docks

## Personality & Motivations
- Core goals are unclear beyond his mercantile activities, though he is clearly someone who has made powerful enemies. He showed genuine surprise and gratitude when healed, and rewarded loyalty — inviting the party to the Shattered Spire to repay them. His use of invisibility to depart suggests caution and resourcefulness typical of Duergar.

## History with the Party
1. **Assassination Attempt:** The party discovered Werz unconscious on the piers, attacked by two assassins wielding glowing (possibly psychic) weapons. He had no visible wounds. The assassins carried a charcoal drawing of him, confirming he was a deliberate target.
2. **Rescue & Gratitude:** Grygum healed him. Werz expressed surprise and gratitude, claimed ignorance of why he was targeted. Upon seeing the drawing of himself, he realized the attack was premeditated. He invited the party to the Shattered Spire the next day to reward them, then turned invisible and departed.
3. **Contract Investigation:** The party later learned from Eldgrim (an assassin/broker) that there was a hit on Werz, though Eldgrim considered him "small potatoes." Eldgrim offered to cancel the contract and permanently brightlist Werz for 20 gold, or for free if the party eliminates the Demogorgon cult.
4. **Deepking Connection:** A stolen contract from Eldgrim's desk contained a furious, personal tirade against Werz — *"THAT SNIVELING SQUEALING WRITHING LITTLE RAT! BIND HIS FEET AND THROW HIM OFF HIS BELOVED DOCKS!"* — written under the personal seal of the Deepking.

## Current Status
- **Last known:** Departed the docks invisibly, saying "he has places to be." Invited the party to meet him at the Shattered Spire the next day.
- **Active threats:** The assassination contract originated from the Deepking himself. Whether Eldgrim has cancelled it yet depends on the party's progress against the Demogorgon cult.
- **Hidden from the party:** Werz claimed no knowledge of why he was targeted. The party now knows the Deepking personally ordered the hit, suggesting Werz has done something to deeply anger the ruler — but the specific offense remains unknown. Werz himself may or may not be aware of the Deepking's involvement.

## Relationships
- **The Deepking:** The Deepking has a visceral, personal hatred of Werz and ordered his assassination. The reason is unknown.
- **Eldgrim:** Considers Werz "small potatoes" — a low-priority contract. Willing to cancel and brightlist him as a bargaining chip.
- **The Party:** Grateful to them for saving his life; owes them a reward at the Shattered Spire.
- **Grygum:** Directly healed by Grygum; expressed personal gratitude.

## Arc Score Events
- **Werz → Party (increase):** Party saved his life and healed him; he offered a reward and future meeting.
- **Deepking → Werz (hostile):** The Deepking's personal seal on the assassination contract indicates extreme animosity.
