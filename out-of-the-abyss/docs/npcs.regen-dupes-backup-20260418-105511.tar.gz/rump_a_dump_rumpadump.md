---
name: Rump-a-dump (Rumpadump)
aliases: []
---

# Rump-a-dump (Rumpadump)

## Identity
- Myconid, companion of the party
- Traveled with the party alongside fellow Myconid, Stool

## Personality & Motivations
- Opinionated and detail-oriented — willing to enumerate lengthy lists of personal criticisms. Demonstrated genuine care for party members beneath a blunt exterior, as evidenced by the sadness shown when saying goodbye to Daz.

## History with the Party
- Traveled with the party as a companion alongside Stool.
- Was convinced by Grygum (along with Stool) that Neverlight Grove was no longer safe.
- Before departing, approached Zalthir and delivered a list of approximately fifty specific ways Zalthir could improve himself, including advice such as "Listen to Stool, he knows what he is doing," "Don't assume you know everything; other people's points of view are important," and "Eat more Zurkhwood, it's good for your digestion."
- Said goodbye to Daz with a hint of sadness before leaving with the other Myconids.

## Current Status
- Departed with their Myconid people, away from Neverlight Grove.
- Last known status: traveling with other Myconids after being convinced the Grove was unsafe.
- Current destination unknown.

## Relationships
- **Stool**: Fellow Myconid companion; Rump-a-dump considers Stool wise ("Listen to Stool, he knows what he is doing").
- **Grygum**: Trusted Grygum's warning about Neverlight Grove enough to leave.
- **Zalthir**: Had strong opinions about Zalthir's shortcomings — delivered an extensive list of self-improvement advice before departing.
- **Daz**: Showed genuine emotional attachment; said goodbye with visible sadness.
