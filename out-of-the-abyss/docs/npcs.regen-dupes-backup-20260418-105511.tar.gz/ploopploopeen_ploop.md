---
name: Ploopploopeen (Ploop)
aliases: []
---

# Ploopploopeen (Ploop)

## Identity
- Archpriest of the Sea Mother (kuo-toa religious leader)
- Father of Bloppblippodd
- Faction: Sea Mother cult (opposed to the Deep Father cult)
- Met by the party during the kuo-toa civil conflict in Sloobludop

## Personality & Motivations
- Core goal: Destroy the Deep Father cult and eliminate his own daughter's heretical influence, even at the cost of her life.
- Cunning and manipulative — willing to use the party as unwitting pawns in an elaborate deception. Presented the escapees as sacrificial offerings to gain proximity to Bloppblippodd, only to turn on her at the critical moment. Cold-blooded enough to personally deliver the killing blow against his own daughter.

## History with the Party
1. **The Altar Ruse:** Ploop stepped forward at the Deep Father altar and presented the party as offerings to Bloppblippodd, appearing to betray them. In truth, this was a calculated ploy — he was betraying his daughter, not the escapees.
2. **Civil War Triggered:** Ploop attacked Bloppblippodd alongside his allies, igniting an all-out civil war among the kuo-toa.
3. **Thorin's Realization:** Thorin noted that Ploop could have paralyzed the entire party with hold person spells if he had genuinely been working against them — evidence that Ploop was playing a deeper game.
4. **Daughter Slain:** Ploop personally struck the final, fatal blow against Bloppblippodd before the altar.
5. **Hut Looted:** After the battle, Grygum looted Ploop's thatched hut, justifying it by claiming Ploop had promised the party payment.

## Current Status
- **Last known location:** Sloobludop, at or near the altar where the battle took place.
- **Status after Demogorgon's emergence:** Unknown. Fate is unconfirmed.
- **What the party knows:** Ploop deceived them but ultimately fought on their side; he killed his own daughter; he apparently promised them payment.
- **What remains hidden:** Whether he survived Demogorgon's emergence; his longer-term plans for Sloobludop and the Sea Mother cult.

## Relationships
- **Bloppblippodd:** His daughter. Killed her personally to end the Deep Father cult's influence. A relationship defined by religious fanaticism overriding familial bonds.
- **The Party:** Used them as props in his scheme but ultimately fought alongside them. Apparently promised them payment. The party looted his home in his absence.
- **Thorin:** Thorin specifically analyzed Ploop's tactics and recognized the deception, showing a degree of grudging respect or at least acknowledgment of Ploop's cunning.
- **Grygum:** Looted Ploop's hut post-battle, citing the promised payment as justification.

## Arc Score Events
- None explicitly noted.
