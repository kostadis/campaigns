---
name: Sethir
aliases: []
---

# Sethir

## Identity
- NPC companion/fellow traveler in the Underdark escape party
- No stated faction affiliation or title
- First appeared during the group's early Underdark travels; exact introduction session not specified in notes

## Personality & Motivations
- Motivated primarily by treasure and wealth — repeatedly advocates for visiting the lost temple / Lost Tomb of Khem
- Demonstrates a practical streak, noting that the Darklake route would be safer than tunnels
- Comes across as somewhat impulsive and blunt, openly announcing the party's plans aloud (potentially a liability)
- Notably susceptible to the Faerzress, which may explain why other party members find him "a bit off"

## History with the Party
1. **Early Underdark Travel:** Visibly affected by Faerzress-rich tunnels. Advocated for exploring a lost temple for treasure and suggested the Darklake as a safer travel route during the group's destination debate.
2. **Between Sessions (noted by Daz):** Daz flagged Sethir as suspicious, saying he "seems a bit off." No specific incident cited.
3. **After Kuo-Toan Ambush:** Present with the group; asked "Should we continue?" before the party pressed on toward Sloobludop.
4. **Gracklstugh:** Openly muttered about the party's plans to get equipment and then head to the Lost Tomb of Khem for treasure.

## Current Status
- **Last known location:** Gracklstugh, traveling with the party
- **Active plans:** Focused on reaching the Lost Tomb of Khem to find treasure
- **Known vs. hidden:** The party (specifically Daz) suspects something is off about Sethir, but the cause is unclear — could be Faerzress exposure, ulterior motives, or something else entirely

## Relationships
- **Daz:** Views Sethir with suspicion; has openly noted him as "a bit off"
- **Broader party:** Travels with the group but occupies a peripheral role; speaks up mainly regarding destinations and treasure
- **No known faction or NPC connections** beyond the traveling party

## Arc Score Events
- None explicitly noted in source material. Daz's suspicion could seed a future trust-related arc score event.
