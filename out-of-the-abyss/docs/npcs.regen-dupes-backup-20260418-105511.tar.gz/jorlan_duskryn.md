---
name: Jorlan Duskryn
aliases: []
---

# Jorlan Duskryn

## Identity
- Scarred drow warrior; brother of Nym Duskryn
- Former lover of Ilvara, discarded after receiving facial scarring due to drow society's emphasis on beauty
- First appeared fighting alongside (or near) the party during the battle in the fungal cavern

## Personality & Motivations
- Driven by a deep, unresolved personal grudge against Ilvara rooted in romantic rejection and humiliation. His charge toward her was described not as tactical but as "a wound reopening" — something uglier and more honest than rage. He is someone whose emotional scars run deeper than his physical ones, and when the opportunity arose to confront Ilvara, nothing else mattered.

## History with the Party
- **Fungal Cavern Battle:** Fought in proximity to the party during a chaotic battle. When Ilvara appeared wounded, Jorlan broke position and charged across swarm-infested terrain toward her, screaming her name. Thorin had an opportunity attack as Jorlan passed but deliberately let him go (rolled an 8, reasoned Jorlan was "functionally useful" charging Ilvara). Jorlan and Ilvara traded blows on the cavern floor after both survived a bridge collapse. He was subsequently hit by a lightning bolt from his own sister, Nym Duskryn, and left staggering.

## Current Status
- **Last known:** Staggering on the fungal cavern floor after being struck by Nym's lightning bolt. His fate after the battle is **not confirmed** — alive, dead, or fled is unknown.
- **Active plans:** None stated beyond his fixation on Ilvara.
- **Hidden info:** The party has no apparent knowledge beyond what they witnessed — his grudge against Ilvara and his sibling tension with Nym.

## Relationships
- **Ilvara:** Former lover. She discarded him after his scarring. His hatred for her is visceral and deeply personal. He engaged her in direct combat when the opportunity presented itself.
- **Nym Duskryn:** Sister. She struck him with a lightning bolt during the battle, described as channeling "professional frustrations" — suggesting a fraught sibling dynamic.
- **The Party:** Not a formal ally. He fought near them and his charge against Ilvara was recognized as tactically convenient. Thorin chose to let him pass. Zalthir assessed the situation as "the tides have turned."

## Arc Score Events
- None explicitly noted.
