---
name: Burrow Warden Jadger
aliases: []
---

# Burrow Warden Jadger

## Identity
- Spectral leader of the Burrow Warden ghosts of Blingdenstone
- Faction representative on the Blingdenstone council
- Encountered during the party's time in Blingdenstone

## Personality & Motivations
- Driven by the protection of sacred burial grounds and the honor of the fallen Burrow Wardens. Commands loyalty from the spectral host and carries himself with solemn dignity, as demonstrated by the formal banner salute upon the party's departure.

## History with the Party
- **Council Meeting:** Jadger's ghost faction objected to the Miners Guild's proposal to strip-mine the sanctum, which the Burrow Wardens considered sacred ground. A sustainable mining compromise was ultimately brokered that respected the burial grounds.
- **Departure from Blingdenstone:** Jadger and the Burrow Warden ghosts dipped their spectral banners in salute as the Ember Vanguard left the city — a gesture of respect and farewell.

## Current Status
- **Last Known Location:** Blingdenstone
- **Active Plans:** Presumably continuing to safeguard the sanctum under the terms of the sustainable mining compromise
- **Party Knowledge:** The party is aware of his role, the burial ground dispute, and the compromise that was reached

## Relationships
- **Burrow Warden Ghosts:** Their spectral leader; commands their loyalty
- **Miners Guild (Blingdenstone):** Factional tension over the sanctum; resolved through compromise
- **The Ember Vanguard:** Respectful terms — honored them with a banner salute at departure
