---
name: Stonespeaker Hgraam
aliases: []
---

# Stonespeaker Hgraam

## Identity
- Master of Dorhun and Rihaud; a figure of authority among the stone giants
- Has not appeared in person; mentioned by name during the party's encounter with Dorhun and Rihaud near the Blade Bazaar

## Personality & Motivations
- No direct personality traits observed — known only through his apprentices' reference to him as their master.

## History with the Party
- **Blade Bazaar encounter:** When the stone giants Dorhun and Rihaud introduced themselves to Thorin, they identified Stonespeaker Hgraam as the master to whom they are both apprenticed. No further details were shared.

## Current Status
- **Last known location:** Unknown; not encountered in person.
- **Active plans:** Unknown.
- **Party knowledge:** The party knows only his name, his title ("Stonespeaker"), and that Dorhun and Rihaud serve as his apprentices.

## Relationships
- **Dorhun** — Apprentice to Hgraam
- **Rihaud** — Apprentice to Hgraam
- **Thorin** — Indirect connection; Thorin was present when Hgraam's name was mentioned
