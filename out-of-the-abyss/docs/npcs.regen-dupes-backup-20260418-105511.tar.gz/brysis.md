---
name: Brysis
aliases: []
---

# Brysis

## Identity
- Wraith, ancient undead entity
- Encountered in a sarcophagus tomb in the Underdark (or dungeon complex)
- First appeared when the party opened or disturbed her tomb

## Personality & Motivations
- Driven by a desperate desire for freedom after millennia of imprisonment. Reacted with immediate hostility and fear upon seeing Dawnbringer, suggesting a history with the weapon. Defiant and dangerous even when cornered — refused to accept defeat after waiting so long to be free.

## History with the Party
1. **Pre-encounter:** Fargas Rumblefoot warned the party about a false tomb with a magical trap — a decoy set up by Brysis.
2. **Combat encounter:** When Thorin activated Dawnbringer, Brysis screamed "Not Dawnbringer!" in recognition/fear. She declared she had waited millennia for freedom and would not be denied. Daz hit her with spells; the party fought her collectively.
3. **Death:** Grygum delivered the killing blow with acid breath (memorably described by Zalthir as "killed by barf").
4. **Aftermath:** The magical trap in the false tomb dissipated upon Brysis's destruction. The party looted her real tomb, recovering a necklace of fireballs, a potion of greater healing, and gold.

## Current Status
- **Dead.** Destroyed by the party.
- Her false tomb trap has dissipated; her real tomb has been looted.

## Relationships
- **Dawnbringer:** Ancient enmity or fear — recognized the weapon immediately, suggesting a prior encounter or well-known threat to her existence.
- **Fargas Rumblefoot:** Knew enough about Brysis's false tomb to warn the party; unclear how he obtained this knowledge.
- **Party:** Hostile combatant. Key contributors to her defeat include Thorin (Dawnbringer activation), Daz (spells), and Grygum (killing blow).
