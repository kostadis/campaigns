---
name: Hargaam
aliases: []
---

# Hargaam

## Identity
- Associated with stone giants; likely a stone giant leader or chief
- Has not appeared directly; referenced only indirectly through events involving one of his stone giants

## Personality & Motivations
- Unknown. Hargaam has not been encountered or described in detail.

## History with the Party
- No direct interactions. The party learned that one of Hargaam's stone giants was driven mad as a result of Narrak's ritual, which involved a two-headed stone giant statue and the text known as *The Rituals of the Two-Headed Beast*.

## Current Status
- **Last known location:** Unknown
- **Active plans:** Unknown
- **Party knowledge:** The party knows only that Hargaam commands stone giants and that at least one was affected by Narrak's ritual. Everything else about Hargaam remains hidden.

## Relationships
- **Narrak:** Narrak's ritual directly harmed one of Hargaam's stone giants, driving it mad. The nature of any relationship or conflict between them is unknown.
- **Stone giants:** Hargaam has authority over stone giants; at least one served under him.

## Arc Score Events
None recorded.
