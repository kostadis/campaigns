---
name: Derendil
aliases: []
---

# Prince Derendil

## Identity
- Self-styled prince; considered "deluded" by others regarding his claim to royalty
- A large creature (race unspecified in notes) who was a fellow prisoner alongside the party

## Personality & Motivations
- Claimed to be royalty, though this was regarded as delusion by those around him. Little else is known of his personality beyond this persistent belief.

## History with the Party
- Derendil was among the prisoners held by the drow.
- He fought alongside the other prisoners during an uprising against drow guards.
- He was killed during the battle against the drow guards. His large corpse was left behind as the surviving prisoners prepared their escape.

## Current Status
- **Dead.** Killed fighting drow guards during the prisoner escape.
- His body was left behind at the site of the battle.

## Relationships
- Fellow prisoner of the party and other captives held by the drow.
- No specific individual relationships noted.

## Arc Score Events
- None recorded.
