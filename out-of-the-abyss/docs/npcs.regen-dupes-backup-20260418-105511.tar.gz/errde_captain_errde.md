---
name: Errde (Captain Errde)
aliases: []
---

# Captain Errde

## Identity
- Captain in the Stone Guard of Gracklstugh
- Apparent intelligence coordinator with ties to both the Stone Guard and the Drow
- Has not appeared directly to the party; known only through a subordinate's reference

## Personality & Motivations
- Operates as an authority figure who receives and relays intelligence reports. Her willingness to pass information about the party to the Drow suggests she prioritizes inter-faction cooperation (or obligation) over discretion. Precise motivations remain unknown.

## History with the Party
- A lone Stone Guard stationed at the Gracklstugh docks recognized the party from an **Ember Vanguard** wanted poster and immediately declared he needed to warn "Captain Errde" of their presence.
- No direct interaction with the party has occurred.

## Current Status
- **Last known location:** Gracklstugh (presumed)
- **Active operations:** Almost certainly relayed intelligence to the Drow that the party passed through Gracklstugh, meaning **the Drow are likely pursuing the party again** as a direct consequence.
- **What the party knows:** They know her name and that a Stone Guard intended to report their arrival to her. They may or may not realize she has tipped off the Drow.
- **What remains hidden:** Her rank's full scope, her relationship with the Drow, and whether she acts out of duty, alliance, or personal interest.

## Relationships
- **Stone Guard:** Commands at least some authority over dock-stationed guards; they report to her by name.
- **The Drow:** Shares intelligence with them — the nature of this relationship (formal alliance, coercion, mutual interest) is unclear.
- **Ember Vanguard:** The wanted poster her guard recognized suggests awareness of or coordination with this faction.
- **The Party:** Views them as persons of interest; no personal interaction yet.

## Arc Score Events
- No direct arc score events recorded. Her behind-the-scenes action of alerting the Drow effectively re-escalated the Drow pursuit threat against the party.
