---
name: Kaelira (Duskryn)
aliases: []
---

# Kaelira (Duskryn)

## Identity
- Member of House Duskryn; one of the Duskryn sisters
- Sent on a mission to extract Daz from a dangerous situation
- First encountered during a chaotic battle involving an insect swarm and poisonous gas

## Personality & Motivations
- Core goal: Extract Daz alive, seemingly under orders from House Duskryn.
- Direct, physical, and blunt — she grabbed Daz by the arm and dragged him to safety without asking permission. Her line, "Come with me if you want to live, you idiot," captures her no-nonsense, exasperated pragmatism. She prioritizes completing the mission over diplomacy or Daz's feelings about it.

## History with the Party
- **Extraction Battle:** Physically seized Daz during a battle and hauled him northeast through insect swarms and poisonous gas to rendezvous with her sister Nym. She enforced his survival without his consent.
- **Asha Vandree Confrontation:** Asha Vandree identified Kaelira as a potential traitor to Lolth. Daz intervened and defused the situation by claiming Kaelira and Nym were Lolth-aligned allies, providing them cover.

## Current Status
- **Last known location:** Northeast of the battle site, at the rendezvous point with Nym and Daz.
- **Active plans:** Unclear beyond the extraction mission; her broader objectives for House Duskryn are unknown.
- **Party knowledge vs. hidden:** The party knows she was sent to extract Daz and that Asha Vandree suspects her of being a traitor to Lolth. Whether she actually is disloyal to Lolth remains unconfirmed.

## Relationships
- **Nym (Duskryn):** Sister and mission partner; Nym was waiting at the extraction point while Kaelira did the physical retrieval.
- **Daz:** Extraction target. She treats him with blunt impatience but is committed to keeping him alive. He in turn shielded her from Asha's accusation.
- **Asha Vandree:** Asha flagged Kaelira as a potential traitor to Lolth — a dangerous accusation. Daz's intervention prevented immediate escalation, but this tension likely persists.
- **House Duskryn:** Operates on behalf of the house; the specifics of her standing and orders are not yet clear.

## Arc Score Events
- Asha Vandree's accusation of Lolth-betrayal is a potentially significant arc event, though no explicit score change was noted. Daz's defense of Kaelira may have shifted trust dynamics between Daz and Kaelira (direction: increase in trust/alliance).
