---
name: Gartokkar
aliases: []
---

# Gartokkar

## Identity
- Duergar member/associate of the Keepers of the Flame
- First encountered through a prior arrangement to retrieve a dragon egg; the party visited his house to complete the deal

## Personality & Motivations
- Described in Narrak's letter as paranoid and desirous of a "genocidal war" against the Derro. However, in person he came across as pragmatic and genuinely fearful of civil war erupting in Gracklstugh. He honored his deals and showed concern for the party's safety, issuing unprompted warnings about the city's volatile state.

## History with the Party
1. **Pre-session arrangement:** Gartokkar had a deal with the party to retrieve a dragon egg.
2. **Narrak's letter:** The party learned through Narrak's correspondence that Gartokkar is paranoid and wants a genocidal war against the Derro — context that colors their view of him.
3. **Party planning:** The group decided to return a mutated dragon egg to Gartokkar and use the transaction as a springboard to escape Gracklstugh before Errde Blackskull could imprison them. Grygum's plan included telling Gartokkar the egg was stolen by "some other crazed group" (not the Derro).
4. **Egg handoff:** The party visited his house. He eagerly asked about the egg, noticed occult markings on it and was worried, but asked Grygum (cleric of Bahamut) to evaluate it. He was pleased that the chromatic egg would produce an evil creature. He paid the party a bag of coins and honored their non-disclosure agreement.
5. **Warning:** Before the party left, he warned them about the Deepking's agents searching for the **Ember Vanguard** — shadowy assassins from Menzoberanzan with powerful magic and soul-rending blades. He stressed that the Derro, Stone Guard, and Grey Ghosts are all on edge, and some factions actively want conflict. Daz interpreted this warning as genuine fear that the party could inadvertently spark civil war.

## Current Status
- **Last known location:** His house in Gracklstugh
- **Active concerns:** Fearful of citywide conflict; aware of the Ember Vanguard threat
- **Party knowledge vs. hidden:** The party knows about his paranoia and anti-Derro sentiments (from Narrak's letter) and his surface-level helpfulness. Whether his desire for genocidal war against the Derro is active scheming or past rhetoric remains unclear to them.

## Relationships
- **Keepers of the Flame:** Affiliated member/figure
- **Narrak:** Narrak wrote about Gartokkar's paranoia and war-mongering tendencies
- **Grygum:** Respected Grygum's clerical judgment on the egg; completed their deal honorably
- **Daz:** Daz read his warning as genuine fear, not manipulation
- **Errde Blackskull:** Indirectly relevant — the party used the Gartokkar transaction to flee before Blackskull could act
- **The Derro:** Harbors deep hostility toward them (per Narrak's letter)

## Arc Score Events
- None explicitly noted.
