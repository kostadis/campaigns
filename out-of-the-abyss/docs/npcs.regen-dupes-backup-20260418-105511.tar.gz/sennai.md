---
name: Sennai
aliases: []
---

# Sennai

## Identity
- Quartermaster of Blingdenstone
- Faction affiliation: Blingdenstone leadership (alongside Chief Dorbo Diggermattock)
- Has not yet been met directly by the party

## Personality & Motivations
- Unknown — no direct interaction has occurred yet.

## History with the Party
- The party was informed they need to consult both Quartermaster Sennai and Chief Dorbo Diggermattock to receive full authorization to enter Blingdenstone. No meeting has taken place.

## Current Status
- **Last known location:** Blingdenstone
- **Active plans:** Unknown
- **Party knowledge:** They know her title (Quartermaster), her name, and that she is one of two leaders whose approval is required for city entry. Nothing else is known.

## Relationships
- **Chief Dorbo Diggermattock:** Co-leader in Blingdenstone; both must be consulted for authorization to enter the city.
- **The Party:** No direct relationship yet established.
