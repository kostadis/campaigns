---
name: Erdde Blackskull
aliases: []
---

# Erdde Blackskull

## Identity
- **Captain of the Stone Guards** (Duergar city guard/military)
- Met through Grygum, who she tasked with an investigation

## Personality & Motivations
- Projects an aura of **paranoia** and suspicion. Tries to appear nonchalant and in control, but is personally affected by recent assassinations — two victims were her own clan members, including her uncle. She is pragmatic and dismissive of superstition, insisting the "empty scabbard killers" are a children's fable being used as cover by some government agency. She guards information tightly, only sharing when pressed and convinced it's operationally necessary.

## History with the Party
- **Provided passes** to the party allowing them through gates that restrict non-Duergar access to the city.
- **Threatened** the party that she could set the Drow on them (likely as leverage to ensure compliance).
- **Met with Grygum** to task him with investigating the "empty scabbard killers" — mysterious assassins whose existence she publicly denies. Bodies have been found with puzzling wounds that her underlings cannot explain.
- When Grygum insisted on more information, she reluctantly brought in her subordinate **Grimholl Forgebrand** to brief him further.
- Revealed that **two of the victims were her own clan members**, including her uncle, making this personal despite her dismissive facade.

## Current Status
- **Location:** Duergar city (likely Stone Guard headquarters)
- **Active operations:** Investigating the "empty scabbard killers" through Grygum; also **searching for Droki**, who the Keepers of the Flame have independently identified as a **Gray Ghosts agent**.
- **What the party knows:** She is their patron for the empty scabbard killer investigation; she is also looking for Droki; she has authority over their city access and could revoke it or weaponize the Drow against them.
- **Hidden:** The depth of her personal stake (uncle killed) may not be fully appreciated by all party members; her true beliefs about who is behind the killings remain unclear.

## Relationships
- **Grygum** — Hired him as an investigator; relationship appears transactional but she trusts him enough to share sensitive information when pressed.
- **Grimholl Forgebrand** — Her subordinate, brought in to assist with briefing Grygum.
- **The Party** — Grudging patron; granted them access but maintains leverage through threats. Appeared disappointed during her meeting, suggesting the party or Grygum may not be meeting her expectations.
- **Keepers of the Flame** — Parallel interest in Droki, though the nature of any direct relationship is unknown.
- **Gray Ghosts** — Adversarial; seeking their agent Droki.
