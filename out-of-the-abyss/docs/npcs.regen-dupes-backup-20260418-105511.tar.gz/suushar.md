---
name: Suushar
aliases: []
---

# Suushar the Awakened

## Identity
- Kuo-toa; self-styled spiritual seeker
- Fellow prisoner/escapee traveling with the party
- Aligned with the worship of the Sea Mother; reverent toward Archpriest Ploopploopeen of Sloopbludop

## Personality & Motivations
- Seeks spiritual enlightenment and an end to the kuo-toa's collective madness. Genuinely devout in his admiration for the Sea Mother and her followers.
- Calm, earnest, and somewhat naïve—he was genuinely confused when Grygum called "Ploopploopeen" a tongue twister, and cheerfully repeated the name multiple times to demonstrate its simplicity. Tends toward a peaceful, philosophical outlook (argued that leaving corpses to scavengers was pragmatic and untraceable).

## History with the Party
- **Thorin's Madness:** Witnessed Thorin suffering a bout of madness and recommended seeking help from Archpriest Ploopploopeen in Sloopbludop, believing the archpriest could cure such afflictions.
- **Corpse Disposal Debate:** Contributed practical reasoning, arguing that trackers wouldn't be able to distinguish natural scavenging from deliberate activity.
- **Travel Plans:** Stated clearly that his destination is Sloopbludop and he has no interest in traveling beyond it. Offered potential help navigating the Darklake.
- **Influence on Buppido:** Buppido later claimed that Suushar helped him realize he was mad, suggesting Suushar had a meaningful calming or grounding effect on the volatile derro—though this came from Buppido during a desperate plea, so its reliability is uncertain.

## Current Status
- Last known status: traveling with the party toward Sloopbludop
- Intends to part ways with the group upon arrival there
- May assist with Darklake travel if persuaded

## Relationships
- **Archpriest Ploopploopeen:** Deep reverence; considers him a spiritual authority and potential source of healing
- **Buppido:** Apparently had some positive influence on the derro; Buppido credits Suushar with helping him recognize his own madness
- **Thorin:** Showed concern for Thorin's mental state and actively tried to help by suggesting a remedy
- **Grygum:** Brief lighthearted exchange over the pronunciation of Ploopploopeen's name
