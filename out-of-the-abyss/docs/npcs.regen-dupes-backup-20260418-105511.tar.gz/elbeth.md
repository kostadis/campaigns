---
name: Elbeth
aliases: []
---

# Elbeth

## Identity
- Armed companion/follower traveling with a group that includes Rust
- First appeared in the Derro slums during the party's activities there

## Personality & Motivations
- Follows orders from Rust without apparent resistance, suggesting a subordinate role or loyalty to Rust's leadership.
- Limited information available; personality traits not yet demonstrated beyond compliance.

## History with the Party
- Encountered traveling through the Derro slums as part of an armed group.
- Was ordered by Rust to stay outside the assassin's lair; she complied.
- Continued traveling with the group after the lair encounter.

## Current Status
- **Last known location:** Derro slums, traveling with Rust's armed group.
- **Active plans:** Unknown; appears to be following the group's broader objectives.
- **Hidden information:** Nearly everything about Elbeth remains unknown — her background, personal goals, and capabilities have not been revealed.

## Relationships
- **Rust:** Takes orders from Rust; likely a subordinate or trusted associate.
- **Armed companions:** Part of the same traveling group; exact dynamics unclear.
- **The Party:** Minimal direct interaction so far.
