---
name: Jimjar (Jim Jir)
aliases: []
---

# Jimjar (Jim Jir)

## Identity
- Fellow prisoner and escapee
- First appeared during the group's captivity; was among the prisoners herded toward a sacrificial depression before the escape

## Personality & Motivations
- Compulsive gambler — makes bets even in life-or-death situations. During the march toward the sacrificial depression, he offered a bet on how many escapees would survive. His flippant attitude in dire circumstances suggests either deep fatalism or a coping mechanism. His gambling nature has already raised suspicions about his trustworthiness (Grygum wondered if Jimjar would let someone die to avoid losing a bet).

## History with the Party
- **Escape Session:** Imprisoned alongside the party and other captives. As the group was herded toward a sacrificial depression, Jimjar proposed a bet on survivor count. After the battle broke out and all escapees survived, he noted "We all made it alive." Fled with the group toward the docks.

## Current Status
- **Last known location:** En route to / at the docks, fleeing with the escapee group
- **Active plans:** Survival and escape alongside the party
- **Hidden vs. known:** The party has noted his gambling compulsion; Grygum already harbors suspicion about whether Jimjar's bets might influence his loyalties or willingness to help others survive

## Relationships
- **Grygum (PC):** Distrustful — Grygum suspects Jimjar might cheat on bets or let someone die to win one
- **Other escapees:** Traveling companion; no deeper bonds evident yet

## Arc Score Events
None recorded yet.
