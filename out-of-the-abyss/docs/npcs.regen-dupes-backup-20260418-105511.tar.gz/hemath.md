---
name: Hemath
aliases: []
---

# Hemath

## Identity
- Duergar arms dealer
- First encountered as a sacrificial captive at the kuo-toa altar

## Personality & Motivations
- Core drive: survival above all else
- Pragmatic and transactional — immediately offers future contact in Gracklstugh in exchange for rescue. Carries the innate cultural cynicism of the duergar, but his desperation overrides it. Willing to cooperate with unlikely allies when his life is on the line.

## History with the Party
- **Kuo-toa Altar Encounter:** Found bloodied and bound among sacrificial captives. Had been dealing weapons to Bloppblippodd, Archpriest of the Deep Father, but she double-crossed him — declaring his sacrifice would be "weapon enough." Pleaded with Grygum for help. Grygum told him cryptically, "there's more than meets the eye," which surprised and comforted him. He agreed to act on the party's signal and asked them to find him in Gracklstugh if they all survived.

## Current Status
- **Last known location:** Among the captives at the kuo-toa altar when battle broke out
- **Fate unknown** — it is unclear whether he escaped, was killed, or was recaptured during the fighting
- **Standing offer:** Told the party to find him in Gracklstugh, implying he has resources and connections there
- **Hidden info:** The full extent of his arms dealing network and his standing in Gracklstugh are unknown to the party

## Relationships
- **Grygum (party member):** Primary point of contact; Hemath placed his trust in Grygum after the cryptic reassurance
- **Bloppblippodd (Archpriest of the Deep Father):** Former business partner turned betrayer; she reneged on their weapons deal and marked him for sacrifice
- **Gracklstugh (faction/city):** Has a base of operations or at minimum business contacts there

## Arc Score Events
- None explicitly noted.
