---
name: Errde Blackskull
aliases: []
---

# Errde Blackskull

## Identity
- Captain of the Stone Guards, Gracklstugh
- Based at Overlake Hold
- First approached the party at the Darklake Brewery with a squad of stone-weapon-bearing Duergar, inviting them to her office

## Personality & Motivations
- Core goal: expose what she believes is deep corruption in the Deepking's court, linked to the Council of Savants and possibly the Clan Lairds. She sees this as her path to the Deepking's favor.
- Pragmatic and calculated — willing to use outsiders for tasks her guards cannot openly perform. Pairs hospitality (pastries, warm drinks) with veiled threats. Smiled when challenged by Daz rather than escalating, suggesting confidence and political savvy.

## History with the Party
1. **Darklake Brewery**: Approached the party with Stone Guards and invited them to Overlake Hold. When Daz questioned whether it was a threat, she defused the tension with a smile.
2. **Overlake Hold Meeting**: Served refreshments, then laid out her request — track down a Duergar named **Droki** in the West Cleft District (Derro territory). She cannot send Stone Guards in force without provoking violence, hence the need for outsiders. Offered **175gp in armory equipment upfront**, with **175gp more** upon delivery of Droki and proof of corruption. Validated the party's own observations of rule-breaking at the Blade Bazaar. Made a veiled but powerful offer: she can misdirect any Drow searching for escaped slaves, effectively guaranteeing the party's freedom.
3. **Party's avoidance**: Despite the deal, the party grew wary of Errde. They feared imprisonment and torture if she turned on them, and deliberately chose **Gartokkar** as their escape route from the city to avoid her.

## Current Status
- **Last known location**: Overlake Hold, Gracklstugh
- **Active operations**: Hunting Droki and pursuing her corruption investigation
- **What the party knows**: She wants Droki, believes the court is corrupt, and has leverage over their safety from Drow pursuers
- **What remains hidden**: According to intercepted letters from **Aliinka** and **Narrak**, Errde is "hunting phantoms" — her conspiracy theories are real enough in spirit but she is unwittingly aiding a **cult's efforts to sow discord** in Gracklstugh. She does not appear to know she is being manipulated.

## Relationships
- **The Party**: Transactional alliance; she holds leverage (Drow misdirection) but the party distrusts her and is actively avoiding her
- **Daz**: Challenged her directly at their first meeting; she responded with amusement rather than hostility
- **Droki**: Her primary target; believes he is the key to unraveling the conspiracy
- **The Deepking**: Loyal; seeks his favor through exposing corruption
- **Council of Savants / Clan Lairds**: Suspects corruption among them
- **Aliinka & Narrak (cult-affiliated)**: View her as a useful fool — her investigations inadvertently serve their goals of destabilizing Gracklstugh
- **Gartokkar**: Indirect relationship — the party chose him over Errde as their faction contact for leaving the city

## Arc Score Events
- No explicit arc score changes noted, but the party's deliberate decision to avoid her and route through Gartokkar suggests a decrease in trust/alliance trajectory.
