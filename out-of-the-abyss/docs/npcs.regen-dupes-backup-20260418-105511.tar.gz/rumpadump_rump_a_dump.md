---
name: Rumpadump (Rump-a-dump)
aliases: []
---

# Rumpadump (Rump-a-dump)

## Identity
- Myconid child; wishes to return to the Neverlight Grove
- Companion/charge of the party alongside Stool

## Personality & Motivations
- Core goal: Return to the Neverlight Grove and reunite with his sovereign and the myconid circle.
- Displays a child's unwavering faith in his home and leaders. Refuses to believe the circle could be corrupted, insisting his sovereign would never allow it. Naïve and earnest.

## History with the Party
- Traveled with the party alongside Stool, both seeking passage to the Neverlight Grove.
- When Zalthir warned the group that a very dangerous and mighty demon was present at the Neverlight Grove, Rumpadump adamantly denied any possibility of corruption, declaring, "The circle cannot be corrupted. Our sovereign would never let that happen."
- Zalthir chose not to press the issue further, recognizing that Rumpadump is a child.

## Current Status
- **Last known status:** Traveling with the party, intent on reaching the Neverlight Grove.
- **What the party knows:** Zalthir has warned that a powerful demon is at the Neverlight Grove. Rumpadump is in denial about any threat to his home.
- **Hidden information:** The true state of the Neverlight Grove and its sovereign remains unconfirmed by the party firsthand.

## Relationships
- **Stool:** Fellow myconid child and travel companion; both share the same destination.
- **Zalthir:** Tried to warn Rumpadump about the danger at Neverlight Grove but ultimately held back out of sympathy for his youth.
- **The Party:** A dependent/charge; the party is escorting him toward his desired destination.
