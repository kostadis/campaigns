---
name: Serith
aliases: []
---

# Serith

## Identity
- Drow defector; former member of the Drow forces at the prison outpost
- Joined the prisoners before the escape attempt; first appeared during the pre-escape planning phase when he identified Imbros as an elite Drow fighter

## Personality & Motivations
- Driven by a mysterious, possibly supernatural compulsion toward the Neverlight Grove — the same force that drew him to the dancing Myconids in the Whorlestone Caverns. He is insistent and single-minded about reaching it.
- Emotionally volatile: the death of Prince Derendil nearly caused him to break down screaming in the middle of combat, suggesting deep attachments and fragile composure under stress. Capable of channeling rage into decisive violence when redirected, as shown when he delivered the killing blow to Imbros.

## History with the Party
1. **Prison Escape** — Provided intelligence on Imbros before the breakout. During the battle, descended armed from the armory and attacked a Drow guard, cursing him in Drow fashion. After Prince Derendil was killed by Imbros, Serith nearly lost control and screamed. Grygum telepathically calmed him by redirecting his rage toward spirituality. Serith, confused but steadied, then killed Imbros with his sword.
2. **Kuo-toa Civil War** — Fled with the rest of the group during the chaos, running toward Grygum.
3. **Journey to Neverlight Grove** — Insisted the party must go to the Neverlight Grove. On the fourth day of travel, announced they must disembark and proceed on foot, explaining the route passes the Lost Tomb of Khaem. When a mysterious feminine voice led the party toward the tomb and Zalthir questioned the direction, Serith confirmed with a nod that it was indeed the correct path.

## Current Status
- Traveling on foot with the party through the Underdark, guiding them toward the Neverlight Grove via the Lost Tomb of Khaem
- His compulsion toward the Neverlight Grove remains unexplained; the connection to the dancing Myconids in Whorlestone Caverns is unresolved
- **Hidden:** The nature and source of his compulsion; his full backstory regarding his fall from grace and punishment among the Drow (referenced obliquely by Imbros's fear of suffering "precisely like Serith's" fate at Ilvara's hands)

## Relationships
- **Grygum** — Grygum telepathically intervened to calm Serith during his breakdown; Serith ran toward Grygum during the kuo-toa escape. There appears to be trust or dependence.
- **Prince Derendil** — Serith was deeply affected by Derendil's death, suggesting a meaningful bond.
- **Imbros (deceased)** — Former Drow comrade turned enemy. Imbros feared suffering a fate like Serith's at Ilvara's hands. Serith killed him.
- **Ilvara** — Implied to have punished or disgraced Serith in some significant way; details unknown.
- **Zalthir** — Some battlefield coordination during the escape; Zalthir also queries Serith for navigation confirmation, suggesting the party treats him as a guide.

## Arc Score Events
- **Prince Derendil's death** — Triggered an extreme emotional reaction; Grygum's telepathic intervention redirected his spiral. Direction of any arc change unclear, but a pivotal character moment.
