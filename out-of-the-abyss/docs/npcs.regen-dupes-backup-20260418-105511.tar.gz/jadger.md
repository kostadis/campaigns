---
name: Jadger
aliases: []
---

# Jadger

## Identity
- **Role / Title:** Burrow Warden of Blingdenstone
- **Faction:** Blingdenstone deep gnome community
- **First appearance:** Assigned the party a mission to deal with the ghost problem in the catacombs

## Personality & Motivations
- Dedicated to the defense and restoration of Blingdenstone, continuing his service even in death. Cheerful and pragmatic to the point of dark humor—casually noted that if the party died on the mission, they could still fight as ghosts via resurrection magic. Grateful and fair, offering meaningful rewards for service rendered.

## History with the Party
1. **Ghost Mission Assignment:** As Burrow Warden, Jadger assigned a group including Glabbagool, Eldeth, Jimjar, and Spiderbait to address the ghost problem in Blingdenstone's catacombs. He specifically requested the rescue of certain ghosts, including Udhask.
2. **Post-Mission Thanks:** After the party put two tormented spirits to rest in the catacombs, Jadger materialized as a friendly ghost to personally thank them. He offered two boons—any two questions he would answer truthfully—as a reward for their service.

## Current Status
- **Last known location:** The Ruby and the Rough temple in Blingdenstone
- **Current activity:** Training the next generation of Burrow Wardens (as a ghost)
- **Active offers:** The party still has **two truthful questions** they can claim from Jadger at the temple
- **Hidden information:** None indicated beyond whatever knowledge he possesses that the questions might unlock

## Relationships
- **Blingdenstone community:** Respected leader and defender, continuing to serve even after death
- **Udhask:** A ghost Jadger specifically wanted rescued from torment
- **The Party (Glabbagool, Eldeth, Jimjar, Spiderbait):** Views them favorably as allies who served Blingdenstone well; indebted to them

## Arc Score Events
- **Increase:** Party successfully put two tormented spirits to rest in the catacombs, earning Jadger's gratitude and the two-question boon reward.
