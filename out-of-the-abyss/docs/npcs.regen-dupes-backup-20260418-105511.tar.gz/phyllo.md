---
name: Phyllo
aliases: []
---

# Phyllo

## Identity
- Myconid Sovereign of Neverlight Grove
- Allied with Zuggtmoy (referred to by Phyllo as "the Great Seeder")
- Encountered by the party during their visit to the Inner Circle of Neverlight Grove

## Personality & Motivations
- Devoted to Zuggtmoy's vision for transforming Neverlight Grove; genuinely believes the changes will bring happiness to all myconids. Shows a zealot's sincerity rather than malice — pleading with Basidia not to leave rather than resorting to violence. Emotionally attached to the other myconids despite the betrayal.

## History with the Party
- Had secretly planned for the party to be killed the following day during their visit to Neverlight Grove.
- When the party returned to the Inner Circle acting nonchalant, Phyllo greeted Basidia and asked if the visitors had enjoyed seeing the circle and what they thought of "the changes."
- After Basidia accused Phyllo of betrayal, Phyllo did **not** attack the fleeing party.
- Instead, Phyllo pleaded with Basidia: *"The Neverlight Grove will be better than ever! And the Great Seeder will make us all happy!"* and called out plaintively, *"Basidia don't go."*

## Current Status
- **Location:** Neverlight Grove
- **Status:** Still allied with Zuggtmoy; remains sovereign of the corrupted grove
- **Hidden info:** The party likely knows Phyllo planned to have them killed and is allied with Zuggtmoy, given Basidia's accusation and the confrontation

## Relationships
- **Basidia:** Fellow myconid sovereign; Phyllo clearly cares about Basidia and was distressed by their departure, despite standing on opposite sides of the Zuggtmoy alliance
- **Zuggtmoy ("the Great Seeder"):** Phyllo's patron and the source of the corruption spreading through Neverlight Grove; Phyllo is a true believer
- **The Party:** Hostile by intent (planned their deaths) but did not act violently when the party fled
