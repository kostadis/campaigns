---
name: Yuk-Yuk
aliases: []
---

# Yuk-Yuk

## Identity
- Goblin hired companion
- Recruited alongside fellow goblin Spiderbait to accompany the party into the Silken Tunnels and the Underdark
- Convinced to join by Jimjar for a promised payment of 20 gold

## Personality & Motivations
- Motivated primarily by coin—agreed to venture into dangerous territory for 20 gold. No further personality details recorded beyond his willingness to follow the party into peril.

## History with the Party
- **Recruitment:** Jimjar convinced Yuk-Yuk and Spiderbait to join the group for 20 gold, heading into the Silken Tunnels.
- **Travel:** Accompanied the party through the Silken Tunnels and into the Underdark.
- **Murder (1st day, 3rd Tenday of Taraskh 1493):** Found dead during a rest period. His throat had been cut with a shortsword while the group slept. Spiderbait discovered the body and was screaming. Grygum observed that any member of the group could have been the killer.

## Current Status
- **Dead.** Murdered in his sleep.
- The killer has not been identified. Grygum noted that anyone in the group could be responsible.
- The murder weapon was a shortsword—this detail may help narrow suspects if investigated further.

## Relationships
- **Spiderbait:** Fellow goblin companion; discovered Yuk-Yuk's body and was visibly distraught.
- **Jimjar:** Recruited Yuk-Yuk and Spiderbait into the group.
- **Grygum:** Commented on the murder, noting the lack of a clear suspect.

## Arc Score Events
- None recorded.
