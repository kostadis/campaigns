---
name: Jimjar (also "Jim Jar")
aliases: []
---

# Jimjar

## Identity
- Deep gnome (svirfneblin) NPC, fellow escapee/companion
- Part of the group fleeing from drow captivity

## Personality & Motivations
- Compulsive gambler — constantly tries to make bets with the party over trivial outcomes, even during dangerous situations. Complained about a lost betting opportunity when the group fled instead of foraging.
- Dismissive and opinionated. Quick to belittle others' concerns, particularly Shuushar's unease about the Faerzess. Bluntly called Kuo-Toa insane while backhanding them with the observation that their madness "seems reasonable."
- Projects confidence in his own knowledge, whether or not it's fully accurate.

## History with the Party
- Fled alongside the party during their escape from drow captors.
- During the flight, complained that Zalthir's insistence on running ruined his planned wager about foraging.
- When Shuushar voiced discomfort about the Faerzress, Jimjar dismissed the concern outright, claiming Faerzress has never affected a living thing and that its only magical property is blocking teleportation spells.

## Current Status
- Last known: traveling with the party, on the run from drow pursuers.
- No independent plans noted beyond his habitual gambling.
- **What the party knows:** His claim that Faerzress is harmless to living creatures and only disrupts teleportation. *(GM note: verify whether this is accurate or if Jimjar is confidently wrong — could matter later.)*

## Relationships
- **Zalthir:** Mild friction — blamed Zalthir for cutting short a betting opportunity by insisting the group flee.
- **Shuushar:** Dismissive. Mocked Shuushar's Kuo-Toa nature and brushed off his instinctive concerns about the Faerzress.
- **Party at large:** Sociable but self-serving; treats companions primarily as betting partners.
