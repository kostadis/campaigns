---
name: Ilvara Mizzrym
aliases:
  - Ilvara
---

# Ilvara Mizzrym

## Identity
High Priestess of House Mizzrym, originally serving Lolth as commander of the Velkynvelve Drow outpost. By her final battle, she had become a corrupted vessel of the demon lord Zuggtmoy, described as Zuggtmoy's work "walking around in a drow priestess's bones." *Also known as: Ilvara.*

## Personality & Motivations
- Haughty, arrogant, well-dressed, and coiffed — she "fits the type" of a Drow priestess, though Thorin observed something manic about her, noting she appears "a bit crazy" compared to the typically calculating Drow
- Threatens prisoners with excruciating, graphic detail and rules through fear
- Initially driven by need to recapture escaped prisoners to fulfill a promise that they would arrive in Menzoberranzan (likely involving money), with the destruction of Velkynvelve compounding her desperation — failure risked her becoming a Drider
- Ultimately wholly devoted to Zuggtmoy's vision, seduced by the "bride heresy" that Lolth wishes to be married
- Muttered prophecy about "the bride" and "the chaos and mayhem to come" throughout the fight — delivered not as threats but as sincere belief in a future she had already accepted
- Tactically sharp even while wounded, reshaping the battlefield and countering threats with precision
- Never begged or offered surrender

## History with the Party
1. **Velkynvelve (arrival):** Received the party as prisoners from Welnaste Mizzrym, ordered Jorlan to take them to the cell, stating "We will use them until the caravan arrives."
2. **Priestess's Tower:** Forced prisoners to carry water and fill her bath. Threatened Prince Derendil with a knife when he objected. Her quarters contained the party's confiscated equipment in a zurkhwood chest.
3. **Prisoner Revolt:** Did not appear directly but her authority drove Imbros to fight desperately, fearing punishment like Serith's.
4. **Escape:** The party chose to abandon their gear in her quarters rather than risk recapture. Sarith warned she would be "honor bound to pursue" them.
5. **Underdark Pursuit:** Commanded the Drow pursuit from Velkynvelve. Sent Xinaya's squad to capture the party alive so she could kill them herself; believed the party would seek refuge at Neverlight Grove.
6. **The Fungal Cavern Battle (Final Encounter):** Found on an elevated platform in the cavern above the heart fungus at the center of Velkynvelve's fungal infestation, visibly altered by fungal growth, preoccupied with a mushroom artifact from Neverlight Grove. **Zalthir** opened the fight aggressively — grappled her with his Eldritch Claw Tattoo, dragged her forty feet into the air, landed two critical hits (31 total damage), and dropped her to the stone floor. She responded with a legendary reaction fear effect (DC-14 Wisdom save), frightening Zalthir and neutralizing his close-range combat kit for a full round. She also screamed in fury and dissolved into the fungal floor, reforming elsewhere. Cast **Insect Plague** at the cavern entrance, instantly killing her own fungal minions (thirteen HP each) and dealing twenty-six damage to **Glabbagool**. **Daz** hit her with a shaped Fireball for 24 damage (half-saved), which also set her mushroom icon smoldering. Called down divine fire on **Daz** and **Nym Duskryn**; conjured fungal growth to reshape the battlefield; summoned four spore servants during the fight. When **Thorin** destroyed the bridge beneath her, she leapt clear and survived the fall. **Jorlan Duskryn** charged her through the insect swarm, screaming her name — their broken romantic history driving his fury. They traded blows on the cavern floor. **Grygum's Guiding Bolt** killed her. Upon death, her body erupted in a massive cloud of poisonous spores, catching Zalthir and Thorin in the blast. She was still muttering prophecy when she died.

## Current Status
**Dead.** Her body erupted into poisonous spores upon death — nothing of her remained. Her death confirmed the totality of Zuggtmoy's corruption; she had ceased to be a person long before the fight. Her prophecies about Zuggtmoy, "the bride," and coming chaos remain unresolved — the party has heard these warnings but their meaning is not yet clear.

## Relationships
- **Zuggtmoy:** Ilvara was fully consumed by the demon lord's influence, serving as a vessel rather than an ally. Her death released demonic corruption as biology (spores), not identity.
- **Jorlan Duskryn:** Former romantic partner/consort, dropped after his disfigurement (acid scarring, lost finger). His resentment drove him to help the prisoners escape — a direct betrayal. He charged her in a rage during the final fight — their history was deeply personal and violent.
- **Shoor:** Current consort who replaced Jorlan.
- **Welnaste Mizzrym:** House sister who delivered the prisoners to her.
- **Imbros:** Subordinate at Velkynvelve, terrified of her punishments.
- **Sarith:** Former prisoner/guard who understands her psychology and warned the party about her pursuit.
- **Xinaya:** Subordinate sent to capture the party on her orders.
- **Asha Vandry:** Described Ilvara's corruption; called her "seduced by this abomination."
- **Nym Duskryn:** Targeted by Ilvara's divine fire during the battle; relationship unclear beyond combat hostility.
- **Zalthir:** Their exchange was the mechanical centerpiece of the fight — his devastating opening assault met by her devastating counter (Frightened condition neutralizing a melee monk). She views him as a genuine threat (screamed in fury when wounded).
- **Daz:** Understands her motivations deeply; dealt significant damage to her and her icon with Fireball.
- **Grygum:** Landed the killing blow from range; noted he was glad to have been standing back when the spore cloud erupted.
- **Thorin:** Destroyed the bridge beneath her; caught in her death spores.
- **Glabbagool:** Took heavy damage from her Insect Plague.

## Arc Score Events
No explicit arc score changes noted in the source material.
