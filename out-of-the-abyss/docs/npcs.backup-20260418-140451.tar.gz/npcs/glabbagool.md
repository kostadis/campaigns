---
name: Glabbagool
aliases:
  - Glabagool
---

# Glabbagool

## Identity
- Sentient gelatinous cube (now in ooze form after a body-swap with the Pudding King); companion and unofficial member of the Ember Vanguard
- His sentience is connected to the rampaging chaotic sentience phenomenon in the Underdark, tied to Juiblex's influence
- *Also known as: Glabagool.*

## Personality & Motivations
- Core desire is friendship, purpose, and belonging — when asked what he wanted as payment, he revealed he just wanted friends and to feel needed
- Endlessly curious, cheerful, and earnest to the point of comedy; he narrates his own actions, plays games with animated statues, gets drunk cleaning tavern floors, and sings terrible sea shanties
- Fiercely proud of being a cube (not an ooze), correcting anyone who conflates the two species, citing his "higher viscosity" and ability to maintain a square shape
- Eager to be useful — cleaning floors, clearing rubble, scouting dangerous objects — earning the affectionate nickname "Roomba"
- Uniquely sentient and capable of speech — abilities it gained after an unknown event it cannot fully explain; curious and communicative, willing to speak aloud to strangers

## History with the Party
1. **Oozing Temple**: Discovered with newfound sentience. Thorin invited him to join; he accepted and received a lucky foot as a welcome gift. Blocked a narrow passage with his body, volunteered to touch mysterious sculptures (triggering gray oozes), cleaned up the remains, and found a hidden treasure cache in a fountain (112 sp, 3 gp, a drow dagger, oil of slipperiness). Confirmed he didn't need to breathe during flooding. Agreed to allow resurrection attempts before consuming any fallen party members.
2. **Blingdenstone Arrival**: Accompanied the party to the gates, where his presence caused deep gnome guards to panic, confirming the city's ooze crisis. The party vouched for him, explaining he was friendly and had helped them during their journey. He spoke aloud to the guards, astonishing them, and shared observations about an unusual increase in agitated oozes in the area, coining the term "oozapalooza." Guards flagged his presence as a concern and directed the party to seek full permissions from Chief Dorbo Diggermattock and Quartermaster Senni.
3. **Blingdenstone Exploration**: Corrected anyone calling him an ooze. Expressed confusion about why his "fat friends" (oozes) were hurting gnomes. Asked to stay upstairs at the Temple of the Ruby in the Rough to avoid accidents.
4. **Trader's Grotto Attack**: When mindless gelatinous cubes attacked the market, protested they were giving intelligent cubes a bad name. Provided tactical advice on avoiding engulfment. Was fascinated by Zalthir's eldritch claw tentacles, asking if he was an ooze; satisfied when Zalthir called himself "an aspiring ooze."
5. **Rubble Clearing & Ooze Trail**: Eagerly accepted a job clearing a rubble passageway, impressing a gnome miner. Began hearing voices calling him south toward the oozes. Zalthir persuaded him to stay with the group by appealing to friendship. Led the party to the Pudding King's cavern, expressing discomfort that oozes were speaking.
6. **Blingdenstone Tasks**: Cleaned Chief Dorbo's kitchen floor (earning "Roomba" nickname). Assigned to assist Barrow Warden ghosts with Eldeth, Jimjar, and Spiderbait. Got drunk on spilled tavern alcohol. Cleared mushroom cultivation caves "like a gigantic transparent snowblower." Confused gargoyles by approaching them as a friendly cube with googly eyes.
7. **Animated Drow Statues**: Amused himself by repeatedly entering and exiting the room to watch statues animate and go still.
8. **Medusa's Lair**: Expressed delight at tasting the Medusa's remains; cheerfully cleaned up the aftermath.
9. **Pudding King Battle**: Offered to let the party pass through him to bypass an ochre jelly barricade (though it would cause acid/oxygen damage). Promised he would never hurt his friends despite the Pudding King's potential influence. During the throne room fight, Zalthir dragged the Pudding King through Glabbagool ("this tickles"). A body-swap occurred — Glabbagool ended up in ooze form, the Pudding King became a cube. Thorin confirmed his identity by asking where they first met. After victory, Glabbagool was cheerful about his new ooze form, noting it was more convenient — the party could carry him in a jar or Bag of Holding. Monk training was discussed to help him control his acidity.
10. **Ooze Crisis Resolution (Trader's Grotto)**: When Jimjar tossed his mysterious bone die onto Glabbagool, he became a telepathic bridge connecting every ooze in the cavern. He gently told them the world was fine and there was no need to kill anyone. The oozes went peaceful and dispersed. He described briefly being part of one vast ooze mind.
11. **Asha Vandree Deception**: Attempted to disguise himself as a rock on Daz's orders; failed almost immediately by narrating his own invisibility and tracking the conversation with wandering eyes. Asha accepted him as Daz's "bound familiar," which actually reinforced Daz's credibility as a powerful mage. Grygum felt Glabbagool deserved compensation for the indignity; Glabbagool didn't mind.
12. **Ilvara Battle**: Caught in Ilvara's Insect Plague, taking 26 points of damage; described as "churning and trembling." Grygum's first priority was checking on him. Daz carefully sculpted his Fireball to exclude Glabbagool from the blast.

## Current Status
- **Form**: Now an ooze rather than a gelatinous cube (post-body-swap with the Pudding King)
- **Last seen**: With the party after the Ilvara battle; traveling as a companion
- **Active plans**: Party has discussed monk training to teach him to control his form and acidity; he has expressed eagerness to travel in a jar or Bag of Holding for convenience
- **Hidden concerns**: The Pudding King's voice previously had some pull on him (he heard it calling from the south, near the slime pool). Whether any residual influence remains after the body-swap is unknown to the party.

## Relationships
- **Thorin**: First to invite him into the party; gave him a lucky foot. Thorin tested his identity during the body-swap with a personal question.
- **Zalthir**: Close bond. Zalthir persuaded him to resist the Pudding King's call by appealing to friendship. Glabbagool was fascinated by Zalthir's tentacles. Zalthir mentally noted Glabbagool should learn to control his acidity (monk training idea).
- **Grygum**: Protective of Glabbagool; first to check on him after the Insect Plague. Suggested using him for rubble-clearing. Felt he deserved compensation for the familiar ruse.
- **Daz**: Daz protects him in combat (sculpted Fireball around him). Used him in the Asha Vandree deception as a "familiar," which Glabbagool didn't mind. Daz privately acknowledged Glabbagool's presence helped sell his credibility.
- **Jimjar**: Assigned together for the ghost mission. Jimjar's bone die triggered Glabbagool's telepathic ooze-network event.
- **Eldeth & Spiderbait**: Partnered for the Barrow Warden ghost quest.
- **Blingdenstone Deep Gnomes**: Source of tension and suspicion, though one miner expressed interest in hiring him for work after seeing his rubble-clearing abilities.
- **The Pudding King**: Adversary. The Pudding King's voice called to Glabbagool through the ooze network. They swapped bodies during the final battle. The Pudding King was defeated.
- **Asha Vandree**: Accepted him as Daz's bound familiar; views him as evidence of Daz's magical power.
- **Chief Dorbo Diggermattock & Quartermaster Senni**: Required their approval for his continued presence in Blingdenstone.

## Arc Score Events
- **Increase**: Joined the party willingly and enthusiastically in the Oozing Temple; consistently demonstrated loyalty and usefulness (cleaning, scouting, rubble-clearing, combat support).
- **Increase**: Resisted the Pudding King's call when Zalthir appealed to friendship.
- **Increase**: Served as telepathic bridge to pacify all oozes in Blingdenstone, resolving the ooze crisis.
- **Potential risk (flagged)**: Previously susceptible to the Pudding King's voice; body-swap may have unknown consequences.
