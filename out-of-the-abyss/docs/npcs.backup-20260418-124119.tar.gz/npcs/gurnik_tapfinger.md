---
name: Gurnik Tapfinger
aliases: []
---

# Gurnik Tapfinger

## Identity
- Cleric affiliated with the Steadfast Stone temple faction
- First appeared at the grand moot, presenting alongside Nomi Pathshutter

## Personality & Motivations
- Core goal: Cleansing the Temple of the Steadfast Stone and restoring its guardians
- Passionate advocate for the temple's strategic value, continuing to push for the cleansing mission even when a simpler alternative (the northern attack route) was proposed by Daz. Comes across as prepared and earnest — he had a rehearsed presentation ready — but potentially stubborn or single-minded in his agenda.

## History with the Party
- **Grand Moot:** Delivered a detailed briefing on how to cleanse the Temple of the Steadfast Stone. Explained that a red spell gem containing a sanctification spell must be placed into a menhir at the temple, which would provoke Ogremoch's Bane into sending servants to attack. The party would need to defend the menhir until three temple guardians awakened. He and Nomi Pathshutter gave a rehearsed joint presentation extolling the benefits of Earth Elementals as battlefield allies. When Daz identified a simpler northern attack route, Gurnik doubled down on the temple plan, emphasizing the value of gaining Earth Elemental support.

## Current Status
- **Last known location:** The grand moot
- **Active plans:** Seeking party buy-in (or other allies) to cleanse the Temple of the Steadfast Stone
- **Known to the party:** Full mechanics of the temple cleansing ritual (red spell gem → menhir → defend against Ogremoch's Bane servants → three guardians awaken). The party also knows a simpler northern route exists as an alternative.
- **Hidden:** No hidden information noted in source material.

## Relationships
- **Nomi Pathshutter:** Collaborative partner; they rehearsed and co-presented the temple plan together at the moot.
- **Daz:** Mild tension — Daz proposed a simpler alternative route, which Gurnik pushed back against.
- **Ogremoch's Bane:** Adversarial; the cleansing ritual directly provokes this entity.

## Arc Score Events
No arc score events noted.
