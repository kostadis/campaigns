---
name: Werz
aliases: []
---

# Werz

## Identity
- Duergar merchant and deal-broker operating in Gracklstugh
- First referenced indirectly by a flumph who read the party's thoughts; met in person at the Shattered Spire tavern, built on a broken stalagmite jutting from the Darklake

## Personality & Motivations
- Core goal: survive his assassin problem and continue brokering deals — he insists he cares only about trade, not politics. He wants the assassins dealt with, preferably without his death.
- Pragmatic and transactional; pays debts promptly and deals in gems. Dismissive of conspiracy theories (calls the idea of an organized assassin's guild "a children's fable"), yet clearly nervous enough to hire outside help. Willing to share valuable political intelligence when it serves his interests.

## History with the Party
1. **Flumph encounter:** The flumph read the party's minds and referenced Werz as a duergar whom assassins wielding "a magical light blade" had tried to kill.
2. **Shattered Spire meeting:** Werz met the party at the tavern. Gave each party member (including the flumph) a gemstone worth 10 gp in gratitude for saving his life. Explained that assassins targeted him but that the Stone Guards would never believe him.
3. **Revealed his trade:** Admitted he brokers forbidden weapons deals between duergar clans, violating the Deepking's decree that only Clan Steelshadow may handle weapons orders.
4. **Offered a favor:** Proposed facilitating a weapons deal between the Deep Gnomes and the duergar clans, which would help the party reach Blingdenstone.
5. **Business with Daz:** Daz negotiated an NDA — started at 1,250 gp, settled at 1,100 gp for secrecy about their dealings. Daz separately charged him for the assassin removal job; Werz paid in gems later identified by Jimjar as empty spell gems valuable to Kazook Pickshine, an alchemist in Blingdenstone.
6. **Political briefing:** Shared intelligence on Gracklstugh's volatile political landscape (see Current Status).

## Current Status
- **Last known location:** Gracklstugh, presumably still operating as a merchant/broker.
- **Active plans:** Waiting on the party to resolve his assassin problem; facilitating the Deep Gnome–Duergar weapons deal.
- **Political intel shared with the party:**
  - Clan Ironshadow's leader will wait out the Deepking's madness, but other clan members are restless.
  - Clan Tharzgad complains about Grey Ghost raids.
  - Clan Xundom will support the Deepking in a war.
  - Stone Guards have recently started taking bribes — a new development coinciding with the Deepking's madness (last few months).
  - Werz warned the city is ready to explode; giving the wrong faction the wrong information could trigger all-out war.
- **Hidden from the party:** Nothing explicitly noted, though his claim of political neutrality ("only cares about trade") may warrant skepticism given his deep knowledge of factional dynamics.

## Relationships
- **The Party (general):** Transactional ally; grateful for saving his life, paying well for their services and silence.
- **Daz:** Primary negotiating counterpart; struck the NDA and assassin-removal deal.
- **Jimjar:** Identified Werz's gem payment as empty spell gems tied to Kazook Pickshine.
- **Kazook Pickshine (Blingdenstone alchemist):** Indirect connection — the spell gems Werz paid with are valuable to Kazook.
- **Clan Steelshadow:** Operates in violation of their monopoly on weapons orders.
- **Grey Ghosts:** His assassins may be connected to them (unconfirmed).
- **Stone Guards:** Distrusts them; believes they wouldn't take his claims seriously, and notes their recent corruption.

## Arc Score Events
- No explicit arc score changes noted in the source material.
