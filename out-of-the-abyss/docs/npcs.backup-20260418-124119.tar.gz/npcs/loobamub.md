---
name: Loobamub
aliases: []
---

# Loobamub

## Identity
- Myconid leader of the Circle of Hunters
- Follower of Basidia
- First encountered in Neverlight Grove when the party was asked to help deal with a Grick

## Personality & Motivations
- Loyal to Basidia and opposed to Phylo's control over reanimated creatures. Seeks to redirect useful dead creatures to Basidia rather than Phylo's Circle of Masters. Adheres strictly to the hunters' code — they retrieve the dead but do not kill. Pragmatic and willing to seek outside help to work around factional constraints.

## History with the Party
- Asked the party to hunt and kill a Grick, requesting they bring the corpse to Basidia for reanimation rather than allowing it to go to Phylo's Circle of Masters.
- Warned the party about a Shambling Mound concealed in nearby swampy ground.
- When questioned by Zalthir about why hunters weren't doing the hunting themselves, explained their philosophy: "We bring back the dead. We do not kill."
- Later gathered with Rusharoo and the circles of hunters and explorers near the exit hole to escape Neverlight Grove.
- Participated in a deep mind meld before departing the Grove with Basidia and Rusharoo.

## Current Status
- Left Neverlight Grove alongside Basidia and Rusharoo.
- Last known status: traveling with Basidia's faction after fleeing the Grove.
- Current location unknown beyond having escaped.

## Relationships
- **Basidia**: Leader and sovereign; Loobamub is a devoted follower.
- **Phylo**: Opposed; Loobamub works to circumvent Phylo's insistence that all dead creatures go to the Circle of Masters.
- **Rusharoo**: Fellow evacuee from Neverlight Grove; departed together.
- **Zalthir**: Directly interacted with; answered his questions about hunter philosophy.
- **The Party**: Sought their help as outside agents capable of killing, something the hunters refuse to do themselves.
