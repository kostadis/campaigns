---
name: Lingrick Xardelvar
aliases: []
---

# Lingrick Xardelvar

## Identity
- Described as the Deepking's "most gaseous ally"
- Named in a stolen contract found in Eldgrim's desk
- No faction affiliation confirmed beyond association with the Deepking

## Personality & Motivations
- Unknown directly; the contract entry describing Lingrick is notably enthusiastic, written with multiple exclamation marks, suggesting the author (Eldgrim or the Deepking) regards this ally with particular excitement or importance.

## History with the Party
- The party has not met Lingrick directly. They learned of this NPC solely through a contract stolen from Eldgrim's desk, where Lingrick is listed by name and described as the Deepking's "most gaseous ally."

## Current Status
- **Last known location:** Unknown
- **Active plans:** Unknown; involvement in whatever arrangement the stolen contract pertains to
- **What the party knows:** Only the name, the "most gaseous ally" descriptor, and the connection to the Deepking via Eldgrim's contract
- **What remains hidden:** Lingrick's nature (the "gaseous" descriptor could imply a gas-related creature, elemental, or something else entirely), location, role in the Deepking's plans, and the full context of the contract

## Relationships
- **The Deepking:** Allied; described as the Deepking's ally in a formal contract
- **Eldgrim:** Connected through the contract found on Eldgrim's desk
- **The Party:** No direct contact; the party is aware of Lingrick's existence through stolen documents only

## Arc Score Events
None recorded.
