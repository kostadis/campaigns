---
name: Dasco Pickshine
aliases: []
---

# Dasco Pickshine

## Identity
- Owner and operator of Pickshine Mine (self-branded as "Dasco Pickshine Mines")
- First encountered when the party arrived at his mine, where four massive Galeb Duhr were blocking the mining path

## Personality & Motivations
- Core goal: promote and expand his mining brand at every possible opportunity
- Dasco is a relentless self-promoter — every piece of his clothing and equipment bears his company logo, he offers "branded tea," and he personally sewed a Dasco Pickshine patch onto Daz's clothes. He takes a "holistic approach to marketing" his mining operation. Despite his bluster, he is pragmatic and resourceful, though grudging when it comes to parting with payment. He stood proudly beside the much taller dragonborn Daz after attaching the patch, clearly relishing the branding moment.

## History with the Party
1. **Galeb Duhr Blockage:** The party arrived at Pickshine Mine to find four ancient Galeb Duhr blocking the path. Dasco had tried everything to move them, including striking them with his pickaxe. Daz solved the problem by arranging resonant geodes and humming to complete the Galeb Duhr's ancient handshake protocol. Dasco grudgingly rewarded the party with two ruby gems worth 500 gp.
2. **Branding Encounter:** Dasco offered branded tea and promoted his mine's brand to the party. When they showed interest, he personally sewed a Dasco Pickshine patch onto Daz's clothes.
3. **Black Pudding Pit Bridge:** Dasco offered a practical solution to a twenty-foot black pudding pit — his miners could bridge it using mithril braces and salt neutralizers. The Pickshine Miners built the bridge in about twenty minutes while singing cheerful songs, though they had to remain behind to maintain it against acid and could not accompany the party to the Pudding King's doors.

## Current Status
- Last known: His miners were maintaining the mithril-and-salt bridge over the black pudding pit, holding the path open for the party
- The party proceeded ahead toward the Pudding King's doors without Dasco's miners as backup
- No hidden information noted

## Relationships
- **Daz (party member):** Particular rapport — Daz solved the Galeb Duhr puzzle and received a personally sewn brand patch from Dasco
- **Pickshine Miners:** Loyal crew; cheerful workers who follow Dasco's direction and sing while they work
- **The Party (general):** Transactional but positive; he paid them (grudgingly) and later provided critical logistical support with the bridge

## Arc Score Events
- **Galeb Duhr resolution:** Likely positive shift — the party solved his mine's blockage problem
- **Bridge construction cooperation:** Further positive collaboration, though the miners' inability to accompany the party forward may carry future consequences
