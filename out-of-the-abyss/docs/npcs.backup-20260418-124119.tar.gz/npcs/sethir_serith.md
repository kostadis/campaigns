---
name: Sethir (Serith)
aliases: []
---

# Sethir (Serith)

## Identity
- Guide / navigator for the party
- Knowledgeable about the Underdark, particularly the Darklake region and surrounding landmarks
- First appeared during the party's journey from Velkynvelve, helping chart their route forward

## Personality & Motivations
- Practical and goal-oriented; focused on getting the group where they need to go. Willing to share knowledge freely and collaborate with others (e.g., incorporating Buppido's suggestions into travel plans). Does not take kindly to having his competence questioned — glared at Thorin when the dwarf criticized his map.

## History with the Party
- Spoke with Fargas to learn the general location of the tomb of Brysis of Khaem on the eastern edge of the Darklake.
- Confirmed he could lead the group to the tomb.
- Drew a map using Ormu (collected by Zalthir), illustrating the route from Velkynvelve through the Silken Paths toward Sloobludop, also marking the Darklake, Gracklstugh, and the tomb's approximate location.
- Explained that the Darklake is not a conventional body of water but rather a "large water balloon" of intersecting caverns, caves, and tunnels.
- Agreed with Buppido's suggestion to visit Gracklstugh after Sloobludop, noting it as a large Derro city where they could acquire weapons and gear, and that the tomb is along the way.
- Estimated they were three days from Sloobludop.

## Current Status
- **Last known location:** Traveling with the party, en route to Sloobludop (approximately three days out).
- **Active plans:** Guiding the party along the route: Sloobludop → Gracklstugh → Tomb of Brysis of Khaem.
- **Known vs. hidden:** The party knows his navigation abilities and his knowledge of the Darklake region. No hidden information indicated in the notes.

## Relationships
- **Fargas:** Source of information about the tomb of Brysis of Khaem's location; Sethir consulted him directly.
- **Zalthir:** Provided the Ormu that Sethir used to draw the map.
- **Buppido:** Collaborative relationship; Sethir agreed with Buppido's suggestion about Gracklstugh.
- **Thorin:** Minor friction — Thorin criticized his map's accuracy, earning a glare from Sethir.
