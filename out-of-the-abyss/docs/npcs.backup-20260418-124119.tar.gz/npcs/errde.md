---
name: Errde
aliases: []
---

# Errde

## Identity
- Head of the Stone Guard in Gracklstugh
- Based at Overlake Hold (also referenced as Underlake Hold for arming the crew)
- First met when the party visited her at Overlake Hold to report on their investigation into the Grey Ghosts and the Council of Savants

## Personality & Motivations
- Core obsession: proving that the Grey Ghosts and the Council of Savants are working together to corrupt the Deepking and destabilize Gracklstugh. She seized on flimsy evidence (a Flumph's psychic testimony) as proof and had to be talked down by Daz.
- Deeply paranoid. She is pretending not to believe that assassins (the Empty Scabbard Killers) targeted her clan/family, but privately craves proof of it.
- Wants the destruction of the Derro, whom she scapegoats for the city's problems. Daz privately assessed her as a paranoid leader blinding herself with conviction, blaming a helpless group for everything broken.
- Politically calculating — she cannot enter the Whorlestone Caves herself without triggering an inter-clan war that would expose her incompetence as city guardian, so she uses the party as deniable assets.

## History with the Party
1. **Initial engagement:** Agreed to employ the party to investigate the Grey Ghosts, Council of Savants, and Droki's involvement. Offered weapons in exchange for cooperation.
2. **Overlake Hold briefing:** Received the party's report and immediately overinterpreted the Flumph testimony. Daz talked her down but she demanded they return for concrete evidence — specifically papers they failed to retrieve. Refused to send Duergar troops into the Derro slums but offered to arm the party's crew instead. Pressured them on timeline.
3. **Cover plan:** Approved Daz's plan to have the party publicly engage with Clan Ironhead and Clan Xardelva to create plausible deniability, so their cave entry wouldn't be traced back to her. Provided intelligence on inter-clan politics.
4. **Armed the crew:** Equipped the party's companions (Jimjar, Spiderbait, Sarith, Eldeth, and others) with weapons.
5. **Ongoing:** Daz planned to visit her to negotiate further terms. She did not appear in the most recent session.

## Current Status
- **Last known location:** Overlake Hold
- **Active operations:** Awaiting concrete evidence from the party — papers from the caves proving Council of Savants involvement with corruption, and evidence about the Empty Scabbard Killers
- **Known to the party:** Her obsession with the Council, her political constraints, her desire for proof about her family's assassins, her inter-clan intelligence
- **Hidden/uncertain:** The full extent of her personal vendetta; whether her theory about the Council and Grey Ghosts has any truth to it

## Relationships
- **Daz:** Primary negotiator. Daz sees through her paranoia and views her scapegoating of the Derro critically, but works with her pragmatically.
- **Grygum:** Asked her for reinforcements (denied). Invokes her name as intimidation — it made checkpoint guard Grogluk visibly sweat.
- **The Deepking / Clan Steelshadow:** Ostensibly serves the Deepking but believes the Council of Savants is corrupting him.
- **Clan Ironhead & Clan Xardelva:** Views them as useful cover for the party; shared intelligence that both clans are seen as opposing the Deepking.
- **Council of Savants:** Primary adversary in her mind. Believes they are behind the city's madness.
- **Grey Ghosts:** Believes they collaborate with the Council.
- **Derro population:** Wants their destruction; uses them as scapegoats.
- **Empty Scabbard Killers:** Suspects they assassinated members of her clan; craves proof.

## Arc Score Events
- Party armed by Errde (relationship solidified — increase in trust/obligation)
- Daz talked her down from overinterpreting the Flumph evidence (maintained credibility — no apparent decrease)
- Party failed to retrieve papers from the caves (potential tension point — she demands they return)
