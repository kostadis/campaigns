---
name: JimJar
aliases: []
---

# JimJar

## Identity
- Deep gnome (svirfneblin) NPC companion
- Traveling with the party as a fellow escapee/companion

## Personality & Motivations
- Compulsive gambler who constantly proposes bets to party members on mundane outcomes. His wagers are lighthearted and seem to be his primary form of social interaction. Despite the frivolous betting, he occasionally offers genuinely shrewd observations and practical advice.

## History with the Party
1. **Knot-tying bet:** Wagered with Grygum that the knots used to restrain Pelek/Derro wouldn't hold overnight. Lost the bet — the knots held — and paid Grygum his winnings the next morning.
2. **Post-Narrak battle:** After the party defeated Narrak, JimJar noted the significant evidence the party had collected from various factions and recommended they keep it for future use. He proposed a bet that the evidence would prove helpful. Daz considered his counsel wise.

## Current Status
- **Location:** Traveling with the party
- **Activity:** Continuing as a companion; offering bets and occasional tactical advice
- **Party knowledge:** The party sees him as a quirky but sometimes insightful companion

## Relationships
- **Grygum:** Regular betting partner; owes Grygum from the lost knot wager
- **Daz:** Daz respects JimJar's judgment, finding his advice about holding onto evidence to be wise

## Arc Score Events
None noted in available session records.
