---
name: Kalannar
aliases: []
---

# Kalannar

## Identity
- Drow soldier
- First encountered in the mess hall, identified by Suushar as one of two Drow sitting at a table

## Personality & Motivations
- No personality traits or motivations demonstrated yet. Only observed sitting in the mess hall looking hungry.

## History with the Party
- Spotted by the party during Gyrgum's cooking assignment in the mess hall. Suushar pointed him out as one of two Drow at a table. No direct interaction occurred.

## Current Status
- Last seen in the mess hall
- No known plans or operations
- The party knows only his name, race, and that he appeared hungry

## Relationships
- Associated with another unnamed Drow who was sitting with him at the table
- Identified to the party by **Suushar**, suggesting Suushar has at least passing familiarity with him

## Arc Score Events
None recorded.
