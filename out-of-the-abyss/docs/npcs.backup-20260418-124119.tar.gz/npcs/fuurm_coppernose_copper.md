---
name: Fuurm Coppernose (Copper)
aliases: []
---

# Fuurm "Copper" Coppernose

## Identity
- Male human farmer with no adventuring skills
- First encountered by the party on the 9th day of the 1st tenday of Myrkhul, in a Faerzress crystal cave in the Underdark

## Personality & Motivations
- Driven by loyalty to his sister, whom he ventured into the Underdark to find after she went missing. Clearly out of his depth — a farmer, not an adventurer — yet desperate enough to press on alone. Initially fearful and defensive when encountered (brandishing a crystal as a weapon), but warmed to the party after being fed and cared for.

## History with the Party
- **9th day, 1st tenday of Myrkhul:** Party discovered him in a Faerzress crystal cave. He was starving, dressed in rags, and armed only with a crystal shard. He challenged the party aggressively out of fear ("Who are you? And back off!"). After explaining his situation — that he'd come searching for his lost sister and was captured by the Drow — Daz expressed astonishment that he had survived and invited him to join the group. The party fed him, which lifted his spirits. He was later seen chatting nervously with Baedora.

## Current Status
- **Last known location:** Traveling with the party after being rescued from the crystal cave
- **Active concerns:** His sister remains missing somewhere in or near the Underdark
- **What the party knows:** He is a farmer who entered the Underdark looking for his sister and was captured by Drow. He has no combat or adventuring experience.
- **What remains hidden:** The fate and whereabouts of his sister; details of his capture by the Drow.

## Relationships
- **Daz:** Invited Copper to join the group; impressed by his survival despite having no skills
- **Baedora:** Seen chatting nervously with her after joining the party; appears to be forming a social connection
- **The Drow:** Former captors; circumstances of capture and escape not fully detailed
- **His sister (unnamed):** Missing; her disappearance is the reason he entered the Underdark
