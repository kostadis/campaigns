---
name: Glabagool
aliases: []
---

# Glabagool

## Identity
- Sentient gelatinous cube; companion of the party
- First encountered prior to arriving at Blingdenstone (details of initial meeting not recorded in these notes); appeared with the party at the gates of Blingdenstone

## Personality & Motivations
- Uniquely sentient and capable of speech — abilities it gained after an unknown event it cannot fully explain. Curious and communicative, willing to speak aloud to strangers. Seems to regard itself as a helpful ally and appears genuinely friendly despite its alarming appearance.

## History with the Party
- **Arrival at Blingdenstone:** Accompanied the party to the gates, where its presence caused the deep gnome guards to panic. The party vouched for Glabagool, explaining it was friendly and had helped them during their journey. Glabagool spoke aloud to the guards, astonishing them. It shared observations about an unusual increase in agitated oozes in the area, coining the term "oozapalooza." The guards flagged its presence as a concern given Blingdenstone's existing ooze problem and directed the party to seek full permissions from Chief Dorbo Diggermattock and Quartermaster Senni.

## Current Status
- **Last known location:** The gates of Blingdenstone, awaiting resolution of its entry permissions.
- **Active concerns:** Its presence in or near Blingdenstone is politically sensitive due to the settlement's ongoing ooze crisis. The party needs approval from Chief Dorbo Diggermattock and Quartermaster Senni to bring Glabagool inside.
- **Known to the party:** Glabagool has noticed a regional surge in agitated ooze activity ("oozapalooza"); the cause of its own sentience remains unknown.

## Relationships
- **The Party:** Trusted companion; the party actively defended and vouched for it.
- **Blingdenstone Guards:** Initially hostile/fearful; astonished by its sentience but still wary given the town's ooze problem.
- **Chief Dorbo Diggermattock & Quartermaster Senni:** Not yet met; their approval is required for Glabagool's continued presence.

## Arc Score Events
No arc score events recorded.
