---
name: Shuushar
aliases: []
---

# Shuushar

## Identity
- Kuo-toan escapee and fellow prisoner; self-styled philosopher and advocate for curing kuo-toan madness
- First appeared as one of the group of prisoners who escaped captivity alongside the party

## Personality & Motivations
- Core goal: achieving "enlightenment" for the kuo-toan people by ending the cycle of madness and involuntary god-creation through mental discipline
- Pacifistic and philosophical by nature, though willing to arm himself when survival demands it (took a hand crossbow during the armory raid and fired on Imbros). Talkative and earnest, he developed his own mindfulness technique — "Kuo-toan-fulness" — which involves creating space between impulse and action. He served as a calming, knowledgeable presence in the group, offering practical guidance on Underdark survival alongside his philosophical musings.

## History with the Party
- **Armory Raid & Escape:** Armed himself with a hand crossbow and participated in the crossbow volley against Imbros, successfully hitting him. Fled during the ensuing chaos.
- **Mushroom Knowledge:** After Thorin involuntarily spoke truths from eating a Tongue of Madness mushroom, Shuushar explained its properties — it compels the eater to speak only the truth, though it is said to "connect the eater with the gods." Thorin, under its effects, remarked that Shuushar has "really big eyes."
- **Cave-In:** Was among those trapped under rocks during a cave-in.
- **Water Concerns:** Reassured the group about water scarcity, promising the Darklake would provide more than enough.
- **Yukyuk's Murder:** Whispered to Zalthir that Yukyuk had been murdered. Spiderbait accused Shuushar of being the killer, citing kuo-toan madness. Shuushar proposed traveling to Sloopbludop so the arch-cleric of the Seamother could cast Zone of Truth. When the group identified Buppido as mad, Shuushar insisted on tying him up rather than releasing him, and walked alongside the gagged derro, lecturing him on "Kuo-toan-fulness."
- **Sloopbludop & Demogorgon:** Had previously told the party that kuo-toa could create gods with the power of their faith. When an entity emerged from the Darklake, Thorin questioned whether it was truly Demogorgon or a kuo-toan creation called "Leemoogoogoon." Shuushar screamed and wailed at its appearance but recovered philosophically, declaring: "Enlightenment is necessary! We must change as a people. Our imagination brought into existence, Leemoogoogoon."
- **Darklake Navigation & Departure:** Served as the group's primary guide and navigator across the Darklake. On the 8th day of the 3rd Tenday of Taraskh, the party encountered a boat of kuo-toans who had also fled Sloopbludop. Shuushar spoke with them and found them receptive to his vision of a better kuo-toan world. He announced he had found his calling and left the party to join them.

## Current Status
- **Last known location:** On a boat with kuo-toan refugees on the Darklake, heading to an unspecified destination
- **Active plans:** Building a movement among displaced kuo-toans to end the madness of god-creation
- **Party knowledge gap:** The party lost their primary navigator upon his departure; Sarith retained Shuushar's instructions but expressed uncertainty about following them

## Relationships
- **The Party (general):** Trusted companion and guide; his departure was a significant practical loss
- **Thorin:** Friendly dynamic; Thorin listened to and internalized Shuushar's teachings about kuo-toan faith and god-creation
- **Sarith:** Relied on Shuushar's knowledge of Sloopbludop and navigation; inherited Shuushar's navigational instructions
- **Zalthir:** Confided in Zalthir about Yukyuk's murder
- **Spiderbait:** Tense; Spiderbait accused Shuushar of murdering Yukyuk
- **Buppido:** Shuushar attempted to rehabilitate the derro using his mindfulness techniques
- **Kuo-toan refugees:** Found kinship and a receptive audience for his philosophy among them
- **Daz:** Daz noted Shuushar "claims to have figured out the cure to Kuo-toan insanity"
