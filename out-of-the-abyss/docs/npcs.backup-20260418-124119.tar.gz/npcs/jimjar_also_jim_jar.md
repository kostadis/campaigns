---
name: Jimjar (also "Jim Jar")
aliases: []
---

# Jimjar

## Identity
- Deep gnome (svirfneblin) NPC, fellow escapee/companion
- Part of the group fleeing from drow captivity

## Personality & Motivations
- Compulsive gambler — constantly tries to frame situations as wagers, even during perilous circumstances. Attempted to bet on who would find food during the escape.
- Dismissive and opinionated — quickly waves away others' concerns with confident (possibly incorrect) claims. Shows a sharp tongue, particularly toward Shuushar and Kuo-Toan beliefs.
- Seems to prioritize his own amusement and gambling over group cohesion.

## History with the Party
- **Escape from the Drow:** Fled alongside the party. Complained that Zalthir's insistence on running ruined his planned food-finding wager. Tried to initiate a bet with the group ("Wanna bet?").
- **Faerzress Discussion:** When Shuushar expressed discomfort about the Faerzress, Jimjar dismissed his concerns. Called Kuo-Toans insane, claiming those "who think they aren't mad" are the worst. Asserted confidently that Faerzress has never affected a living thing and that its only magical property is preventing teleportation spells.

## Current Status
- Traveling with the party, on the run from drow pursuers
- No known independent plans beyond gambling and survival
- **Party knows:** He's a compulsive bettor with strong opinions and questionable expertise on Underdark phenomena
- **Potentially hidden:** Whether his claims about Faerzress are accurate or dangerously wrong

## Relationships
- **Zalthir:** Mild friction — resented Zalthir's decision to run, which interrupted his gambling plans
- **Shuushar:** Openly dismissive; considers Kuo-Toans collectively insane and doesn't take Shuushar's concerns seriously
- **The Party:** Positioned as a colorful but potentially unreliable companion
