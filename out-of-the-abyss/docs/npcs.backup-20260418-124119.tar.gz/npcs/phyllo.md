---
name: Phyllo
aliases: []
---

# Phyllo

## Identity
- Myconid Sovereign of Neverlight Grove
- Allied with Zuggtmoy ("the Great Seeder")
- Encountered when the party visited the Inner Circle of Neverlight Grove

## Personality & Motivations
- Devoted to Zuggtmoy and genuinely believes her influence will improve Neverlight Grove and bring happiness to all myconids. Does not appear malicious so much as fanatically converted — pleading rather than threatening when challenged. Shows emotional attachment to Basidia despite their ideological split.

## History with the Party
- Had secretly planned for the party to be killed the following day during their visit to the Inner Circle.
- When the party returned to the Inner Circle acting nonchalant, Phyllo greeted Basidia and asked if the visitors had enjoyed seeing the circle and what they thought of "the changes."
- When Basidia accused Phyllo of betrayal, Phyllo did not attack the fleeing party. Instead, Phyllo pleaded with Basidia not to leave, calling out: *"The Neverlight Grove will be better than ever! And the Great Seeder will make us all happy!"* and plaintively: *"Basidia don't go."*

## Current Status
- **Location:** Neverlight Grove (Inner Circle)
- **Activity:** Remains allied with Zuggtmoy; presumably continuing to spread her influence among the myconids
- **Known to party:** They know Phyllo is a traitor allied with Zuggtmoy who planned to have them killed. They know Phyllo chose not to pursue them when they fled.
- **Hidden:** The full extent of Zuggtmoy's plans and Phyllo's role in them remains unclear.

## Relationships
- **Basidia:** Fellow Myconid Sovereign; Phyllo clearly cares about Basidia and desperately wants them to stay and embrace Zuggtmoy's gifts. Their relationship is fractured — Basidia views Phyllo as a betrayer.
- **Zuggtmoy:** Phyllo's patron and object of devotion; refers to her as "the Great Seeder."
- **The Party:** Hostile by intent (planned their murder) but did not act on it when the moment came. Let them flee.
