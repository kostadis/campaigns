---
name: Whisperwind
aliases: []
---

# Whisperwind

## Identity
- Giant; friend and ally of the party member Thorin
- Has not appeared directly in any session to date; known only through Thorin's references

## Personality & Motivations
- Appears to serve as an intelligence source or scout, particularly regarding underground threats. Specific personality traits have not yet been demonstrated in play.

## History with the Party
- **Pre-session history:** At some point before the observed sessions, Whisperwind warned Thorin about the duergar (deep dwarves). This warning proved relevant when Thorin later spotted a duergar named Hemath and recalled Whisperwind's caution.

## Current Status
- **Last known location:** Unknown
- **Active plans:** Unknown
- **Party knowledge:** The party (at minimum Thorin) knows Whisperwind as a trustworthy source of information about the duergar. No further details have been revealed.

## Relationships
- **Thorin:** Friend and trusted contact. Thorin takes Whisperwind's warnings seriously.
- **Duergar:** Oppositional; Whisperwind has knowledge of and concern about duergar activity.
