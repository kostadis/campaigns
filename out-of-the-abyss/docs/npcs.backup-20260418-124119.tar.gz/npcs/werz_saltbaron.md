---
name: Werz Saltbaron
aliases: []
---

# Werz Saltbaron

## Identity
- Duergar merchant operating near the piers of Ghohlbrorn's Lair
- First encountered when the party found him unconscious after being attacked by two assassins on the docks

## Personality & Motivations
- Core goals are unclear beyond self-preservation and continuing his merchant activities
- Comes across as grateful but guarded — he expressed genuine surprise at being rescued, yet quickly turned invisible and departed, saying "he has places to be." Pragmatic and cautious, he rewards those who help him but does not linger.

## History with the Party
1. **Assassination Attempt:** The party discovered Werz unconscious on the piers, having been attacked by two assassins wielding glowing weapons (possibly psychic). He had no visible wounds. The assassins carried a charcoal drawing of him, confirming he was a deliberate target.
2. **Rescue & Gratitude:** Grygum healed him. Werz expressed surprise and gratitude, claimed ignorance about why he was targeted, then recognized the drawing as proof he was specifically marked. He invited the party to the Shattered Spire the next day to reward them, turned invisible, and departed.
3. **Contract Investigation:** The party later engaged with the assassin network specifically to get Werz's contract cancelled. Eldgrim confirmed there was an active hit on Werz, dismissing him as "small potatoes." Eldgrim offered to cancel the contract and permanently brightlist Werz for 20 gold, or for free if the party eliminates the Demogorgon cult.

## Current Status
- **Last known:** Turned invisible and left the docks; expected to meet the party at the Shattered Spire the next day to provide a reward
- **Active threat:** A stolen contract from Eldgrim's desk contains a furious, personal denunciation of Werz — *"WERZ SALTBARON THAT SNIVELING SQUEALING WRITHING LITTLE RAT! BIND HIS FEET AND THROW HIM OFF HIS BELOVED DOCKS!"* — written under the **personal seal of the Deepking**
- **Hidden from Werz:** He likely does not know the Deepking himself ordered the hit. The party may or may not have shared this information yet.
- **Contract status:** Cancellation is conditional on the party eliminating the Demogorgon cult (per Eldgrim's deal), unless the party paid the 20 gold instead.

## Relationships
- **The Deepking:** Personally furious with Werz — authored the assassination contract under his own seal. The reason for this hatred is unknown but the language ("sniveling squealing writhing little rat") suggests Werz may have informed on or betrayed the Deepking in some way.
- **Eldgrim:** Handles the assassination contract; considers Werz insignificant ("small potatoes").
- **The Party:** Grateful to them for saving his life; owes them a reward at the Shattered Spire.
- **Grygum:** Specifically healed Werz; direct personal debt.

## Arc Score Events
- No explicit arc score changes noted in the source material.
