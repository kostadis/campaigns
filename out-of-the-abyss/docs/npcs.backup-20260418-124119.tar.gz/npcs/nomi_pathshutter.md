---
name: Nomi Pathshutter
aliases: []
---

# Nomi Pathshutter

## Identity
- Major leader of Blingdenstone
- First appeared at the grand moot as part of the deep gnome leadership

## Personality & Motivations
- Core goal: Cleansing the Temple of the Steadfast Stone to enable the summoning of Earth Elementals, protected from the corrupting influence of Ogremoch's Bane.
- Appears politically coordinated and strategic; delivered a rehearsed joint presentation with Gurnik Tapfinger at the grand moot, suggesting she values preparation and coalition-building.

## History with the Party
- **Grand Moot:** Presented alongside Gurnik Tapfinger, proposing a plan to cleanse the Temple of the Steadfast Stone. The presentation appeared rehearsed, indicating prior coordination between the two leaders. The plan centers on summoning Earth Elementals and shielding them from being driven insane by Ogremoch's Bane.

## Current Status
- **Last known location:** Blingdenstone (at the grand moot)
- **Active plans:** Advocating for the cleansing of the Temple of the Steadfast Stone as a strategic priority for Blingdenstone
- **Known vs. hidden:** The party knows her public proposal; the extent of her political influence, her deeper motivations, and any private agendas remain unknown

## Relationships
- **Gurnik Tapfinger:** Close political ally; the two coordinated a joint rehearsed presentation at the grand moot, suggesting an established working relationship
- **Blingdenstone leadership:** One of the settlement's major leaders; exact rank or title unspecified

## Arc Score Events
No arc score events noted.
