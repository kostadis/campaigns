---
name: Shuushar (also "Suushar")
aliases: []
---

# Shuushar

## Identity
- Fellow captive/companion of the party
- No faction affiliation noted

## Personality & Motivations
- Appears sensitive to magical or environmental phenomena, particularly Faerzess. His reaction to the Faerzess suggests he has prior familiarity with it — previously experiencing it as harmless light — but is now disturbed by a fundamental change in its nature.

## History with the Party
1. **Rockfall incident:** After a rockfall, Grygum directed Stool to go help Shuushar, indicating he was injured or trapped.
2. **Faerzess cave passage:** While the group moved through a cave suffused with Faerzess, Shuushar was visibly uncomfortable. Afterward, he remarked: *"That was odd. It was the first time I had felt so strange. The Faerzess was just a light, but now it seems to be a poison."* This signals that something has changed about the Faerzess — a potentially significant development.

## Current Status
- Traveling with the party
- Physically affected or unsettled by the altered Faerzess
- **What the party knows:** Shuushar openly shared his discomfort and his observation that Faerzess has changed from a harmless light to something toxic
- **What remains hidden:** The cause of the Faerzess corruption is unknown

## Relationships
- **Grygum:** Grygum showed concern for Shuushar's well-being after the rockfall, directing aid to him.
- **Stool:** Sent by Grygum to assist Shuushar; their direct relationship is unclear beyond this moment.

## Arc Score Events
No arc score events noted.
