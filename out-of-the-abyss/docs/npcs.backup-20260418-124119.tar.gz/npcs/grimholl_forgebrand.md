---
name: Grimholl Forgebrand
aliases: []
---

# Grimholl Forgebrand

## Identity
- Subordinate of Erdde Blackskull
- Goes by "Holl" to friends
- First appeared when brought into a room to brief Grygum on a series of mysterious killings

## Personality & Motivations
- Blunt and guarded — immediately establishes distance with strangers ("Holl to my friends, and you are not my friends"). His core drive in the interaction was delivering factual intelligence on the killings. He appears to take his duties under Erdde Blackskull seriously.

## History with the Party
- **Briefing on the Mysterious Killings:** Grimholl was brought in by Erdde Blackskull to brief Grygum on a pattern of killings. He reported that the bodies found had no entrance wounds or exit wounds — a detail the party initially may have doubted. Zalthir later corroborated Grimholl's account after examining a Duergar merchant who had been attacked by assassins wielding glowing weapons and similarly bore no visible wounds.

## Current Status
- **Last known location:** Unclear beyond the briefing room; presumably still operating under Erdde Blackskull.
- **Active plans:** None specified beyond his investigative role regarding the killings.
- **Party knowledge:** The party knows his report about woundless bodies was truthful. The nature of the glowing weapons and the mechanism behind the woundless deaths remain unexplained.

## Relationships
- **Erdde Blackskull:** Direct superior; Grimholl serves under and reports to them.
- **Grygum:** Recipient of Grimholl's briefing; no personal rapport established.
- **Zalthir:** No direct interaction, but Zalthir's independent investigation validated Grimholl's claims.
- **The Party:** Kept at arm's length — explicitly told them they are not his friends.
