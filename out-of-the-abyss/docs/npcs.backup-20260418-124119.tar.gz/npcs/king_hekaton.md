---
name: King Hekaton
aliases: []
---

# King Hekaton

## Identity
- King of the Giants
- Mentioned in historical/cultural context during Thorin's reverie about the festival of Greengrass
- Has not appeared directly to the party

## Personality & Motivations
- A ruler who values peace between giants and the smaller races. His decree ending hostilities after the War of the Giants established a lasting accord that shaped relations for an extended period.

## History with the Party
- **Thorin's Reverie (Greengrass festival):** King Hekaton was referenced in the context of the post-war peace. After the War of the Giants concluded, he decreed peace with the "little people" (smaller races), and this peace has been maintained among giants and their neighbors since.

## Current Status
- Last known status: Unknown. He has only been referenced historically.
- The party knows him as the giant king who decreed peace after the War of the Giants.
- No direct interactions or current operations known.

## Relationships
- **The Giants:** Their king and authority figure.
- **The "Little People" (smaller races):** Established a peace accord with them following the War of the Giants.
- **Thorin:** Knows of Hekaton through cultural memory/history connected to the Greengrass festival.
