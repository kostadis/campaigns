---
name: Brysis of Khaem
aliases: []
---

# Brysis of Khaem

## Identity
- Half-elf sorcerer of Netherese nobility, from the height of Faerûn's great empires of magic
- Her Lost Tomb is located on the eastern edge of the Darklake in the Underdark
- The party entered her tomb during exploration of the Underdark

## Personality & Motivations
- In life, she was a figure of wealth, power, and status, depicted flaunting these qualities in stone dioramas and murals alongside the floating cities of Netheril. Her current motivations are unclear — a telepathic feminine voice called out to the party upon entering the tomb, pleading for help, and later urged Zalthir to look inside the sarcophagus, claiming "I can help you!" Whether this voice belongs to Brysis or something else is unresolved.

## History with the Party
- **Tomb Discovery:** The party learned about the tomb from **Fargas Rumblefoot**, who provided intelligence about its layout — specifically that it contains a false burial chamber with a fake sarcophagus designed to deceive treasure hunters, and that the real treasure is in a separate chamber accessible through a secret passageway from the servants' tomb.
- **Tomb Entry:** Upon entering, the party encountered a stone diorama depicting Brysis as a Netherese noble with her retinue, and murals of Netheril's floating cities. A soft feminine voice telepathically contacted the party, pleading for help.
- **Sarcophagus Chamber:** In the deepest chamber, the party found her gilded sarcophagus. A **Wraith** rose from it, declaring: *"Your deaths will free me from this prison, and how my victims will serve me even in death!"*
- **Cliffhanger:** During the encounter, the telepathic feminine voice spoke again — *"In the sarcophagus! I can help you!"* — as Zalthir moved the sarcophagus lid aside. The session ended with Zalthir looking inside.

## Current Status
- **Last known situation:** The party is mid-encounter at her gilded sarcophagus; Zalthir has just opened the lid.
- **Unresolved mystery:** It is unclear whether the Wraith *is* Brysis or a separate entity. The telepathic feminine voice appears distinct from the Wraith, suggesting Brysis (or something else) may be trapped within the sarcophagus while the Wraith serves as a guardian or jailer.
- **Hidden from the party:** The secret passageway from the servants' tomb to the real treasure chamber (per Fargas Rumblefoot's intel) — unclear if the party has found or used this information yet.

## Relationships
- **Fargas Rumblefoot:** Provided the party with detailed knowledge of the tomb's layout and hidden chambers.
- **Zalthir:** The party member who moved the sarcophagus lid and is the focal point of the unresolved cliffhanger.
- **The Wraith:** Relationship ambiguous — could be Brysis's cursed form, a separate guardian, or her jailer.

## Arc Score Events
No arc score events noted in the source material.
