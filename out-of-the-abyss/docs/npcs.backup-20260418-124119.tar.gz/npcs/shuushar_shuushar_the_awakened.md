---
name: Shuushar (Shuushar the Awakened)
aliases: []
---

# Shuushar the Awakened

## Identity
- Kuo-toan pacifist and self-styled philosopher
- Fellow traveler with the party; knowledgeable guide regarding kuo-toan society and the Underdark
- First appeared as a companion already traveling with the group prior to reaching Sloobludop

## Personality & Motivations
- Committed pacifist who finds violence deeply distressing and unnecessary. Advocates for dialogue and understanding before any action is taken.
- Tends to be long-winded and preachy, droning on about open-mindedness before thankfully walking away. Genuinely believes in hearing all perspectives before making judgments.
- Excited and proud of his homeland and people despite being considered a troublemaker among them.

## History with the Party
- **Ambush battle near Sloobludop:** Provided tactical intel on the kuo-toan monitor's role (a leader who manages outbreaks of insanity; defeating the monitor demoralizes other kuo-toans). Lamented the violence afterward.
- **Approach to Sloobludop:** Affirmed to Sethir that they should continue. Grew visibly excited when they encountered a kuo-toan party about an hour out from the settlement.
- **Introduction to Ploopploopeen:** Personally introduced the party to Ploopploopeen, archpriest of the Sea Mother, having spoken with a member of her party first.
- **Debate over killing Ploopploopeen's party:** Was aghast when the group considered violence. Argued that the Sea Mother is an old, legitimate god and that it is the **Deep Father** who demands humanoid sacrifices. Urged the party to speak with Ploopploopeen's daughter **Bloppblippodd** before deciding anything.

## Current Status
- **Last known location:** With the party near or at Sloobludop, in the company of Ploopploopeen's group.
- **Active concerns:** Mediating between the party and his people; trying to prevent unnecessary bloodshed.
- **Hidden information:** Ploopploopeen cast a pointed glance at Shuushar when referencing troublesome "visionaries," suggesting he has a contentious reputation among the kuo-toans that he has not fully disclosed to the party.

## Relationships
- **Ploopploopeen** — Known to her; she views him with some suspicion as a disruptive visionary.
- **Bloppblippodd** — Knows of her and trusts her enough to recommend the party speak with her.
- **Sethir** — Responds to Sethir's prompts and seems to accept him as a decision-maker in the group.
- **The Party (general)** — Serves as cultural interpreter and moral conscience; tolerated but sometimes tuned out due to his tendency to lecture.
