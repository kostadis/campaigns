---
name: Themberchaude
aliases: []
---

# Themberchaude

## Identity
- Red dragon residing in Gracklstugh
- Associated with the Keepers of the Flame
- Has not appeared in person; referenced only through NPCs (Daz, Thorin)

## Personality & Motivations
- Paranoid about his position and security within Gracklstugh's power structure. Suspects the Keepers of the Flame have their own plans that may not serve his interests. Wants intelligence on what is truly happening in the city and whether he is genuinely in control or merely a figurehead.

## History with the Party
- **Referenced only:** Daz mentioned Themberchaude while analyzing Gracklstugh's political situation, noting the dragon's suspicions about the Keepers of the Flame.
- Thorin floated a plan to escape Gracklstugh by riding on Themberchaude's back — unclear if this was serious or speculative.

## Current Status
- **Location:** Gracklstugh (exact lair location unspecified)
- **Activity:** Seeking information about the Keepers of the Flame's true intentions and his own standing in the city's power dynamics
- **Party knowledge:** The party knows Themberchaude exists, is suspicious of the Keepers, and feels insecure about his authority. They have not met him directly.

## Relationships
- **Keepers of the Flame:** Distrustful; believes they have hidden agendas that may threaten his position
- **Daz:** Source of intelligence about Themberchaude's concerns
- **Thorin:** Has expressed interest in using Themberchaude as an escape route
- **The Party:** No direct relationship yet

## Arc Score Events
None recorded.
