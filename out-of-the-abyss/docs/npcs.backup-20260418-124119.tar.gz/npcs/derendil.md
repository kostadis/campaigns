---
name: Derendil
aliases: []
---

# Prince Derendil

## Identity
- Self-styled "Prince"; considered deluded by others
- Fellow prisoner encountered during captivity alongside the party

## Personality & Motivations
- Claimed royal status, though this was regarded as a delusion rather than fact. Little else is known of his personality beyond this grandiose self-image.

## History with the Party
- Was held as a prisoner alongside the party.
- Died during the fight against drow guards that enabled the prisoners' escape. His large corpse was left behind as the group fled.

## Current Status
- **Dead.** Killed during the breakout from drow captivity.
- His body was left at the site of the escape.

## Relationships
- Fellow prisoner of the party and other captives; no deeper individual relationships noted.

## Arc Score Events
None recorded.
