---
name: Ploopploopeen (Ploop)
aliases: []
---

# Ploopploopeen (Ploop)

## Identity
- Archpriest of the Sea Mother (kuo-toa deity)
- Father of Bloppblippodd
- Leader of the Sea Mother faction in the kuo-toa civil conflict against the Deep Father cult
- Met by the party when they were presented as apparent offerings at the altar

## Personality & Motivations
- Core goal: Destroy the Deep Father cult and eliminate his own daughter Bloppblippodd's heretical influence. Willing to commit filicide to achieve this.
- Cunning and manipulative — orchestrated an elaborate ruse, pretending to cooperate with the Deep Father cult while secretly planning to betray his daughter. Thorin noted that Ploop could have incapacitated the escapees with hold person spells if he had truly been against them, confirming the depth of his deception.

## History with the Party
1. **The Altar Ruse:** Ploop presented the escapees as offerings to Bloppblippodd at the altar, appearing to cooperate with the Deep Father cult. This was a calculated deception.
2. **Betrayal Revealed:** Instead of sacrificing the escapees, Ploop turned on his daughter, attacking Bloppblippodd alongside his allies and triggering an all-out civil war among the kuo-toa.
3. **Killing Blow:** Ploop personally struck the final, fatal blow against Bloppblippodd before the altar.
4. **Aftermath:** Grygum looted Ploop's thatched hut, justifying it by noting that Ploop had previously promised to pay the party.

## Current Status
- **Last known location:** Sloobludop, at or near the altar where the battle took place
- **Status after Demogorgon's emergence is unknown** — fate unconfirmed
- His hut has been looted by the party

## Relationships
- **Bloppblippodd** — His daughter; killed her personally to end the Deep Father cult's influence
- **The Party** — Used them as pawns in his scheme; had promised them payment. Relationship is ambiguous — he protected them through his ruse but also manipulated them
- **Thorin** — Thorin recognized the sophistication of Ploop's deception, acknowledging he had been playing them
- **Grygum** — Looted Ploop's home, citing the unpaid promise of compensation

## Arc Score Events
None explicitly noted.
