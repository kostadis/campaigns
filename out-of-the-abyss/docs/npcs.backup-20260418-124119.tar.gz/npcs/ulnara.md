---
name: Ulnara
aliases: []
---

# Ulnara

## Identity
- Derro necromancer, member of the Council of Savants
- Cultist of Demogorgon
- Operates a zombie-production pit filled with zombies, fungi, and decomposed flesh
- First encountered when she emerged from a narrow tunnel in the southeast wall of her pit alongside an Ogre Zombie, confronting the party

## Personality & Motivations
- Initially arrogant and demanding — challenged the party on who they were and who they served. Her bravado collapsed instantly when Daz demonstrated lethal power, revealing a core of cowardice and self-preservation. Became sniveling and subservient, eagerly seeking to ingratiate herself with anyone she perceives as more powerful. Genuinely fearful of the Drow.

## History with the Party
- **First encounter (zombie pit):** Ulnara emerged aggressively, demanding to know who the party was and who they worked for. When Daz killed Skiit with Toll the Dead, she immediately switched to fawning deference. She thanked the party for the "new supply" (Skiit's body for zombification) and begged them to tell Pliinki that she had done much to help the "Ember Vanguard."

## Current Status
- **Location:** Alive, operating in the zombie pit
- **Activity:** Continuing her necromantic operations; producing zombies
- **Belief:** Convinced the party are powerful allies (likely Ember Vanguard–affiliated or Drow authority figures)
- **Hidden from the party:** The full scope of her necromantic operation and her deeper ties to Demogorgon's cult remain unexplored

## Relationships
- **Pliinki:** Someone Ulnara wants to impress; she desperately asked the party to relay her helpfulness to Pliinki
- **Council of Savants:** Member of this body (broader role/standing unknown)
- **Ember Vanguard:** Wants credit for aiding them; exact relationship unclear
- **Daz (party member):** Deeply fears him after witnessing him kill Skiit; treats him with terrified deference
- **Skiit:** Killed by Daz in front of Ulnara; she claimed the body as raw material without hesitation

## Arc Score Events
- No explicit arc score changes noted.
