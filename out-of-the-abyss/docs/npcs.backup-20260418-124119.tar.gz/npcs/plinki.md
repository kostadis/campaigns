---
name: Plinki
aliases: []
---

# Plinki

## Identity
- Female derro, recent convert to the Cult of Demogorgon
- Affiliated with the Council of Savants and the Grey Ghosts
- First encountered indirectly through a flumph's psychic trauma dump, then met in person atop a mesa near a black obelisk in a large Underdark cavern

## Personality & Motivations
- Fanatically devoted to Demogorgon (whom she mentally referred to as the "Big Baboon Demon"). Her core goal was to corrupt a stolen red dragon egg by infusing it with a demon's spirit, creating a dual-headed dragon to offer Demogorgon as a mount. She was gleefully obsessed with the black obelisk, treating it with reverence and delight. She refused all attempts at reason, her mind consumed with thoughts of "Sacrifice! Power!"

## History with the Party
1. **Flumph encounter:** The party first learned of Plinki through a flumph's psychic trauma dump, which described a derro conducting evil activities around an obelisk in a chamber with a circular pathway and pyramid, working with the Council of Savants.
2. **Meeting at the obelisk:** The party found Plinki stroking the fifty-foot-tall black obelisk atop the mesa's highest tier. When Grygum introduced himself as a cleric of Bahamut, she became excited, interpreting his arrival as proof her ritual was working — "A cleric of Bahamut to see my creation! Excellent!"
3. **Confrontation:** Plinki revealed the egg's origin (stolen by the Grey Ghosts from the Keepers of the Flame) and declared that Grygum's beating heart would seal the ritual. She signaled six derro followers to move on the party.
4. **Combat and death:** She hesitated when Grygum threatened the egg's destruction. Zalthir caught her in magical darkness, grappled her, and Grygum struck her with a necromantic claw. Zalthir then killed her with a fire breath attack. Her death shattered her followers' morale.

## Current Status
- **Dead.** Killed by Zalthir's fire breath attack atop the mesa.
- Her ritual to corrupt the red dragon egg was interrupted but its current state of completion is unclear.

## Relationships
- **Council of Savants:** Collaborator; was working with them on the obelisk/egg project.
- **Grey Ghosts:** Received the stolen red dragon egg from them.
- **Demogorgon:** Object of fanatical worship; the egg corruption was meant as an offering.
- **Grygum (party):** Viewed him as an unwitting sacrifice to complete her ritual; he attempted to reason with her and failed.
- **Zalthir (party):** Identified her as the enemy's lynchpin and killed her directly.
- **Derro followers (six):** Served as her guards; panicked and broke after her death.
