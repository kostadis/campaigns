---
name: Fargus Rumblefoot
aliases: []
---

# Fargus Rumblefoot

## Identity
- Role and faction affiliation unknown from available notes
- First appearance predates the sessions covered; met the party prior to their exploration of the Lost Tomb of Khaem

## Personality & Motivations
- Insufficient data to fully characterize. Demonstrated willingness to share knowledge and warn others of danger, suggesting a helpful or allied disposition toward the party.

## History with the Party
- **Pre-session (exact timing unknown):** Warned the party about a "secret room" or "false tomb" within the Lost Tomb of Khaem. This tip proved accurate — the party later discovered a hidden passage beneath the northeast sarcophagus during their exploration of the tomb.

## Current Status
- **Last known location:** Unknown; was not present during the party's exploration of the tomb
- **Active plans:** None known
- **Party knowledge:** The party trusts his information — his warning about the false tomb checked out, which likely bolsters his credibility for future tips

## Relationships
- Has enough of a relationship with the party that they took his warning seriously and recalled it mid-dungeon. No other NPC or faction connections noted.

## Arc Score Events
None recorded.
