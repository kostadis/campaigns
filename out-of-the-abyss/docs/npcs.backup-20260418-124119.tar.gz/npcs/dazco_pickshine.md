---
name: Dazco Pickshine
aliases: []
---

# Dazco Pickshine

## Identity
- Representative of the Miners Guild
- First appeared during a council meeting where the party was involved in brokering a compromise over mining operations

## Personality & Motivations
- Core goal: Secure funding for city repairs through mining revenue; prioritizes the economic interests of the Miners Guild.
- Pragmatic and results-oriented. Initially pushed hard for immediate strip mining as the fastest path to revenue, showing little concern for other considerations. However, he proved willing to negotiate and ultimately accepted a compromise, suggesting he values practical outcomes over ideological stubbornness.

## History with the Party
- **Council Meeting:** Dazco advocated aggressively for immediate strip mining to fund city repairs. The party brokered a sustainable mining compromise that balanced the city's economic needs with respect for ghosts' sacred grounds. Dazco agreed to the terms.

## Current Status
- Last known location: The council meeting
- Has agreed to the party's sustainable mining compromise; presumably overseeing its implementation through the Miners Guild
- **Party knows:** His role in the Miners Guild, his initial position on strip mining, and his acceptance of the compromise
- **Potentially hidden:** His true feelings about the compromise, whether the Miners Guild will fully comply, and any internal guild politics at play

## Relationships
- **Miners Guild:** Representative and advocate for their interests
- **The Party:** Initially an obstacle/opponent during negotiations; shifted to a reluctant ally after accepting the compromise
- **The Ghosts / Sacred Grounds Stakeholders:** Was willing to disregard their interests in favor of economic gain; the compromise forces him into an uneasy coexistence with these concerns
