---
name: Shoor
aliases: []
---

# Shoor

## Identity
- Male Drow fighter, stationed at Velkynvelve (Drow outpost)
- One of two male Drow subordinates serving under Priestess Ilvara
- First appeared flanking Ilvara when she greeted the arriving prisoners

## Personality & Motivations
- No direct personality traits observed yet; known primarily through his role and relationships.
- His position as Ilvara's favored consort suggests ambition or at least willingness to leverage social standing among the Drow.

## History with the Party
- Was present alongside Ilvara and Jorlan when the party first arrived as prisoners at Velkynvelve.
- No direct interactions with the party have been noted beyond this initial appearance.

## Current Status
- **Location:** Velkynvelve, the Drow outpost
- **Role:** Serving as Ilvara's "primary squeeze" / favored consort, having replaced the disfigured Jorlan
- **Hidden info:** Jorlan's escape plot is partly motivated by a desire to make Shoor "look ridiculous" — the party may or may not be aware of this detail (sourced from Jimjar's gossip and Jorlan's motivations)

## Relationships
- **Ilvara:** Her current favored consort; replaced Jorlan in this role
- **Jorlan:** Rival. Shoor took Jorlan's place after Jorlan was injured/disfigured. Jorlan harbors resentment and is actively scheming to humiliate Shoor
- **Jimjar:** Jimjar is the source of gossip about Shoor's relationship with Ilvara; no direct relationship implied
- **The Party:** No meaningful individual relationships established yet
