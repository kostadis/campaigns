---
name: Yestabrod
aliases: []
---

# Yestabrod

## Identity
- Deceased NPC; previously encountered and killed by the party
- Role in death: corpse used as a puppet "priest" during a mock wedding rehearsal procession linked to Zuggtmoy and Araumycos

## Personality & Motivations
- No living personality observed in the notes provided; only encountered as a corpse being manipulated by outside forces.

## History with the Party
1. **Killed by the party** at some prior point (details of the original encounter not provided in these notes).
2. **Post-mortem:** His corpse was retrieved and carried by three spore servants that rose from a garden. The spore servants manipulated his body to act as a priest presiding over a mock wedding rehearsal — a procession enacting vows between stand-ins for **Araumycos** and **Zuggtmoy**.

## Current Status
- **Dead.** His corpse was last seen being puppeted by spore servants during the wedding rehearsal procession.
- His body appears to be a tool in Zuggtmoy's plans to unite with Araumycos through some form of ritualistic marriage.
- **Party knows:** Yestabrod is dead; his corpse is being used in a ceremony tied to Zuggtmoy and Araumycos.
- **Unknown:** Whether his corpse holds further significance in the actual wedding ritual, or if this was merely a rehearsal.

## Relationships
- **Zuggtmoy:** His corpse serves her designs — cast in the role of priest for her symbolic union with Araumycos.
- **Araumycos:** Connected only through the mock wedding; a stand-in represented Araumycos as the other party in the vows.
- **Spore Servants:** Three rose from the garden specifically to carry and puppet his corpse.
- **The Party:** Killed him previously; witnessed the desecration of his remains.

## Arc Score Events
- None noted in provided material.
