---
name: Zalthir
aliases: []
---

# Zalthir

## Identity
- Drow monk, companion and fellow prisoner of the party
- First encountered as a prisoner in the drow prison; participated in the initial escape attempt alongside Daz and the other captives

## Personality & Motivations
- Pragmatic and self-interested, reluctant to take on missions beyond his immediate survival needs ("Saving the Duergar from a mad king and defeating another cult of Demogorgon is not what I am here for"). Pushes for compensation when asked to do work for others. His core goal is escaping the Underdark and acquiring magical equipment along the way. He is quick-thinking and resourceful, often serving as the group's scout, but tends toward sardonic commentary and quiet observation. He shows loyalty to specific individuals — notably his friend "Rump-a-dump" — while remaining unsentimental about the broader situation.

## History with the Party
- **Prison Escape:** Devised the initial escape plan (sneak into tower, arm up, return weapons to prisoners). The plan fell apart when he tripped over a goblet. Attempted to shove guard Imbros but accidentally caressed him due to weakness from captivity. Survived the ensuing fight.
- **Post-Escape:** Looted drow bodies for weapons, grabbed silk ropes, suggested burning the place down. Escaped via waterfall and tunnels. Ate a Tongue of Madness mushroom and took a vow of silence to avoid being compelled to speak truth.
- **Cave-in:** Was among those not trapped; examined unconscious Daz and concluded the mage would die without rescue.
- **Silken Paths:** Cut a web strand, initiating the Giant Spider encounter. Fought in the retreat. Confronted Fargas Rumblefoot about promised treasure, assessed Fargas's claims were desperation or bravado. Touched Fargas's belly and declared "No gnoll spawn." Asked whether drow pursuers would be slowed by the spiders.
- **Spectator Encounter:** Attempted to use myconid mind network to find someone to communicate with the Spectator. Performed an acrobatic strike from underneath a web strand — missed, then was paralyzed by the Spectator's green ray. His acrobatics deeply impressed goblin guides Yukyuk and Spiderbait, preventing them from abandoning the group. Privately considered convincing the guides to retrieve gold from a mimic.
- **Demogorgon's Appearance:** Was about to flee but stayed when he saw incapacitated companions needed carrying. Annoyed at having been caught up in the summoning ritual.
- **Darklake Journey:** Uncomfortable in low-ceilinged caves due to height. Prepared to attack when a Kuo-Toan boat was spotted. Wanted to object to Shuushar's departure (valued his navigation) but was preempted by Thorin.
- **Myconid Scouting:** Discovered myconids dancing frantically (madness-affected) and quaggoth spore servants in a cave. Noted Stool had never described such behavior.
- **Flumph Contact:** Received telepathic visions of Plinki conducting evil rituals at an obelisk/pyramid chamber, and intelligence about a derro with Council of Savants / Gray Ghosts insignia. Questioned the flumph for actionable intel.
- **Gartokkar Negotiation:** Pushed for compensation during negotiations with Gartokkar Xundorn.
- **Mesa / Plinki Encounter:** When derro surrounded Grygum to sacrifice him, Zalthir cast magical darkness over the mesa top, attacked derro within it, and grappled Plinki. Grygum had used Zalthir as a threat ("the Drow hates dragons and will destroy the egg").
- **Derro Patrol Fight:** Summoned darkness on enemies, landed a critical strike. Pragmatically asked whether mad derro near a tent needed fighting.
- **Sarith Incident:** Physically stopped Sarith from walking compelled toward myconids. Called out Daz's earlier assurance about spore range being safe, noting sarcastically, "The knowledge of the Drow…" Positioned himself far from myconids.
- **Egg Discussion:** Agreed with the plan to hand the dragon egg to Gartokkar and escape via ports. Insisted the party save his friend Rump-a-dump.
- **Fountain Chamber:** Dispatched gray oozes with precise bare-fisted monk strikes, handling them one by one as the party activated statues.

## Current Status
- **Last Known Location:** With the party in the Underdark (fountain/ooze chamber area), traveling toward the ports
- **Active Concerns:** Insistent on rescuing his friend Rump-a-dump; wants to acquire magical equipment; wary of Neverlight Grove given possible Zuggtmoy presence
- **Hidden from Party:** Privately considered manipulating the goblin guides to retrieve mimic gold; briefly wondered if the Spectator identified Buppido as the demon but dismissed the thought

## Relationships
- **Daz:** Trusted ally from the prison break; Zalthir relied on him as backup. Later called out Daz's incorrect spore-range assessment with sarcasm.
- **Sarith:** Fellow drow; Zalthir physically intervened to stop his compelled behavior toward the myconids.
- **Rump-a-dump:** Close friend; Zalthir is increasingly insistent the party rescue him, claims he would never be a threat.
- **Fargas Rumblefoot:** Pressed him hard about promised treasure; skeptical of his claims.
- **Buppido:** Buppido expressed interest in Zalthir being "part of my divine plan." Zalthir briefly suspected the Spectator identified Buppido as a demon.
- **Yukyuk & Spiderbait (goblin guides):** Impressed them with his acrobatics; privately considered using them to retrieve treasure.
- **Grygum:** Functional alliance; Grygum leveraged Zalthir's reputation as a threat against Plinki.
- **Thorin:** Some friction — Thorin encouraged Shuushar to leave before Zalthir could object.
- **Shuushar:** Valued his navigational skills; wanted him to stay.
- **Stool:** Used Stool's knowledge as a baseline for assessing myconid behavior.

## Arc Score Events
- No explicit arc score changes noted in source material.
