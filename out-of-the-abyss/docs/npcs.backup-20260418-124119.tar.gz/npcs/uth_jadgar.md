---
name: Uth-Jadgar
aliases: []
---

# Uth-Jadgar

## Identity
- Barrow Warden ghost; title: Barrow Warden
- First appeared at the grand moot, where he participated in strategic discussions with the party

## Personality & Motivations
- Takes pride in the legacy and tactical prowess of the Barrow Wardens. Appreciates well-crafted strategy, praising the party's plan as "technically brilliant" and comparing it favorably to Barrow Warden methods from their prime. Willing to offer aid in exchange for service — transactional but not hostile.

## History with the Party
- **Grand Moot:** Attended and praised the party's plan. Revealed that the Temple of the Steadfast Stone is located in the Rock Blight and must be cleansed before it can be used as a staging area. Offered the assistance of other Barrow Warden ghosts contingent on the party undertaking a quest for them. The party accepted and delegated Glabbagool, Eldev, and Jimjar to assist with the Barrow Wardens' quest.

## Current Status
- **Last known location:** At or near the grand moot gathering
- **Active plans:** Awaiting completion of the quest he proposed; Glabbagool, Eldev, and Jimjar have been assigned to assist
- **Party knowledge:** The party knows about the Temple of the Steadfast Stone's location in the Rock Blight, the need to cleanse it, and the offer of Barrow Warden ghost reinforcements. The specific details of the Barrow Wardens' quest are not elaborated in the notes.

## Relationships
- **Barrow Warden ghosts:** Leader or spokesperson; can mobilize them as allies if the quest is fulfilled
- **Glabbagool, Eldev, Jimjar:** Assigned by the party to work with the Barrow Wardens on their quest
- **The Party:** Cooperative relationship built on mutual exchange — respect for the party's tactical acumen, aid offered conditionally
