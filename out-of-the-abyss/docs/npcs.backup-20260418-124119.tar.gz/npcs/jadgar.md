---
name: Jadgar
aliases: []
---

# Borough Warden Jadgar

## Identity
- Ghost of a Svirfneblin (deep gnome), three feet tall
- Former Borough Warden of Blingdenstone; defended the city against the Drow and other threats
- First appeared in the catacombs beneath the Temple of the Ruby in the Rough, manifesting immediately after Pelek's spirit departed

## Personality & Motivations
- Core goal: Re-establish the Borough Wardens by secretly training young gnomes to serve in the reformed order
- Pragmatic and transactional — willing to share knowledge but demands something in return. Values fairness in exchanges and rewards effort (e.g., accepting a martial demonstration as valid payment for information). Carries the weight of a guardian who never stopped protecting his city, even in death.

## History with the Party
1. Appeared to the party in the catacombs after Pelek's ghost moved on.
2. Proposed a standing deal: for every ghost the party helps put to rest, he answers one question about the Underdark.
3. When asked about the ooze problem, explained that oozes are normally solitary — a mass infestation is highly unusual.
4. Zalthir raised a possible connection to Juiblex. Jadgar offered further insight in exchange for Zalthir demonstrating a monk technique he could teach his trainees.
5. After Zalthir performed an impressive martial display, Jadgar explained the distinction between devils (corrupt individuals through personal deals) and demons (empower proxies to cause widespread carnage).
6. Advised the party to search for an intermediate agent — a proxy empowered by a demon to motivate the oozes.
7. Recommended they speak with a young gnome he is mentoring (the future leader of the new Borough Wardens), once the party has gathered more information.

## Current Status
- **Location:** Catacombs beneath the Temple of the Ruby in the Rough, Blingdenstone
- **Active operations:** Secretly training young gnomes to re-establish the Borough Wardens
- **Standing deal with the party:** One answered question per ghost laid to rest — still active
- **Hidden:** The identity of the young gnome he is mentoring has not yet been revealed; he withheld it until the party gathers more information

## Relationships
- **Pelek:** Fellow ghost; Jadgar appeared immediately after Pelek's spirit was put to rest
- **Young gnome protégé:** Unnamed mentee being groomed to lead the new Borough Wardens
- **Zalthir (party member):** Positive rapport — Jadgar was impressed enough by Zalthir's martial demonstration to share additional intelligence
- **The Party (general):** Transactional but cooperative; sees them as useful allies in both laying ghosts to rest and investigating the ooze threat

## Arc Score Events
- Helping Pelek's spirit depart triggered Jadgar's appearance and opened the transactional relationship (likely positive arc progression for Blingdenstone/Borough Wardens).
- Zalthir's martial demonstration deepened the exchange, unlocking additional information about the demonic threat.
