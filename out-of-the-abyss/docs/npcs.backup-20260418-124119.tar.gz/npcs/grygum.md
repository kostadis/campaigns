---
name: Grygum
aliases: []
---

# Grygum

## Identity
- Cleric of Bahamut, though he references "the lessons of his cult," suggesting an unorthodox or fringe sect rather than a mainstream faith
- Fellow prisoner alongside the party; first appeared during a prison breakout/escape sequence

## Personality & Motivations
- Pragmatic and tactically minded — he equipped himself at the armory before heading into danger, reasoning "an armed cleric is better than a disarmed one." He treats spell slots as precious non-renewable resources and openly laments his lack of ranged options. He has a mischievous streak, making dry jokes and goading enemies with taunts like "Come get it, idiot." He is willing to stab an ally in the face if a punch won't do the job.

## History with the Party
1. **Prison Escape:** Followed other prisoners to the armory to equip himself. Healed a critically wounded Thorin with a magical touch, restoring him from near-death. Attempted Toll the Dead against the Drow Imbros (resisted). After Prince Derendil's death drove Serith mad, Grygum telepathically calmed Serith by redirecting his rage toward spirituality.
2. **Fargas's Bargain & the Spectator:** Produced notes of Fargas's earlier statements and pressured him to honor his deal. Assessed Fargas's truthfulness and vouched for him. Bet Jimjar that the deep gnome couldn't convince a Spectator they weren't demons. Fired his handheld crossbow during the Spectator fight.
3. **Blingdenstone — Realm of the Rock:** Welcomed by a Galeb Duhr to "the Realm of the Dragon" (corrected to "the Realm of the Rock"); joked about being in a cavern. Recognized the "Lady of Rot" as Zuggtmoy, alarming Blingdenstone's leaders. Summoned a bat familiar to scout the Festering Fissure, chanted a protective warding prayer during the lichen harvest. Punched Zalthir to break a hypnotic trance — the blow was too weak, so he stabbed Zalthir with a dagger instead. Sensed the Galeb Duhr were waiting for divine authority at the White Shell Mine. Provided a blessing to aid Zalthir's meditation before an explosive tunnel breach. Was present when Thorin deciphered giant runes requiring three sacrifices.
4. **Bridge Ambush / Big Heart Fungus:** Lent his light crossbow to Thorin. Inscribed an invisible Glyph of Warding on the bridge (triggered by hostile creatures). Applied the Dust of Suleiman directly onto the Big Heart Fungus. Baited Jorlan across the bridge, detonating the glyph for 21 damage and destroying a spore servant. Noted the combined Dust + Fireball effect exceeded expectations.

## Current Status
- Last seen at the bridge encounter following the destruction of the Big Heart Fungus
- Down to limited spell resources (one 4th-level slot was treated as non-renewable)
- Aware of Zuggtmoy's threat and the summoning circle requiring three sacrifices
- **Hidden:** The exact nature of his "cult" and its relationship to Bahamut remain unexplained

## Relationships
- **Thorin:** Saved his life with healing magic during the escape; lent him his crossbow later. Recurring protective dynamic.
- **Zalthir:** Blessed his meditation; also stabbed him in the face to break a trance — a practical if blunt camaraderie.
- **Serith:** Telepathically calmed him after Derendil's death, redirecting his grief into spirituality.
- **Jimjar:** Friendly enough to make bets with him.
- **Fargas:** Held him accountable to his word; vouched for his honesty to the group.
- **Jorlan:** Hostile — baited him into a trap and detonated a glyph on him.
- **Imbros (Drow):** Opposed during the escape; Imbros resisted Grygum's Toll the Dead.
- **Galeb Duhr of Blingdenstone:** Received warmly; recognized as having divine authority.
