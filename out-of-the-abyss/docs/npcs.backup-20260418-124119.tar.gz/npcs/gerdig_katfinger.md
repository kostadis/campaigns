---
name: Gerdig Katfinger
aliases: []
---

# Gerdig Katfinger

## Identity
- Provided the party with a Ruby spell gem prior to the events described
- No further details on role, title, or faction affiliation available in source notes

## Personality & Motivations
- Insufficient information to characterize personality or motivations from available notes.

## History with the Party
- At some point before the session described, Gerdig gave the party a **Ruby spell gem**.
- The gem was later used by **Grygum**, who placed it into the great menhir at the center of an ancient temple to begin a **hallowing ritual** aimed at cleansing the site of **Ogremoch's Bane**.

## Current Status
- Last known status and location are not specified in the notes.
- No active plans or operations described.

## Relationships
- **Grygum**: Recipient (directly or through the party) of the Ruby spell gem Gerdig provided.
- No other relationships specified.

## Arc Score Events
None noted.
