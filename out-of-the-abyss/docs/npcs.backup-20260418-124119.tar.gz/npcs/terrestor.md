---
name: Terrestor
aliases: []
---

# Terrestor

## Identity
- Alleged evil wizard from the Kingdom of Nelrindenvane
- Never encountered by the party; exists only in Prince Derendil's stories

## Personality & Motivations
- Supposedly a malevolent wizard who cursed Derendil into Quaggoth form and exiled him from his kingdom. No verified personality traits exist, as Terrestor is almost certainly a fictional character invented by Derendil.

## History with the Party
- Mentioned by Prince Derendil as the villain responsible for his cursed transformation. The party has never met or interacted with Terrestor directly.

## Current Status
- **Likely does not exist.** Daz knows that Derendil's entire backstory — including the Kingdom of Nelrindenvane — is fabricated. Terrestor is part of that fabrication.
- The broader party may not yet know Derendil's story is false.

## Relationships
- **Prince Derendil:** Cast as Derendil's nemesis in his self-told origin story.
- **Daz:** Knows Derendil's story is fabricated, meaning Daz likely understands Terrestor is fictional.

## Arc Score Events
None applicable.
