---
name: Jorlan
aliases: []
---

# Jorlan

## Identity
- Male Drow fighter, formerly stationed at Velkynvelve outpost
- Former favored consort of Priestess Ilvara; demoted after disfigurement
- First encountered escorting the party to their prison cell at Velkynvelve

## Personality & Motivations
- Driven entirely by jealousy, bitterness, and revenge against Ilvara and Shoor. His hatred is so consuming that it rendered him immune to Zuggtmoy's spore enslavement.
- Calculating and self-aware — willing to help enemies escape not out of compassion but to humiliate his rivals. Openly admits he doesn't care if the prisoners succeed.
- Reckless when his rage is provoked, as demonstrated when he charged headlong into a trap after being taunted.

## History with the Party
1. **Velkynvelve (Prison):** Escorted the party to their cell. Was identified by Jimjar as Ilvara's former romantic partner, replaced by Shoor after his injury.
2. **Escape Offer:** Approached Thorin during a food delivery and proposed helping the prisoners escape — leaving the prison door open, creating a distraction, and clearing the path to the armory. His motive was purely to embarrass Shoor and make Ilvara regret choosing him. Acknowledged the party's distrust: *"You are wise not to trust me."*
3. **Bridge Battle:** The party allied with Asha Vandree over Jorlan. Jorlan was positioned across the bridge from the party. Grygum (or Thorin — accounts vary on who taunted) called out *"Come get it, idiot!"* and Jorlan charged across, triggering a Glyph of Warding for 21 damage that also destroyed a spore servant and damaged the Heart Fungus. Thorin followed up with a critical hit from Dawnbringer (14 damage) and applied the Sap technique, imposing disadvantage.

## Current Status
- **Last known:** Staggered but still standing on the bridge, wounded and furious, mid-combat
- **Condition:** Took at least 35 combined damage; reeling but not yet down (AC 18)
- **Allegiance:** Uninfected by Zuggtmoy's spores due to his hatred; hostile to the party after the bridge ambush

## Relationships
- **Ilvara:** Former romantic partner. Deeply bitter about being discarded after his disfigurement. His entire motivation revolves around making her regret her choice.
- **Shoor:** Ilvara's current consort and Jorlan's replacement. Jorlan despises him and wants to see him humiliated.
- **Asha Vandree:** Fellow uninfected drow. Asha expressed exhaustion at being caught between Jorlan and Ilvara's drama for months. The party chose Asha's side over Jorlan's.
- **Thorin:** Initially approached Thorin to broker the escape deal; now direct combat enemies. Thorin landed a critical hit on him during the bridge fight.
- **Grygum:** Inscribed the Glyph of Warding that Jorlan triggered; may have been the one to taunt him into charging.

## Arc Score Events
- **Escape alliance offer** — potential positive shift (party received his help planning the Velkynvelve escape)
- **Party chose Asha over Jorlan and set a trap specifically targeting him** — significant negative shift; Jorlan is now openly hostile
