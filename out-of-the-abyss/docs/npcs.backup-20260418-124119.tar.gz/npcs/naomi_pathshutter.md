---
name: Naomi Pathshutter
aliases: []
---

# Naomi Pathshutter

## Identity
- Community leader or earth-magic practitioner in a mining settlement
- Associated with efforts to commune with earth elementals and navigate subterranean sacred sites
- First appeared in a crowded meeting hall the morning after the party dealt with threats in the tunnels

## Personality & Motivations
- Driven to restore the sacred underground paths and communicate with the earth — she pushed herself to exhaustion over forty-eight hours attempting to summon earth elementals. Frustrated that hallowing Ogremoch's altar did not open the expected route to Entemoch's boon. Capable of genuine respect once she recognizes competence, as shown when she learned of the party's accomplishments. Can be socially blunt or careless, as demonstrated by mistaking Daz for an ogre.

## History with the Party
- **Meeting Hall Briefing:** Naomi spread a map before the party and explained the situation — the tunnels to Entemoch's throne had shifted and sealed after Ogremoch's altar was hallowed, and the earth seemed frozen, unable to heal itself. Miners reported strange vibrations, as if the rock was trying to communicate but couldn't.
- **Social Misstep with Daz:** She mistook Daz for an ogre, causing a tense exchange about respect. The community rallied to defend the party as allies.
- **Shift to Respect:** When the party revealed they had defeated four insane earth elementals and a Medusa, Naomi's demeanor changed to genuine admiration.
- **Quest Given:** She tasked the party with investigating the strange vibrations and finding the lost path to Entemoch's boon.

## Current Status
- **Last Known Location:** The meeting hall in the mining settlement.
- **Active Plans:** Attempting to summon earth elementals and restore communion with the earth; waiting on the party to investigate the vibrations and locate the path to Entemoch's throne.
- **Known vs. Hidden:** The party knows about the sealed tunnels, the failed summoning attempts, the strange vibrations, and the quest objective. It is unclear what deeper knowledge Naomi may hold about Ogremoch, Entemoch, or why the earth is "frozen."

## Relationships
- **Daz (Party Member):** Rocky start — she mistook him for an ogre, causing offense. Relationship likely improved after she expressed genuine respect for the party's deeds.
- **The Party (General):** Initially dismissive or unaware of their capabilities; now views them with admiration and has entrusted them with a critical task.
- **The Mining Community:** Appears to hold a leadership or advisory role; the community backed the party during the tense exchange, suggesting shared trust between Naomi's people and the adventurers.
- **Entemoch / Ogremoch:** Deeply invested in the spiritual/elemental politics of the underground — she hallowed Ogremoch's altar and seeks Entemoch's boon.

## Arc Score Events
- **Increase:** Naomi's respect for the party increased significantly upon learning they had defeated four insane earth elementals and a Medusa.
- **Decrease (minor/potential):** The awkward moment of mistaking Daz for an ogre introduced brief tension, though the community's intervention and her later admiration likely offset this.
