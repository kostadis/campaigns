---
name: Senni
aliases: []
---

# Senni

## Identity
- Quartermaster of Blingdenstone; represents the non-mining population of the city
- First mentioned by guards at the city entrance as someone the party should speak with about gaining full permissions (particularly regarding Glabagool)

## Personality & Motivations
- Advocates for the broader civilian populace of Blingdenstone, not just the mining interests. Willing to challenge Chief Dorbo publicly when she believes he's failing the community—she confronted him directly in Diggermattock Hall over his inadequate response to the ooze infestation. More diplomatically open than Dorbo, particularly regarding reconciliation with the Gold Whisker clan, whom Dorbo suspects of being wererats.

## History with the Party
1. **Guards' recommendation:** City guards told the party to seek out Senni and Chief Dorbo about full city permissions, especially concerning Glabagool's presence.
2. **Diggermattock Hall confrontation:** The party witnessed Senni clash with Chief Dorbo over the ooze infestation and observed her more conciliatory stance toward the Gold Whisker clan.
3. **Grand Moot:** Senni had previously agreed to support Daz's plan. At the grand moot, she asked Daz to lead and call the meeting to order, positioning him in a leadership role among Blingdenstone's major leaders.

## Current Status
- **Last known location:** Diggermattock Hall, present at the grand moot among Blingdenstone's leadership.
- **Active concerns:** The ooze infestation and its resolution; possible reconciliation with the Gold Whisker clan.
- **Party knowledge:** The party knows she is the Quartermaster, that she opposes Dorbo on the ooze issue, and that she is supportive of Daz's plans. No hidden information indicated in the notes.

## Relationships
- **Chief Dorbo Diggermattock:** Political tension—they clash over the ooze infestation and the Gold Whisker situation, though they serve together in Blingdenstone's leadership.
- **Daz (party member):** Supportive; she backed his plan and deferred to him to lead the grand moot.
- **Gold Whisker clan:** More open to reconciliation than Dorbo.
- **The Party:** Generally cooperative; a gatekeeper for city permissions alongside Dorbo.
