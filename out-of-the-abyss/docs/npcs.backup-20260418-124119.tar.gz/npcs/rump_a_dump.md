---
name: Rump-a-dump
aliases: []
---

# Rump-a-dump

## Identity
- Myconid sprout; friend and circle-mate of Stool
- Originally from Neverlight Grove
- First mentioned by Stool, who urged Zalthir to seek him out; later found in person among dancing Myconids in a cave

## Personality & Motivations
- Terse, precise, and restrained — a sharp contrast to Stool's enthusiastic chattiness. Quick-witted and unafraid to push back (e.g., countering the cannibalism accusation with a pointed comparison to humanoid eating habits).
- Core drive: deep concern for his people in Neverlight Grove and a desire to understand and reverse whatever Voosbur's strange spores have done to the Myconid community.

## History with the Party
1. **Initial mention:** Stool told Zalthir that Rump-a-dump was unhappy and needed to be found and brought back. Stool vouched for his character, insisting he was friendly and would never allow the party to be turned into zombies. Zalthir deferred, prioritizing survival.
2. **First meeting:** The party found Rump-a-dump among the dancing Myconids in the cave. He was visibly uncomfortable and worried. He explained the situation: Voosbur released strange spores that changed the other Myconids, who began dancing unnaturally. After Voosbur's spores transported them from Neverlight Grove, the others ate strange mushrooms (shrinking/growing kind) and became affected. Rump-a-dump refused to eat them and remains unaffected. He told the party that the dances and talk of "the Lady's dream" are not the way of Myconids — it is forced. He expressed fear that Voosbur's spores may have infected Neverlight Grove and hoped the Sovereign there might know a way out.

## Current Status
- **Last known location:** The cave with the dancing Myconids
- **Active concerns:** Fears Voosbur's spores have spread to Neverlight Grove; hopes the Sovereign there can help
- **Party knowledge:** The party understands the threat of Voosbur's spores, the unnatural dancing, "the Lady's dream," and that Rump-a-dump is unaffected because he didn't eat the mushrooms. The full nature of Voosbur's spores and "the Lady" remains unclear.

## Relationships
- **Stool:** Close friend and circle-mate. Stool cares deeply about Rump-a-dump's wellbeing and vouched for him to the party.
- **Zalthir:** Stool's primary point of contact in the party regarding Rump-a-dump; Zalthir initially deferred the quest.
- **Voosbur:** Source of the strange spores that displaced and altered the Myconids; Rump-a-dump views Voosbur's influence as dangerous and antithetical to Myconid ways.
- **Neverlight Grove Sovereign:** Rump-a-dump's hope for answers and a potential cure.
- **Thorin:** Brief exchange — Thorin suggested eating mushrooms was cannibalism; Rump-a-dump rebutted sharply.
