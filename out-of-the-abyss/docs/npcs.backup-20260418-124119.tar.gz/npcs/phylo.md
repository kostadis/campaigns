---
name: Phylo
aliases: []
---

# Phylo

## Identity
- Co-sovereign of Neverlight Grove, sharing power with Basidia
- Devoted agent of the "Great Seeder" (Zuggtmoy), working to prepare the grove for Zuggtmoy's wedding to Araumycos
- First encountered when the party arrived at Neverlight Grove; greeted them warmly using rapport spores

## Personality & Motivations
- Core goal: Serve Zuggtmoy by restructuring myconid society and preparing the "great celebration" / "great awakening" — the wedding between Zuggtmoy and Araumycos.
- Outwardly warm, enthusiastic, and welcoming, but manipulative and deceptive. Uses language of joy, wonder, and community improvement to disguise sinister intent. Explicitly steered the party away from the eastern plateau and the Garden of Welcome, where visitors are transformed into fungal spore servants.

## History with the Party
- **Arrival at Neverlight Grove:** Greeted the party with rapport spores. Proclaimed a "day of joy" was approaching and encouraged them to explore — but warned them away from the eastern plateau, promising a "peek" at the surprise the next day.
- **Directed party toward the Great Seeder:** Described the entity as "wonderful" and one who would "help all of us get closer to her beauty." Daz identified the female pronouns as unusual for myconids and connected them to Zuggtmoy.
- **Garden of Welcome revealed as a trap:** The Circle of Welcome, which Phylo invited Xinaya to visit, turned out to transform visitors into fungal spore servants. A previous group of "softers" who accepted Phylo's offer to visit the Garden have not been seen since — Phylo made no mention of them.

## Current Status
- **Last known location:** Neverlight Grove, acting as co-sovereign.
- **Active plans:** Orchestrating the grove's transformation in service of Zuggtmoy's wedding to Araumycos. Mandates all dead creatures be brought to the Circle of Masters for reanimation. Continues to funnel visitors toward the Garden of Welcome.
- **What the party knows:** The party is aware that Phylo serves Zuggtmoy, that the Garden of Welcome is a trap, that Phylo's restructuring serves sinister ends, and that previous visitors were disappeared.
- **What may remain hidden:** The full scope of Phylo's control over the grove's circles; the exact timeline and mechanics of the Zuggtmoy–Araumycos wedding; whether Phylo can be separated from Zuggtmoy's influence.

## Relationships
- **Basidia** (co-sovereign): Deep ideological rift. Basidia believes Phylo has contracted a "diseased spore" and views Phylo's restructuring — eliminating communal melds in favor of hierarchical, siloed circles — as contrary to myconid unity.
- **Zuggtmoy ("The Great Seeder"):** Phylo's true master. Phylo speaks of her with reverence and devotion.
- **Circle of Masters:** Phylo's inner circle of closest followers; oversee the Garden of Welcome and handle reanimation of the dead.
- **Inner Circle:** Circle leaders loyal to Phylo who enforce the new social hierarchy.
- **Hepbobe:** Downplayed Basidia's concerns about Phylo, framing the conflict as mere organizational preference.
- **Daz** (party): Identified the Zuggtmoy connection through Phylo's unusual use of gendered pronouns.
- **Xinaya** (party): Phylo specifically invited Xinaya to visit the Circle of Welcome (the trap).

## Arc Score Events
- No explicit arc score changes noted in the source material.
