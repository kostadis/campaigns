---
name: Yukyuk
aliases: []
---

# Yukyuk

## Identity
- Goblin guide of the Silken Paths (paired with Spiderbait)
- Color motif: orange
- First encountered at the entrance to the Silken Paths, where he and Spiderbait offered their guiding services to the party

## Personality & Motivations
- Core goal: earn a living guiding travelers across the Silken Paths (2 gold per day)
- Enthusiastic and expressive, with a surfer-like speech pattern once his formal business demeanor drops. Quick to anger when cheated (threw his beanie on the ground when Jimjar couldn't pay a bet), but easily won back over by impressive feats. Described posthumously by Spiderbait as "the kindest, gentlest goblin you could imagine."

## Appearance
- Relaxed comfortable shoes, baggy pants, long-sleeved wide shirt, and a beanie
- Covered in tattoos written in draconic script — actually goblin words using draconic characters, with incorrect spelling

## History with the Party
1. **Silken Paths entrance:** Introduced himself and offered to guide the party for 2 gold/day. Jimjar tricked him and Spiderbait into a bet demonstrating their skills, then couldn't pay. Yukyuk was furious but Spiderbait negotiated a deal to guide the party until the debt was repaid.
2. **During the crossing:** Dropped his formal tone and excitedly told Topsy about his web-surfing moves. Reassured Zalthir that web vibrations wouldn't attract spiders. Shared lore about a "crazy Drow wizard" who tried to burn the Silken Paths but failed because the spiders rebuilt faster. When spiders were detected near a cocoon, his advice was: "Get out of here."
3. **After the spider/Spectator encounter:** Critiqued the group's tactics, suggesting they should have slid under the spiders and cut the web. Was very impressed by Zalthir's acrobatic combat move, calling it "next-level spider walking." This admiration convinced him and Spiderbait to stay with the group despite Jimjar's unpaid debt.
4. **Murdered:** Found dead at the start of a subsequent session. Killed by Buppido, who claimed it was part of a "divine plan." He had nothing of value on him.

## Current Status
- **Dead.** Murdered by Buppido.
- The party knows Buppido is responsible and that he framed it as divinely ordained.

## Relationships
- **Spiderbait:** Business partner and fellow guide; Spiderbait was the more diplomatic of the two and mourned his death deeply.
- **Jimjar:** Source of frustration — Jimjar's bet scam angered Yukyuk and nearly cost the party their guides.
- **Zalthir:** Earned Yukyuk's genuine admiration through acrobatic combat; this was the key reason Yukyuk stayed with the group.
- **Topsy:** Friendly — excitedly shared his web-surfing stories with her.
- **Buppido:** His killer.

## Arc Score Events
- Buppido's murder of Yukyuk likely constitutes a significant narrative event tied to Buppido's arc (direction: escalation of Buppido's "divine plan" killings).
