---
name: Sarith (also referred to as "Sathir" in the text)
aliases: []
---

# Sarith

## Identity
- Drow NPC, fellow escapee from Velkynvelve
- Knowledgeable Underdark navigator and survivalist
- First appearance: part of the group of prisoners escaping Velkynvelve

## Personality & Motivations
- Core goal: survive the escape from Velkynvelve and evade the pursuing drow
- Pragmatic and competent — focuses on food, water, and tactical movement. Quick to suggest harvesting a slain creature for rations and to assess the group's resource situation. Prideful about his skills; visibly annoyed when Grygum spotted a route before he did, though he grudgingly acknowledged the help. Takes a leadership role in navigation and planning without being asked.

## History with the Party
- **Rockfall Encounter:** Survived the rockfall unscathed (Zalthir confirmed he was not under the rocks).
- **Giant Centipede Fight:** Fought alongside Buppido, Topsy, and Turvy using a hand-held crossbow; helped kill the creature with his bolts. Immediately shouted "Rations!" to suggest harvesting the corpse for food.
- **Drow Pursuit Briefing:** Provided critical intelligence when the group realized drow scouts from Velkynvelve were pursuing them. Explained how Underdark tunnels twist and change, allowing enemies to appear suddenly. Warned that non-flying surface-dwellers ("Overbriters") are the easiest prey in the Underdark. Stressed the need to keep moving.
- **Faerzess Cave Navigation:** Was actively searching for the next tunnel route. Grygum found it first; Sarith was visibly annoyed but acknowledged Grygum's contribution before rushing down the tunnel.
- **End-of-Day Assessment:** Gave a cautiously positive report on distance gained from pursuers. Warned of a critical water shortage. Ordered Eldeth to cover their trail the following day and recommended slower, more careful travel. Revealed that **Ilvara has found and caught up with them**, urging the group to either gain distance or obscure their trail.

## Current Status
- **Last known location:** Traveling with the party through Underdark tunnels, one day's travel from Velkynvelve
- **Active concerns:** Water shortage is urgent; Ilvara and drow pursuers have caught up; ordered Eldeth to cover the trail next day and the group to slow their pace
- **Known vs. hidden:** The party knows he is a capable Underdark guide and competent fighter. No hidden motivations have been revealed yet, though his drow background and knowledge of the pursuers may warrant scrutiny.

## Relationships
- **Grygum:** Mild friction — annoyed when Grygum spotted a route before him, but acknowledged the help
- **Eldeth:** Gives her direct orders (told her to cover the trail); she appears to accept his tactical authority
- **Buppido:** Fought alongside him during the centipede battle; Buppido earlier shouted that Sarith was supposed to rescue him per "the divine plan" (Sarith's reaction unrecorded)
- **Topsy & Turvy:** Fought alongside them during the centipede encounter
- **Ilvara:** Knows her by name; aware she is personally leading the pursuit — suggests prior familiarity or knowledge of drow command structure
- **Zalthir:** Zalthir checked on his status after the rockfall

## Arc Score Events
No explicit arc score changes noted in the source material.
