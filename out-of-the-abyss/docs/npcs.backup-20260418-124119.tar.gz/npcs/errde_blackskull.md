---
name: Errde Blackskull
aliases: []
---

# Errde Blackskull

## Identity
- Captain of the Stone Guards, Gracklstugh
- Based at Overlake Hold
- First approached the party at the Darklake Brewery with a group of Duergar bearing stone weapons; invited them to her office for a conversation

## Personality & Motivations
- Core goal: expose what she believes is deep corruption in the Deepking's court, linked to the Council of Savants and possibly elements of the Clan Lairds. She sees this as her path to the Deepking's favor.
- Pragmatic and resourceful — willing to use outsiders for tasks she can't handle with her own forces due to political constraints. Combines hospitality (pastries, warm drink) with veiled threats. Responded to Daz's challenge with composure and a smile rather than hostility.

## History with the Party
1. **Darklake Brewery:** Approached the party with armed Stone Guards. When Daz challenged whether this was a threat, she defused the tension and assured them it was friendly.
2. **Overlake Hold Meeting:** Served refreshments, then laid out her request — track down a Duergar named Droki in the West Cleft District (Derro territory). She cannot send Stone Guards there without provoking violence. She validated the party's observations of corruption at the Blade Bazaar. Offered 175gp in equipment upfront, 175gp more on delivery of Droki and proof of conspiracy. Also leveraged a powerful incentive: she can tell any Drow searching for escaped slaves that those slaves are not in the city, effectively guaranteeing the party's freedom.
3. **Party's later avoidance:** The party grew wary of Errde and deliberately chose to avoid her, fearing imprisonment and torture for information. They planned to use Gartokkar as their escape route from the city instead.

## Current Status
- **Last known location:** Overlake Hold, Gracklstugh
- **Active operations:** Hunting Droki and the conspiracy she believes runs through the Council of Savants and Clan Lairds
- **What the party knows:** She made them a deal and has power over their freedom regarding Drow pursuit
- **What remains hidden from her:** According to intercepted letters (Aliinka's and Narrak's), Errde is described as consumed by "conspiracy theories" and "hunting phantoms" — she is unwittingly aiding a cult's efforts to sow discord in the city. She does not appear to know she is being manipulated.

## Relationships
- **The Party:** Transactional alliance, now strained. The party fears her and is actively avoiding contact.
- **The Deepking:** Seeks his favor through exposing corruption
- **Council of Savants / Clan Lairds:** Suspects them of conspiracy
- **Droki:** Her primary investigative target
- **The Cult (Aliinka, Narrak):** They view her as a useful fool whose paranoia serves their agenda — she is unaware of this
- **Gartokkar:** Indirectly relevant — the party chose him over Errde as their exit strategy
- **Daz:** Initial point of friction; Daz challenged her directly at first meeting

## Arc Score Events
- No explicit arc score changes noted in source material.
