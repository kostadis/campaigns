---
name: Errde Blackstaff
aliases: []
---

# Errde Blackstaff

## Identity
- Faction leader in Gracklstugh (specific faction/title not named in notes)
- Has not appeared directly to the party; known through intermediaries and references

## Personality & Motivations
- Core goal: Obtain evidence of Demogorgon's influence among the Derro — though she may have a predetermined agenda and is willing to fabricate justification if real evidence isn't provided.
- Pragmatic and politically calculating. Willing to use outsiders as expendable assets to avoid triggering inter-faction violence in Gracklstugh.

## History with the Party
- **Pre-contact:** Was among the faction leaders in Gracklstugh anxious to find non-Duergar willing to venture into the Derro slums to locate Droki, since sending Duergar would trigger a bloodbath.
- **Indirect reference via Daz:** Daz informed the party that Errde wants evidence of Demogorgon's influence among the Derro. Daz suggested the books and papers found in Narrak's ritual cavern would likely satisfy her. Daz also warned that if she doesn't get evidence, "she'll invent it."

## Current Status
- **Last known location:** Gracklstugh (exact location unspecified)
- **Active plans:** Awaiting evidence of demonic influence among the Derro; the party has potentially relevant documents from Narrak's ritual cavern
- **Hidden information:** Her willingness to fabricate evidence if none is provided (the party has been warned of this by Daz, so they are at least partially aware)

## Relationships
- **Daz:** Appears to serve as an intermediary or informant connected to Errde; knows her methods and disposition well enough to warn the party about her tendencies
- **The Party:** Has not met them directly; views them as useful non-Duergar operatives for dangerous work in the Derro slums
- **The Derro:** Politically opposed; seeks justification to act against them
