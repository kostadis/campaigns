---
name: Khaem
aliases: []
---

# Khaem

## Identity
- Historical figure associated with the Lost Tomb of Khaem, a dungeon/burial site
- Not encountered as a living NPC; known only as the namesake of the tomb

## Personality & Motivations
- Unknown. Khaem has not appeared as a living or interactive character.

## History with the Party
- The party identified the Lost Tomb of Khaem as a destination, planning to visit it to secure a weapon before proceeding to Neverlight Grove.

## Current Status
- **Location:** Entombed (presumed deceased) within the Lost Tomb of Khaem
- **Party knowledge:** The party knows the tomb exists and believes it contains a weapon worth acquiring. No further details about Khaem personally are known.

## Relationships
- No known relationships established in play.

## Arc Score Events
- None.
