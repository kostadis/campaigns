---
name: Guldor
aliases: []
---

# Guldor

## Identity
- Drow guard at the Drow outpost
- Assigned to chamber pot cleaning detail — a punishment duty suggesting he failed at something previously
- First encountered by the party during their captivity at the outpost

## Personality & Motivations
- Takes his diminished role seriously despite its lowly nature. Vigilant and threatening toward prisoners, clearly keen to avoid further failures. Maintains authority through intimidation, warning captives he can cut them off at the lake if they attempt to flee.

## History with the Party
- **Chamber pot detail:** Supervised prisoners Daz, Sarith, and Stool during the cleaning run. Warned Daz explicitly that he could reach the lake before any of them could escape.
- **Kitchen incident:** Caught Gyrgum attempting to steal a knife and threatened him with severe consequences.

## Current Status
- **Location:** Stationed at the Drow outpost
- **Activity:** Continuing guard duties on the chamber pot detail
- **Hidden info:** The nature of his original failure that landed him on punishment duty remains unknown to the party

## Relationships
- **Suushar:** Described Guldor's assignment as "the dirty job," implying awareness of his diminished standing among the Drow
- **Daz, Sarith, Stool:** Prisoners under his direct supervision during the chamber pot run
- **Gyrgum:** Caught him stealing; antagonistic dynamic
