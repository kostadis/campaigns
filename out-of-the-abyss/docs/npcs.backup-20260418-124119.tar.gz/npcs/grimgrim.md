---
name: Grimgrim
aliases: []
---

# Grimgrim

## Identity
- Duergar assassin; guard/enforcer affiliated with the assassin's guild
- First appeared at the intersection near the assassin's lair, materializing alongside Rust

## Personality & Motivations
- Core goals and drives are unclear beyond serving as muscle for the guild.
- Functions as a loyal subordinate, following orders and standing guard without notable independent action.

## History with the Party
1. Materialized alongside Rust at the intersection near the assassin's lair, confronting or intercepting the party.
2. Served as one of the guards positioned behind the party during their meeting with Eldgrim.
3. Was actively distracted by Thorin, who engaged him and Rust with questions about the guild's name — providing cover for Daz to steal the contract from Eldgrim's desk.

## Current Status
- Last known location: the assassin's lair, serving as Eldgrim's guard.
- No independent plans or operations noted.
- **Unknown to Grimgrim:** Daz successfully stole the contract during the meeting while he was distracted.

## Relationships
- **Rust:** Fellow guard; the two operate as a pair, appearing and working together.
- **Eldgrim:** Superior within the guild; Grimgrim serves as his bodyguard during meetings.
- **Thorin:** Was directly engaged/distracted by Thorin during the contract theft.
- **Daz:** Unaware that Daz stole the contract under his watch.
