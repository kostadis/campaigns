---
name: Thangus Ironhead
aliases: []
---

# Thangus Ironhead

## Identity
- Clan leader of Clan Ironhead
- Encountered when the party secured an audience using their badges

## Personality & Motivations
- Publicly presents as a loyal supporter of the Deepking, endorsing Clan Steelshadow's pre-eminence. However, the party strongly suspects this is a survival tactic rather than genuine loyalty. Daz assessed him bluntly: "He's lying and trying to survive." Zalthir was similarly unconvinced of his honesty.

## History with the Party
- The party used their badges to gain an audience with Thangus. During the meeting, he declared Clan Ironhead's approval of the Deepking's policies and Clan Steelshadow's supremacy. The party saw through this as performative loyalty.
- A stolen contract found on Eldgrim's desk, written under the Deepking's seal, names Thangus Ironhead. The contract orders him **boiled in oil and fed to roaches** for attempting to "encroach on my family's business" — indicating the Deepking has already marked him for execution.

## Current Status
- **Last known:** Leading Clan Ironhead, publicly maintaining a façade of loyalty to the Deepking.
- **Hidden from Thangus (unknown):** Whether he is aware of the death contract bearing his name is unclear from the notes.
- **What the party knows:** The party knows both that Thangus is lying about his loyalty *and* that the Deepking has signed a contract for his gruesome execution. This gives them significant leverage or reason to warn him.

## Relationships
- **The Deepking / Clan Steelshadow:** Publicly deferential, but the Deepking views him as an encroacher on Steelshadow business and has ordered his death.
- **Eldgrim:** The death contract was found on Eldgrim's desk, suggesting Eldgrim may be involved in carrying out or facilitating the execution order.
- **The Party:** Guarded interaction. The party sees through his act and possesses information that could save — or doom — him.
