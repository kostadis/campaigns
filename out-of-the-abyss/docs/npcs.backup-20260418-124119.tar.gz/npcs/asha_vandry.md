---
name: Asha Vandry
aliases: []
---

# Asha Vandry

## Identity
- Drow priestess, devout follower of Lolth
- Unaffiliated with Ilvara's faction; actively opposes her and rejects the "bride heresy" (the belief that Zuggtmoy's influence is a further manifestation of Lolth)
- First encountered in the fungal cavern as one of only three individuals not yet enslaved by Ilvara's spores

## Personality & Motivations
- Core goal: the death of Ilvara and the destruction of her mushroom artifact. She cannot accomplish this alone and has allied with the party to see it done.
- Paranoid, sharp, and deeply contemptuous of those she considers beneath her — she treats Zalthir and Grygum with open disdain while directing all meaningful conversation toward Daz. She refuses physical contact out of a visceral fear of fungal contamination. Despite her severity, she shows flashes of relatable exasperation, particularly regarding Jorlan and Ilvara's unresolved romantic entanglement. Her faith in Lolth is genuine and functions as a lens through which she interprets everything, including deception attempts against her.

## History with the Party
- **Fungal Cavern Encounter:** Daz attempted to deceive her with a staged divine visitation from Lolth (Dancing Lights + spider familiar). She saw through it but reframed the deception as a divine test of her own discernment, believing she had *passed* Lolth's test by identifying Daz as a charlatan.
- Questioned whether the party had been infected by Zuggtmoy's spores, suspecting their behavior might be fungal madness.
- Provided critical tactical intelligence: the Heart Fungus does not cause the spore illness — only Ilvara's spores and her mushroom artifact do (qualified with "I believe"). Warned that **Thorin and Grygum specifically** must not approach the artifact due to a marker they picked up in the Whorlstone Caverns of Gracklstugh.
- Advised the party to target the Heart Fungus with their most powerful spell rather than Ilvara directly. Openly mocked Grygum's suggestion to use Phantasmal Killer on Ilvara.
- Was briefly alarmed by Glabbagool's visible eyes but was impressed when Thorin introduced the ooze as Daz's familiar.
- Explained that the spore servants were former drow allies who had willingly embraced Ilvara's spores.
- **Negotiation concluded** with a tentative alliance: the party kills Ilvara and destroys the mushroom artifact; in exchange, the party receives everything Ilvara has accumulated.

## Current Status
- **Last known location:** The fungal cavern, waiting for the party to carry out the assault on Ilvara.
- **Active plan:** Relying entirely on the party to kill Ilvara and destroy the mushroom artifact. She cannot or will not perform the assault herself.
- **Known to party:** Her tactical intelligence about the Heart Fungus, the artifact, and the Whorlstone marker warning. Her hatred of Ilvara and the terms of the alliance.
- **Potentially hidden:** The identity of the implied third uninfected individual (herself, Jorlan, and one other). The full extent of her knowledge about Lolth's involvement or non-involvement. Whether her "I believe" qualifier about the artifact reflects genuine uncertainty or deliberate hedging.

## Relationships
- **Ilvara:** Deep, bitter hatred. Wants her dead in the strongest possible terms.
- **Jorlan:** Fellow uninfected survivor. Asha is exhausted by having to mediate between Jorlan and Ilvara's unresolved romantic drama.
- **Daz:** The only party member she treats as a worthy interlocutor. Sees him as the group's leader.
- **Zalthir & Grygum:** Dismissed with disdain or outright ignored. She openly mocked Grygum's tactical suggestion.
- **Thorin:** Warned him specifically about the Whorlstone marker. Seemed mollified by his introduction of Glabbagool.
- **Glabbagool:** Initially alarmed, then impressed — accepted the ooze as Daz's familiar.
- **Lolth:** Genuine, zealous devotion. Her faith is the foundation of her identity and her resistance to fungal infection.

## Arc Score Events
- No explicit arc score changes noted. The tentative alliance represents a positive shift in disposition toward the party, contingent on them fulfilling the bargain. Daz's failed deception could have soured relations but was neutralized by Asha's self-serving reinterpretation.
