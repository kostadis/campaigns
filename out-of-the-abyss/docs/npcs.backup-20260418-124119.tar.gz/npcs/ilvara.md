---
name: Ilvara
aliases: []
---

# Ilvara

## Identity
- High Priestess of Lolth; commander of the Velkynvelve Drow outpost
- Faction: House Mizzrym (referred to as Welnaste Mizzrym's "house sister")
- First encountered when the party arrived as prisoners at Velkynvelve, where she received them from Welnaste and ordered Jorlan to take them to the cell

## Personality & Motivations
- Haughty, arrogant, well-dressed, and coiffed — she "fits the type" of a Drow priestess, though Thorin observed something manic about her, noting she appears "a bit crazy" compared to the typically calculating Drow. She threatens prisoners with excruciating, graphic detail and rules through fear. Her core drive shifted over time: initially she needed to recapture the party to fulfill a promise that they would arrive in Menzoberranzan (likely involving money), with the destruction of Velkynvelve compounding her desperation — failure risked her becoming a Drider. Ultimately she was corrupted by Zuggtmoy's influence, seduced by the "bride heresy" that Lolth wishes to be married.

## History with the Party
1. **Velkynvelve (arrival):** Received the party as prisoners, ordered them celled, stating "We will use them until the caravan arrives."
2. **Priestess's Tower:** Forced prisoners to carry water and fill her bath. Threatened Prince Derendil with a knife when he objected. Her quarters contained the party's confiscated equipment in a zurkhwood chest.
3. **Prisoner Revolt:** Did not appear directly but her authority drove Imbros to fight desperately, fearing punishment like Serith's.
4. **Escape:** The party chose to abandon their gear in her quarters rather than risk recapture. Sarith warned she would be "honor bound to pursue" them.
5. **Underdark Pursuit:** Commanded the Drow pursuit from Velkynvelve. Sent Xinaya's squad to capture the party alive so she could kill them herself; believed the party would seek refuge at Neverlight Grove.
6. **Ongoing Threat:** Daz explained to companions that she would never stop — she needs the party found or she risks becoming a Drider. "She won't rest until the party is found or she is dead."
7. **Final Confrontation (corrupted):** Found on an elevated platform, visibly altered by fungal growth, preoccupied with a mushroom artifact from Neverlight Grove. Still carried her scourge. Controlled spore servants (former Velkynvelve guards) and the cavern's Heart Fungus. Zalthir teleported to her and dealt 31 damage while grappling; she screamed in fury and dissolved into the fungal floor, reforming elsewhere. Daz hit her with a shaped Fireball for 24 damage (half-saved), which also set her mushroom icon smoldering. She summoned four spore servants during the fight.

## Current Status
- **Last known:** Wounded and bleeding in the fungal cavern, still fighting
- **Heart Fungus** being ground down by the Dust of Suleiman; her mushroom icon is burning
- She retains the ability to merge with and travel through the fungal environment
- Still controls spore servants and personal spores (the vector for the spore illness that enslaves others)
- **Party knows:** Her corruption by Zuggtmoy, the bride heresy, her ability to dissolve into fungus, her control over spore servants, and that her mushroom artifact is a key mechanism of corruption
- **Potentially hidden:** The full extent of her fungal powers; whether any part of the original Ilvara remains

## Relationships
- **Jorlan:** Former consort, dropped after his disfigurement (acid scarring, lost finger). His resentment drove him to help the prisoners escape — a direct betrayal.
- **Shoor:** Current consort who replaced Jorlan.
- **Welnaste Mizzrym:** House sister who delivered the prisoners to her.
- **Imbros:** Subordinate at Velkynvelve, terrified of her punishments.
- **Sarith:** Former prisoner/guard who understands her psychology and warned the party about her pursuit.
- **Xinaya:** Subordinate sent to capture the party on her orders.
- **Asha Vandry:** Described Ilvara's corruption; called her "seduced by this abomination."
- **Zuggtmoy:** Source of her fungal corruption; Ilvara brought the mushroom artifact from Neverlight Grove.
- **Zalthir:** Engaged her directly in melee combat; she views him as a genuine threat (screamed in fury when wounded).
- **Daz:** Understands her motivations deeply; dealt significant damage to her and her icon with Fireball.

## Arc Score Events
- No explicit arc score mechanics noted in the source material.
