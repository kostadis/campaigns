---
name: Starlace
aliases: []
---

# Starlace

## Identity
- Traveling merchant specializing in magical wares
- First appeared in Blingdenstone during the city's preparations for battle against the Pudding King and his oozes

## Personality & Motivations
- A pragmatic businessperson willing to trade in conflict zones, suggesting either bravery or a keen eye for profit during wartime demand. Negotiations with the party were mutually satisfactory, indicating fair dealing.

## History with the Party
- **Blingdenstone (pre-battle):** Arrived while the city prepared for the assault on the Pudding King. Sold the party **Zalthir spectacles** (glowing crystal lenses granting sight of invisible creatures and the ability to see through magical darkness). Enchanted **Grygum's mace and shield** with protective magic. Purchased excess armor from the party at a price both sides found fair.

## Current Status
- **Last known location:** Blingdenstone
- Presumably still traveling and trading; no further appearances noted
- No hidden information indicated in the notes

## Relationships
- **Grygum:** Direct customer — enchanted his mace and shield
- **The Party:** Positive commercial relationship; fair trades on both sides
