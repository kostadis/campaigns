---
name: Jadger
aliases: []
---

# Jadger

## Identity
- **Role / Title:** Burrow Warden of Blingdenstone
- **Faction:** Blingdenstone deep gnome community
- **First Appearance:** Assigned the party a mission to deal with the ghost problem in the catacombs

## Personality & Motivations
- Dedicated to the defense and restoration of Blingdenstone, serving as a leader among the Burrow Wardens even beyond death. Cheerful and pragmatic to the point of dark humor—he casually noted that if the party died on their mission, they could still fight as ghosts via resurrection magic. He is grateful and fair, rewarding service with meaningful boons.

## History with the Party
1. **Ghost Mission Assignment:** Jadger tasked a group including Glabbagool, Eldeth, Jimjar, and Spiderbait with handling the ghost problem in Blingdenstone's catacombs. He specifically requested the rescue of certain ghosts, including Udhask.
2. **Post-Mission Thanks:** After the party put two tormented spirits to rest, Jadger materialized as a friendly ghost to personally thank them. He offered two boons—any two questions he would answer truthfully—as a reward for their service.

## Current Status
- **Last Known Location:** The Ruby and the Rough temple in Blingdenstone
- **Current Activity:** Training the next generation of Burrow Wardens (as a ghost)
- **Outstanding Reward:** The party has **two truthful questions** they can claim from Jadger at the temple whenever they are ready
- **Hidden Information:** None indicated; Jadger appears straightforward and allied with the party

## Relationships
- **The Party:** Grateful ally; considers them worthy of reward for their service to Blingdenstone
- **Udhask:** A ghost Jadger specifically wanted rescued from the catacombs
- **Blingdenstone:** Loyal servant of the deep gnome community, continuing his duty as Burrow Warden even in death
