---
name: Serith
aliases: []
---

# Serith

## Identity
- Drow defector; former member of the Drow society who suffered a fall from grace / punishment prior to imprisonment
- First appeared as a fellow prisoner in the Drow outpost, where he sided with the party against his former comrades during the escape

## Personality & Motivations
- Driven by a mysterious compulsion toward the Neverlight Grove — the same force that drew him to the dancing Myconids in the Whorlestone Caverns. Emotionally volatile; the death of Prince Derendil nearly caused him to break down screaming in the middle of combat. He channels his pain into action when given direction, as shown when Grygum's telepathic intervention redirected his grief into a killing blow against Imbros. Knowledgeable about Drow society and the Underdark, and willing to use that knowledge for the group's benefit.

## History with the Party
1. **Drow Outpost Escape:** Identified Imbros as an elite Drow fighter before the breakout. During the battle, descended from the armory armed and attacked a Drow guard, cursing him in Drow fashion. After Prince Derendil was killed by Imbros, Serith nearly lost control — Grygum telepathically calmed him by redirecting his rage toward spirituality. Serith then delivered the killing blow to Imbros.
2. **Kuo-toa Civil War:** Fled with the rest of the escapees during the chaos, running toward Grygum.
3. **Travel to Neverlight Grove:** Insisted the party must go to the Neverlight Grove, claiming a compulsion he connected to the dancing Myconids. On the fourth day of travel, announced they must disembark and proceed on foot, noting the path passes the Lost Tomb of Khaem.
4. **Lost Tomb Approach:** Confirmed the mysterious feminine voice was leading them in the direction they were already heading toward the tomb.

## Current Status
- **Last known:** Traveling on foot with the party through the Underdark, heading toward the Neverlight Grove via the Lost Tomb of Khaem
- **Active:** Following a strange compulsion toward the Neverlight Grove; serving as the group's navigator for this route
- **Hidden:** The true nature of his compulsion toward the Myconids and Neverlight Grove remains unexplained; his full backstory regarding his punishment/fall from grace among the Drow is unknown to the party

## Relationships
- **Grygum:** Trusts him — Grygum's telepathic intervention during the escape was a pivotal stabilizing moment; Serith ran toward Grygum during the kuo-toa escape
- **Prince Derendil (deceased):** Deeply affected by Derendil's death, suggesting a meaningful bond
- **Imbros (deceased):** Former Drow comrade turned enemy; Imbros feared suffering Serith's fate at Ilvara's hands, implying Serith's punishment was severe and well-known; Serith killed him
- **Ilvara:** Serith's fall from grace is tied to her — she apparently administered or ordered his punishment
- **Zalthir:** Cooperated during the escape (attacked the same guard Zalthir had engaged); Zalthir defers to Serith's navigation knowledge

## Arc Score Events
- **Increase:** Grygum's telepathic calming during the escape deepened Serith's trust/connection to the party
- **Decrease (potential):** Prince Derendil's death was a major emotional blow — Serith's stability may be fragile
