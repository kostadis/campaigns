---
name: Hemeth
aliases: []
---

# Hemeth

## Identity
- Duergar weapons trader, originally from Gracklstugh
- One of the castaways collected by the party during Underdark travel

## Personality & Motivations
- Core goal: Return home to Gracklstugh; resume his weapons trade
- Pragmatic and self-preserving — turns invisible and hides at the first sign of danger. Competitive about his trade, visibly irritated when the party seeks goods from rival merchants. Has a dry, grumbling humor, especially when recounting near-death experiences ("I didn't think they would think sacrificing me was a weapon. Crazy fish people.").

## History with the Party
- **Joined as castaway:** Picked up by the party during their Underdark journey.
- **Kuo-Toan boat:** Suggested the party take a Kuo-Toan boat they spotted, sharing a story about nearly being sacrificed by Kuo-Toans during a past weapons deal.
- **Duergar Keelboat discovery:** Identified an abandoned boat as a Duergar Keelboat by recognizing the crates.
- **Ambush situation:** Demonstrated duergar invisibility (lasting a full hour) to hide during a potential ambush.
- **Gracklstugh briefing:** Over several days of travel, shared extensive intel about Gracklstugh — its strict regimentation, xenophobia, the restriction of non-duergar to the Darklake district, the pervasive use of invisibility for surveillance, its slaver culture, and the Blade Bazaar marketplace.
- **Eldritch Claw Tattoo incident:** When Zalthir asked him about procuring an Eldritch Claw Tattoo, Hemeth couldn't provide it. Grumbled jealously when the party turned to Brannum Redmarch instead.

## Current Status
- Last known: Traveling with the party, arriving at or near Gracklstugh
- Serves as the party's primary source of local knowledge about the city
- **Party knows:** Gracklstugh's social rules, the Blade Bazaar, duergar invisibility, slaver culture
- **Potentially hidden:** Hemeth's personal standing in Gracklstugh, any debts or enemies he may have there

## Relationships
- **Party (general):** Cooperative but self-interested; useful as a guide and informant
- **Zalthir:** Direct interaction over the tattoo request; mild friction when bypassed as a merchant
- **Brannum Redmarch:** Rival/competitor in the party's eyes; Hemeth resents being passed over for him
- **Kuo-Toans:** Hostile history — nearly sacrificed during a past trade deal
- **Gracklstugh / Duergar society:** Native; weapons trader by profession; familiar with the city's power structures

## Arc Score Events
- No explicit arc score changes noted in source material.
