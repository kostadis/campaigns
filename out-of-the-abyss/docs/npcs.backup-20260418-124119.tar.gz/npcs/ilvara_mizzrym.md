---
name: Ilvara Mizzrym
aliases: []
---

# Ilvara Mizzrym

## Identity
- High Priestess of House Mizzrym, corrupted vessel of the demon lord Zuggtmoy
- Primary antagonist of the battle in the fungal cavern at the center of Velkynvelve's fungal infestation
- By the time the party fought her, she was no longer a person aided by a demon lord — she was described as Zuggtmoy's work "walking around in a drow priestess's bones"

## Personality & Motivations
Ilvara was wholly devoted to Zuggtmoy's vision. She muttered prophecy about "the bride" and "the chaos and mayhem to come" throughout the fight — delivered not as threats but as sincere belief in a future she had already accepted. She was tactically sharp even while wounded, reshaping the battlefield and countering threats with precision. She never begged or offered surrender.

## History with the Party
**The Fungal Cavern Battle (Final Encounter):**
- Stationed in the cavern above the heart fungus at the center of Velkynvelve's infestation.
- **Zalthir** opened the fight aggressively — grappled her with his Eldritch Claw Tattoo, dragged her forty feet into the air, landed two critical hits (sixteen-plus damage), and dropped her to the stone floor. She responded with a legendary reaction fear effect (DC-14 Wisdom save), frightening Zalthir and neutralizing his close-range combat kit for a full round.
- Cast **Insect Plague** at the cavern entrance, instantly killing her own fungal minions (thirteen HP each) and dealing twenty-six damage to **Glabbagool**.
- Called down divine fire on **Daz** and **Nym Duskryn**; conjured fungal growth to reshape the battlefield.
- When **Thorin** destroyed the bridge beneath her, she leapt clear and survived the fall.
- **Jorlan Duskryn** charged her through the insect swarm, screaming her name — their broken romantic history driving his fury. They traded blows on the cavern floor.
- **Grygum's Guiding Bolt** killed her. Upon death, her body erupted in a massive cloud of poisonous spores, catching Zalthir and Thorin in the blast. She was still muttering prophecy when she died.

## Current Status
- **Dead.** Her body erupted into poisonous spores upon death — nothing of her remained. Her death confirmed the totality of Zuggtmoy's corruption; she had ceased to be a person long before the fight.
- Her prophecies about Zuggtmoy, "the bride," and coming chaos remain unresolved — the party has heard these warnings but their meaning is not yet clear.

## Relationships
- **Zuggtmoy:** Ilvara was fully consumed by the demon lord's influence, serving as a vessel rather than an ally. Her death released demonic corruption as biology (spores), not identity.
- **Jorlan Duskryn:** Former romantic partner. She discarded him after his scarring, per drow society's values. He charged her in a rage during the final fight — their history was deeply personal and violent.
- **Nym Duskryn:** Targeted by Ilvara's divine fire during the battle; relationship unclear beyond combat hostility.
- **Zalthir:** Their exchange was the mechanical centerpiece of the fight — his devastating opening assault met by her devastating counter (Frightened condition neutralizing a melee monk).
- **Grygum:** Landed the killing blow from range; noted he was glad to have been standing back when the spore cloud erupted.
- **Thorin:** Destroyed the bridge beneath her; caught in her death spores.
- **Glabbagool:** Took heavy damage from her Insect Plague.

## Arc Score Events
No explicit arc score changes noted in the source material.
