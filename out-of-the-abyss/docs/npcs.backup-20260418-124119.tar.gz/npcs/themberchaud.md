---
name: Themberchaud
aliases: []
---

# Themberchaud

## Identity
- **Title:** Wyrmsmith of Gracklstugh; also called "Father of Flame," "the Everburning," and "the Foundry's Heart"
- **Race/Type:** Young red dragon
- **Faction:** Nominally serves the Keepers of the Flame, though he believes the Keepers serve *him*
- **First Appearance:** Discussed by Gartokkar Xundorn and a halfling outside the Darklake Brewery before the party met him in person in his gem-filled cavern

## Personality & Motivations
Themberchaud possesses a fragile, oversized ego — he cannot even wait for someone to agree before declaring them his agents. He genuinely believes he rules Gracklstugh, proclaiming it "my town," despite functioning as a glorified lighter for the Duergar forges. He is pampered, vain (scales polished, claws painted), and visibly overweight — described as landing like "a bag of potatoes" with a second chin and a belly that rolls on sharp turns. Zalthir doubts he could survive in the wild, having likely forgotten how to hunt. His maturity has been stunted by his captive, coddled existence.

## History with the Party
1. **Initial discussion:** The party learned about Themberchaud from Gartokkar and a halfling, who explained the Keepers' cycle of pampering, controlling, and eventually replacing the dragon. Daz questioned why a red dragon would accept the role.
2. **Cavern audience:** Themberchaud met the party in his hoard cavern. He dismissed Gartokkar, breathed fire in a circle to check for spies, questioned each party member individually (asking Zalthir about gold dragonborn heritage, Daz about Menzoberranzan ties), and unilaterally declared them his agents. He ordered them to do what Gartokkar says but report to him first.
3. **Party schemes:** Grygum (cleric of Bahamut) expressed outrage at how the dragon is treated. The party hatched a plan to free Themberchaud and ride him out of Gracklstugh, but ultimately abandoned it.
4. **Egg subplot:** The party learned the Keepers' red dragon egg — intended as Themberchaud's replacement — was stolen and repurposed by a cult for Demogorgon. Grygum advocated returning the egg to Gartokkar, reasoning the hatched abomination would let Themberchaud take revenge on his controllers.
5. **Dive-bomb encounter:** After the party dealt with the grey ghosts, Themberchaud dive-bombed them in the streets, declared them his agents under his protection, and flew them through the cavern. He detoured to a forge to breathe fire (the Duergar rolled their eyes). During a sharp turn, Grygum, Thorin, and Daz fell off and had to be rescued. He deposited them at the docks.
6. **Departure from Gracklstugh:** As the party left, Thorin noted that Themberchaud believed he had an agreement with them — but the party never actually made a deal with the dragon.

## Current Status
- **Last known location:** Gracklstugh, presumably in his cavern or roaming the city
- **Active concerns:** Themberchaud is unaware that (1) the Keepers view him as their tool, not their master; (2) the red dragon egg meant to replace him was stolen; (3) the party left Gracklstugh without fulfilling any obligation to him
- **Unresolved:** His reaction to the party's departure and broken implicit "agreement" remains unknown
- **Hidden from him:** The entire replacement cycle — the Keepers' plan to eventually kill him and hatch a successor

## Relationships
- **Keepers of the Flame / Gartokkar Xundorn:** Themberchaud believes they serve him; they believe he serves them. Gartokkar was visibly displeased when dismissed from the cavern audience.
- **The Party:** Declared them his agents without consent. The party never formally agreed. Grygum sympathizes with his captivity on principle (as a cleric of Bahamut). Zalthir views him as an embarrassment to dragonkind. Thorin was interested in riding him out of the city.
- **Duergar of Gracklstugh:** They do not take him seriously — forge workers roll their eyes at his dramatic fire-breathing. The party's association with him made locals fear they were the Ember Vanguard.
- **The Cult / Demogorgon plot:** Unknowingly connected — the stolen egg was his replacement, now repurposed for darker ends.

## Arc Score Events
- No explicit arc score changes noted in the source material.
