---
name: Sennai
aliases: []
---

# Quartermaster Sennai

## Identity
- Quartermaster of Blingdenstone; a civic leader
- Has not yet been met directly by the party
- The party was told they need to consult both Sennai and Chief Dorbo Diggermattock to receive full authorization to enter the city

## Personality & Motivations
- Unknown — no direct interaction has occurred yet.

## History with the Party
- The party was directed to seek out Sennai (alongside Chief Dorbo Diggermattock) as a requirement for gaining full entry into Blingdenstone. No meeting has taken place.

## Current Status
- **Last known location:** Blingdenstone
- **Active plans:** Unknown
- **Party knowledge:** They know her title (Quartermaster), her name, and that her approval is needed for city access. Nothing else is known.

## Relationships
- **Chief Dorbo Diggermattock:** Fellow leader in Blingdenstone; jointly responsible for authorizing entry to the city.
- **The Party:** No direct relationship yet established.

## Arc Score Events
None recorded.
