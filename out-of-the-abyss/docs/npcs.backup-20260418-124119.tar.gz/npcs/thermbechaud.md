---
name: Thermbechaud
aliases: []
---

# Thermbechaud

## Identity
- Referenced as a geographic landmark; associated with a cave
- Not encountered directly by the party; mentioned only as a point of origin for travel to the Cairngorm Cavern

## Personality & Motivations
- No personality or motivations observed — Thermbechaud has not appeared in play.

## History with the Party
- The party used Thermbechaud's cave as a departure point for their journey to the Cairngorm Cavern. No direct interaction occurred.

## Current Status
- Last known location: Thermbechaud's cave
- No active plans or operations noted
- The party knows the cave exists and used it as a waypoint; nothing further is established

## Relationships
- No known relationships documented in session notes.

## Arc Score Events
- None.
