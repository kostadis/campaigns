---
name: Asha Vandree
aliases: []
---

# Asha Vandree

## Identity
- Drow priestess, devout follower of Lolth
- Former subordinate of Ilvara at the drow outpost
- First encountered when Daz attempted to deceive her by posing as divinely touched by Lolth

## Personality & Motivations
Asha is a true believer — sharp, doctrinally rigid, and deeply committed to Lolth. She saw through Daz's charlatan performance instantly but chose to keep him, rationalizing his usefulness through her own theological framework ("Perhaps my prayers have been answered through this… confused vessel"). She carries a visceral, personal hatred for Ilvara rooted in long proximity to a corrupted superior. She is pragmatic enough to use others for the violence she cannot do herself, but everything filters through her faith.

## History with the Party
1. **Daz's Deception Attempt:** Daz tried to pass himself off as Lolth-touched using Dancing Lights absorbed into his spider familiar. Asha recognized the con immediately, having seen such performances in drow society. Rather than rejecting Daz, she constructed her own explanation — that he and his companions were infected by Zuggtmoy's spores and deluded, possibly a trick of Ilvara's. She accepted Glabbagool as a bound familiar, fitting her framework of Daz as a deluded but genuinely powerful mage.
2. **Intelligence Briefing:** Asha provided critical tactical intelligence before the fight against Ilvara. She revealed that Ilvara had been seduced by Zuggtmoy's influence, that Ilvara's allies had turned into mindless fungal creatures, and that only she and Jorlan remained uninfected — she through devotion, Jorlan through hatred. She identified the mushroom artifact from Neverlight Grove and the Big Heart Fungus as key threats. She offered Ilvara's (possibly contaminated) magical items and "the gratitude of Lolth" as payment.
3. **Tactical Role:** Asha held the perimeter during the battle rather than engaging directly, handling external threats while the party did the close-range killing. She was explicit that this arrangement suited her — she had always needed someone else to do the lethal work.
4. **Confrontation with the Duskryn Sisters:** When Kaelira and Nym Duskryn appeared, Asha immediately moved for her weapon, denouncing them as traitors to Lolth. Daz defused this by introducing them as Lolth-aligned allies — a lie that worked because of his long-running cover identity as a Lolth follower in Asha's eyes.
5. **Post-Battle Prayer:** After Ilvara's death, Asha dropped to her knees and began murmuring prayers to Lolth, already reshaping events into a narrative her goddess could use. Multiple party members noted this with wariness.

## Current Status
- **Last known location:** The cavern where Ilvara was killed, praying to Lolth over the aftermath.
- **Active plans:** Building a theological narrative around the events she witnessed — the destruction of a Zuggtmoy-corrupted priestess, the role of the party, and her own survival through faith.
- **Known vs. hidden:** The party knows she is a genuine Lolth zealot and that she manipulated them into serving her ends. What remains hidden is what theology she is constructing from this moment and whether Lolth will actually answer her prayers (Thorin acknowledged this possibility).

## Relationships
- **Daz:** Views him as "an insane mage who had converted to Lolthism" — a characterization noted as accurate. She sees through his deceptions but keeps him as a useful vessel she can frame within her worldview. Daz maintains a Lolth-follower cover identity with her.
- **Ilvara:** Deep personal hatred, not merely political. Described Ilvara as a former high priestess corrupted by Zuggtmoy. Wanted her butchered and sent to "an unearthly grave."
- **Jorlan:** Fellow uninfected drow at the outpost. He survived through hatred rather than faith. Asha and Jorlan maintained twenty feet of distance from the infected and kept separate food.
- **Kaelira & Nym Duskryn:** Initially hostile — suspected them as traitors to Lolth. Accepted Daz's lie that they were Lolth-aligned allies.
- **Glabbagool:** Accepted as Daz's bound familiar within her framework.
- **Grygum:** Watches Asha warily; filed her post-battle prayer under "watch this space."
- **Thorin:** Acknowledged with concern that Asha's prayers to Lolth might actually be answered.

## Arc Score Events
No explicit arc score changes noted in the source material.
