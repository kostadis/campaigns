---
name: Flumph
aliases: []
---

# Flumph

## Identity
- A flumph encountered by the party during their Underdark travels
- No faction affiliation noted

## Personality & Motivations
- Cautious and self-preserving; explicitly declined to enter the assassin's redoubt, preferring to observe danger rather than participate in it. Possesses a dry, sardonic wit — "I want to observe a tragedy, not be in one." Willing to travel with the group when the risk is managed (e.g., sneaking under cover of a Darkness spell).

## History with the Party
- Shared an image of an egg with the party (context/significance of the egg not elaborated in notes).
- Was invited to join the group entering the assassin's redoubt but refused, choosing to stay behind.
- Later accompanied the party (alongside Jimjar, Sarith, Stool, Elbeth, and Spiderbait) as they sneaked past the Derro caves, concealed by Zalthir's Darkness spell.

## Current Status
- Last known: traveling with the party, having just passed the Derro caves.
- No active plans or operations noted.
- The party knows Flumph possesses knowledge of (or connection to) a mysterious egg but details remain unclear.

## Relationships
- **The Party:** A companion of convenience; willing to travel with them but sets firm boundaries on personal risk.
- **Jimjar, Sarith, Stool, Elbeth, Spiderbait:** Fellow travelers in the group that sneaked past the Derro caves.
- **Zalthir:** Benefited from Zalthir's Darkness spell during the Derro cave passage.
