---
name: The Garden Shadow
aliases: []
---

# The Garden Shadow

## Identity
- Ancient monk; martial and spiritual mentor to Zalthir
- Has not appeared directly in play; referenced through Zalthir's memories during the lichen harvest attempt

## Personality & Motivations
- Patient teacher with deep knowledge of nature, herbalism, and practical wilderness skills. Emphasized the value of contemplative training even to a reluctant student, suggesting a long-view philosophy about preparedness and wisdom.

## History with the Party
- **Lichen Harvest Attempt:** When Zalthir was poisoned during a lichen harvest, he recalled The Garden Shadow's specific teachings on how to cut lichen and tend trees. Zalthir had originally dismissed this training, preferring a life of action over contemplation, but recognized its value in the moment of crisis.

## Current Status
- Last known status: unknown; referenced only in past tense as part of Zalthir's backstory
- No indication of whether The Garden Shadow is alive, dead, or otherwise
- The party has no direct knowledge of this figure beyond whatever Zalthir has shared

## Relationships
- **Zalthir:** Former student. The Garden Shadow trained Zalthir as a monk, imparting wilderness and herbalism knowledge. Zalthir was a somewhat reluctant pupil who preferred action over contemplation, though he has come to appreciate the training.

## Arc Score Events
None recorded.
