---
name: Jaezred
aliases: []
---

# Jaezred

## Identity
- Drow soldier
- First encountered in the mess hall, seated at a table when Gyrgum arrived for cooking duty

## Personality & Motivations
- No personality traits or motivations observed beyond appearing hungry in the mess hall.

## History with the Party
- Identified by Suushar as one of two Drow sitting at a table in the mess hall. No direct interaction with the party has occurred.

## Current Status
- Last seen in the mess hall
- No known plans or operations
- The party knows only that he is a Drow soldier present in the mess hall

## Relationships
- **Suushar:** Identified Jaezred by name to the party
- **Unnamed Drow:** Was seated with a second, unidentified Drow at the same table

## Arc Score Events
None.
