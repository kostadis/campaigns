---
name: Perigrog Scrapedust
aliases: []
---

# Perigrog Scrapedust

## Identity
- Gnome worker/demolitions specialist at the White Shell Mine, the largest salt mine in the Underdark
- First encountered by the party at the White Shell Mine when they investigated an impassable tunnel

## Personality & Motivations
- Practically minded and knowledgeable about the mine's conditions. Eager to solve problems using gnomish expertise, particularly specialized explosives. Celebrated enthusiastically when the tunnel was successfully breached, suggesting a collaborative and spirited disposition.

## History with the Party
- **White Shell Mine encounter:** Perigrog informed the party about a tunnel that had become impassable—impossibly dry, with blinding crystallite walls, absolute suffocating silence, and shadows that appeared painted on the walls as if time itself had stopped. He and the other gnomes presented their specialized explosives to help breach the obstruction. After Zalthir identified a solution and successfully redirected the magical blast through shadow space to shatter the wall without collapsing the surrounding tunnels, Perigrog and the gnomes celebrated the success.

## Current Status
- **Last known location:** White Shell Mine in the Underdark
- **Activity:** Presumably resumed mining operations after the tunnel was cleared
- **Party knowledge:** The party knows him as a helpful gnome demolitions expert at the mine; no hidden information indicated in available notes

## Relationships
- **Zalthir:** Worked directly with Zalthir to solve the tunnel obstruction; deferred to Zalthir's magical expertise for the final solution while contributing gnomish explosives knowledge
- **Fellow gnome miners:** Part of a group of gnomes at the White Shell Mine who collectively assisted with the breach

## Arc Score Events
None indicated in available notes.
