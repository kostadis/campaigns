---
name: Stonespeaker Hgraam
aliases: []
---

# Stonespeaker Hgraam

## Identity
- Master stonespeaker of the stone giants; mentor to both Dorhun and Rihaud
- Has not appeared in person; mentioned by name only during the party's encounter with Dorhun and Rihaud near the Blade Bazaar

## Personality & Motivations
- No direct personality details observed. Known only as a figure of authority and teaching among the stone giants, with at least two apprentices operating under his guidance.

## History with the Party
- **Blade Bazaar encounter:** When the stone giants Dorhun and Rihaud introduced themselves to Thorin, Dorhun identified Stonespeaker Hgraam as the master to whom both he and Rihaud are apprenticed. No further details were shared.

## Current Status
- **Last known location:** Unknown; not encountered in person.
- **Active plans:** Unknown.
- **Party knowledge:** The party knows only his name, his title ("Stonespeaker"), and that he is the master of Dorhun and Rihaud. Everything else remains hidden.

## Relationships
- **Dorhun** — Apprentice to Hgraam
- **Rihaud** — Apprentice to Hgraam
- **Thorin** — No direct relationship; Thorin learned of Hgraam through Dorhun's introduction
