---
name: Tarngardt
aliases: []
---

# Tarngardt

## Identity
- Former Deep King of Gracklstugh (grandfather of the current Deep King)
- Historical political figure; not encountered directly by the party

## Personality & Motivations
- Enacted a major reform by liberating the derro population of Gracklstugh, suggesting a progressive or pragmatic political stance relative to traditional duergar norms. No further personality details available from session notes.

## History with the Party
- No direct interactions. Tarngardt is a historical figure referenced in the context of Gracklstugh's political and social landscape.

## Current Status
- Presumably deceased (grandfather of the current Deep King)
- His legacy is visible in the city's layout: the derro now occupy both the West Cleft District and East Cleft District, and former duergar guardhouses built to watch derro slaves stand abandoned following his decree

## Relationships
- **Current Deep King of Gracklstugh**: Grandson
- **The Derro**: Liberated them from slavery, enabling their expansion across the Cleft Districts
- **Duergar establishment**: His decree ended the slave-watch infrastructure, likely a politically significant and potentially controversial act

## Arc Score Events
None recorded.
