---
name: Daz
aliases: []
---

# Daz

## Identity
- Drow (implied by Chipgrin's remark about negotiating with drow)
- Magic user (employs magic missiles)
- No stated faction affiliation
- First appearance context not explicitly noted; encountered with the party during Underdark travel through the Silken Paths and combat with spiders and a Spectator

## Personality & Motivations
- Core goal: escape the Underdark; willing to solve others' problems only insofar as it clears a path out
- Pragmatic, blunt, and impatient with inefficiency — he seized control of Blingdenstone's political debates out of sheer exasperation, not ambition
- Possesses a ruthless streak: privately dismissed goblin guides as potential "battle fodder," and willingly stakes his own life as collateral for plans he commands
- Earns respect through competence and directness, though his manner can unsettle allies and adversaries alike

## History with the Party
1. **Silken Paths & Spider Retreat** — Used magic missiles to cover the party's retreat from spiders. Muttered that the goblin guides "might prove useful as fodder in a battle"; Buppido overheard this remark.
2. **Spectator Fight** — Killed the Spectator with magic missiles described as "glowing teardrops of blue-white force."
3. **Blingdenstone Political Crisis** — Took decisive control of the svirfneblin leadership debates, cutting through bureaucratic stalling. Proposed a direct plan to deal with the Pudding King. Secured support from Chief Dorbo and Senni, including recruiting the Gold Whisker clan as a diversionary force.
4. **Negotiation with Chief Chipgrin** — Clarified the party's true purpose (clearing a route out), refused to facilitate political maneuvering, and personally guaranteed accountability for any casualties — offering himself as a target for vengeance if the plan failed. Chipgrin noted Daz exceeded even drow stereotypes for difficult negotiation.
5. **Grand Moot** — Led the meeting at Senni's request. Presented the battle plan: a gnome army distraction at the ooze amphitheater while the party covertly snatched the Pudding King using magic. Exposed gnome leaders' attempts to exploit the party for side quests, though the party later chose some voluntarily.

## Current Status
- **Last known location:** Blingdenstone, following the grand moot
- **Active plans:** Leading the assault plan against the Pudding King — gnome army diversionary attack while the party conducts a covert extraction
- **Known vs. hidden:** The gnome leaders and Chipgrin know Daz as the plan's architect and sole accountable party. Buppido overheard Daz's "fodder" comment about the goblin guides — the party may not be aware of this.

## Relationships
- **Chief Dorbo & Senni** — Earned their trust and cooperation through assertiveness; Senni deferred meeting leadership to him
- **Chief Chipgrin (Gold Whisker clan)** — Tense but functional negotiating relationship; Chipgrin respects Daz's directness but finds him extreme; Daz refused to be leveraged for Chipgrin's political ambitions
- **Buppido** — Potential tension; Buppido overheard Daz's callous remark about using goblin guides as fodder
- **Goblin guides** — Daz views them instrumentally, not as allies
- **The Party** — Functions as de facto strategist and spokesman in high-stakes situations

## Arc Score Events
- **Buppido overhearing the "fodder" remark** — potential trust decrease / future conflict trigger with Buppido
- **Taking personal accountability at Chipgrin negotiation** — trust increase with Chipgrin and Gold Whisker clan
- **Leading the grand moot and exposing gnome leaders' exploitation** — trust/respect increase with Blingdenstone leadership
