---
name: Thorin
aliases: []
---

# Thorin

## Identity
- Orc cleric of Bahamut
- Party member (PC)
- Notable for his unusual faith — an orc devoted to Bahamut, which surprises NPCs they encounter

## Personality & Motivations
- Holds strong opinions about how combat "should" be conducted; was annoyed at Giant Spiders for not "playing the game as it was meant to be played" during a retreat. Suggests a code of honor or expectation of fair engagement.
- Direct and aggressive in combat — charged a Spectator even while hit by a confusion ray.
- Observant and practical; noted inaccuracies in Sethir's map regarding relative distances.

## History with the Party
- **Giant Spider Encounter:** Participated in a web-cutting retreat; vocally frustrated with the spiders' tactics.
- **Sethir's Map:** Pointed out that the map didn't accurately reflect relative distances.
- **Spectator Fight:** Hit by a confusion ray from the Spectator but charged and attacked regardless. Struck by a second (blue) ray from another eyestalk but was unaffected. Attempted a "hill strike" — a technique learned from a hill giant battle master — to knock the Spectator prone, but the creature proved too strong.
- **Blingdenstone Gates:** Vouched for the party's truthfulness to the gnome guards. His identity as an orc cleric of Bahamut surprised the guards but apparently helped the party gain entry.

## Current Status
- Last known location: Blingdenstone (or its vicinity)
- No specific active plans noted beyond the party's ongoing journey

## Relationships
- **Sethir:** Fellow party member; willing to critique Sethir's mapmaking openly.
- **Blingdenstone Gnomes:** Made an impression at the gates by vouching for the party; his unusual faith was a point of curiosity.
- **Bahamut:** Devout follower — his faith defines his identity and surprises those who encounter him.

## Arc Score Events
None noted.
