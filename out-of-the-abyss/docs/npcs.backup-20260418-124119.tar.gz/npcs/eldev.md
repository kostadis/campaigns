---
name: Eldev
aliases: []
---

# Eldev

## Identity
- NPC companion/ally assigned to a side quest
- Specific role, title, and faction affiliation not detailed in available notes

## Personality & Motivations
- No personality traits or personal motivations are described in the available notes.

## History with the Party
- Assigned alongside **Glabbagool** and **Jimjar** to assist the **Barrow Warden ghosts** with their quest, while the main party split off to handle the **Rock Blight** and **Neverlight Grove** tasks.

## Current Status
- **Last known activity:** Undertaking the Barrow Warden ghost quest with Glabbagool and Jimjar.
- **Location:** Unspecified; presumably wherever the Barrow Warden quest leads.
- No further updates on the outcome of this mission.

## Relationships
- **Glabbagool** — Co-assigned to the Barrow Warden quest.
- **Jimjar** — Co-assigned to the Barrow Warden quest.
- **Barrow Warden ghosts** — Tasked with assisting them.
- **The main party** — Split from them to handle this side objective.

## Arc Score Events
None noted.
