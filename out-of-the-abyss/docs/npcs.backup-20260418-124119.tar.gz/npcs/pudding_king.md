---
name: Pudding King
aliases: []
---

# Pudding King

## Identity
- Servant of Juiblex, the demon lord of oozes; also collaborating with Zuggtmoy
- Commander of oozes in the Underdark
- Confronted by the party in his throne room after they breached the walls using an Earth Elemental

## Personality & Motivations
- Fanatically devoted to Juiblex, willingly surrendering his humanoid form to become a sentient, telepathic ooze. Driven by a zealous desire to reduce all deep-dwelling races to ooze. Grandiose and theatrical—delivered dramatic telepathic monologues mid-combat, though the party asked him to lower his mental volume. Also served Zuggtmoy's fungal corruption plans by using oozes to "soften the shell" so her garden could "take root in the flesh beneath."

## History with the Party
1. **First Reference:** The party overheard Zuggtmoy's psychic message directed at the Pudding King, revealing his role as her collaborator—commanding oozes in service of her fungal corruption schemes.
2. **Confrontation:** The party breached his throne room walls with an Earth Elemental. When Zalthir attempted to grapple him, the Pudding King shed his humanoid form, revealing himself as a sentient telepathic ooze.
3. **Battle:** He leveraged green slime ceiling hazards and lair actions, including devastating slime wave attacks that knocked multiple party members prone and coated them in corrosive slime. Zalthir grappled him and made the crucial decision to drag him out of the throne room, stripping him of his lair actions. During this, Zalthir dragged him through Glabbagool's body, causing a body/position swap that led the party to accidentally attack Glabbagool before realizing the deception.
4. **Death:** Under a coordinated assault from the full party—Daz (Magic Missile, 20 damage), Grygum (Inflict Wounds, 23 damage), Thorin (Dawnbringer strikes, 12 radiant damage), and Zalthir (Eldritch Claw tentacle-enhanced flurry, 37 damage)—the Pudding King dissolved with a final telepathic scream: *"Behold the true feast, the soul's final blend!"* His consciousness dissipated and his form melted into inert puddles.

## Current Status
- **Dead.** Dissolved completely; consciousness dissipated, physical form reduced to inert puddles.
- His death removes a key operative from both Juiblex's and Zuggtmoy's plans in the Underdark, though Zuggtmoy's broader schemes remain active.

## Relationships
- **Juiblex:** Primary patron; the Pudding King fully embraced Juiblex's power, sacrificing his humanoid form.
- **Zuggtmoy:** Active collaborator; used his oozes to advance her fungal corruption agenda.
- **Glabbagool:** Used Glabbagool's presence in battle to create a body/position swap, causing confusion and friendly fire among the party.
- **The Party:** Viewed them as insignificant compared to his divine mission; they viewed him as a key threat to be eliminated.

## Arc Score Events
- None explicitly noted.
