---
name: Turvy
aliases: []
---

# Turvy

## Identity
- Male deep gnome (svirfneblin), twin brother of Topsy
- Lycanthrope (wererat) — known to at least some party members (Daz)
- Fellow prisoner at Velkynvelve; met by the party in the slave pen

## Personality & Motivations
- Extremely quiet; mumbles rather than speaking clearly, relying on Topsy to translate for him. Operates almost exclusively as a unit with his twin sister. Shows a pragmatic, opportunistic streak — eager to steal when the chance arises. Despite this, he is not fearless; he broke down screaming at the sight of Demogorgon and had to be physically carried to safety.

## History with the Party
1. **Velkynvelve** — Greeted Grygum (via Topsy translating) and suggested Blingdenstone as a destination. Worked kitchen duty alongside Topsy, stealing food and later knives while Grygum distracted the Drow guards.
2. **Escape from Velkynvelve** — Scrambled into the armory and fired hand crossbows from the roof during the breakout battle. Offered to retrieve gear for a price; when declined, the twins transformed into rats, then shifted back to gnome form on the cavern floor and headed toward the Darklake passage.
3. **Underdark Travel** — Participated in a crossbow volley against a giant centipede alongside Sarith, Buppido, and Topsy. Thorin called on the twins to save Eldeth and Jimjar during the fight. Sided with Jimjar in the corpse disposal debate, arguing dead bodies would slow pursuing Drow. Ironically found the name "Blingdenstone" off-putting despite having suggested it earlier. Observed by Daz speaking privately with Topsy before sleep.
4. **Kuo-toa Settlement** — Recognized the kuo-toan factional battle as a prime opportunity to steal. Fled with the group toward the docks during the chaos.
5. **Demogorgon's Appearance** — Screamed and wailed at the sight of the demon lord; Grygum carried him to the boat.

## Current Status
- **Last known location:** On the boat fleeing the kuo-toa settlement after Demogorgon's emergence.
- **Active concerns:** His lycanthropy remains a potential threat to the group.
- **Party knowledge:** Daz knows (or suspects) the twins are lycanthropes. The broader party may not be fully aware.

## Relationships
- **Topsy** — Twin sister, inseparable companion, and his voice/translator. They operate as a pair in virtually all situations and hold private conversations away from the group.
- **Grygum** — Positive relationship; Grygum physically carried Turvy to safety during the Demogorgon encounter.
- **Jimjar** — Aligned with him on the corpse disposal question.
- **Thorin** — Thorin directed the twins in combat, suggesting some degree of tactical trust.
- **The Party (general)** — A useful if somewhat self-interested ally; willing to help but always looking for an angle or a profit.
