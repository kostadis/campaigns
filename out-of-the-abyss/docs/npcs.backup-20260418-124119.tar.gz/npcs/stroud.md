---
name: Stroud
aliases: []
---

# Stroud

## Identity
- Dwarf, notable public figure following the events of the Well of the Dragons
- No faction affiliation mentioned
- No direct meeting with the party recorded

## Personality & Motivations
- Stroud appears to be an unlikely hero—someone who stumbled into greatness rather than pursuing it deliberately. His willingness to go on a speaking tour suggests he embraces (or at least doesn't shy away from) the fame his victory brought him. His explanations of the game suggest he may not fully understand the magnitude or mechanics of what he accomplished.

## History with the Party
No direct interactions with the party recorded.

## Current Status
- Last known activity: conducting a speaking tour recounting his chess victory over Protanther, walking audiences through his thought process and the board
- No active plans or operations noted
- Public figure whose story is apparently well-known enough to be common knowledge

## Relationships
- **Protanther** — The Gold Dragon he defeated in chess after the events of the Well of the Dragons
- **Bahamut** — Some believe Bahamut guided Stroud's hand during the match; no confirmation either way
- **Chess grandmasters** — Have analyzed the game and are perplexed by Stroud's explanations, as he appears to barely understand the rules of chess

## Arc Score Events
None recorded.
