---
name: Topsy and Turvy
aliases: []
---

# Topsy and Turvy

## Identity
- Deep gnome (svirfneblin) twins; fellow escapees from captivity
- Part of the group that ended up at Ghohlbrorn's Lair

## Personality & Motivations
- Little is known about their core personality or drives from observed interactions. They have kept a low profile among the escapee group.

## History with the Party
- Escaped captivity alongside the party and other NPCs.
- Arrived at Ghohlbrorn's Lair with the group of escapees.
- They are the only other escapees besides the party who have **not** gone missing from Ghohlbrorn's Lair.

## Current Status
- **Last known location:** Ghohlbrorn's Lair
- **Active concerns:** Daz suspects the reason Topsy and Turvy haven't disappeared like the other escapees is that they are **wererats**. This suspicion has not been confirmed.
- **What the party knows:** Daz has voiced the wererat theory. The twins' true nature remains unverified.

## Relationships
- **Daz:** Suspects them of being wererats.
- **Other escapees:** The rest of the escapee group has gone missing from Ghohlbrorn's Lair; Topsy and Turvy are the sole exceptions.
