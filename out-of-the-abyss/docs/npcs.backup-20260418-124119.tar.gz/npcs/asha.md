---
name: Asha
aliases: []
---

# Asha

## Identity
- Drow cleric stationed at Velkynvelve
- Subordinate to Ilvara, the outpost's commander
- First mentioned by Jimjar as part of the power dynamics at Velkynvelve

## Personality & Motivations
- Ambitious — actively positioning herself to challenge or replace Ilvara as commander of Velkynvelve. Her core drive appears to be advancement within the outpost's hierarchy.

## History with the Party
- Jimjar informed the party that Asha is "angling for the top job," providing insight into internal Drow politics at Velkynvelve.

## Current Status
- **Last known location:** Velkynvelve
- **Active plans:** Maneuvering to supplant Ilvara as outpost commander
- **Party knowledge:** The party knows (via Jimjar) that Asha is a rival to Ilvara and seeks the leadership position. No direct interactions with Asha have been noted.

## Relationships
- **Ilvara:** Political rival; Asha seeks to replace her as commander of Velkynvelve
- **Jimjar:** Aware of Asha's ambitions and willing to share that information with the party

## Arc Score Events
None recorded.
