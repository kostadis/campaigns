---
name: Nym
aliases: []
---

# Nym

## Identity
- Drow soldier from Velkynvelve; member of the drow scout force pursuing the party
- First identified during a pursuit encounter when Zalthir recognized his distinctive gait among the drow scouts

## Personality & Motivations
- Dutiful but pragmatic — he follows orders to track down escaped prisoners but is not reckless about personal safety. When faced with a potential cave collapse, he chose self-preservation over further investigation. Shows a hint of smugness or vindication ("I told you it was the other tunnel"), suggesting he questions his companions' judgment.

## History with the Party
- **Pursuit encounter:** Nym was among the drow scouts tracking the party through tunnels. Zalthir recognized him by his gait. When Zalthir accidentally fell from a hiding place and made noise, Nym drew his weapon and searched the area. Grygum used Thaumaturgy to create a tremor, which convinced Nym the cave was unstable. Believing the prisoners had gone a different direction, he turned back, unaware the tremor was magical.

## Current Status
- **Last known location:** In the tunnel system, heading away from the party's actual position after being misdirected
- **Active operations:** Still part of the drow scout force actively pursuing the escaped prisoners
- **Known vs. hidden:** The party knows Nym by name and gait (via Zalthir) and that they successfully fooled him. Nym does not know how close he came to finding them and believes the tremor was natural.

## Relationships
- **Velkynvelve drow:** Fellow soldier in the pursuit force; defers to the group's mission but disagrees with his companions on tracking decisions
- **Zalthir (party member):** Zalthir knows Nym well enough to recognize him by gait alone, suggesting prior familiarity from captivity at Velkynvelve
- **The party:** Unknowing adversary; was directly deceived by Grygum's Thaumaturgy

## Arc Score Events
- None noted.
