---
name: Gartokkar Xundorn
aliases: []
---

# Gartokkar Xundorn

## Identity
- **Role:** Custodian of the Flame; chief of the Keepers of the Flame
- **Race:** Duergar priest
- **Faction:** Keepers of the Flame — the faction responsible for tending the red dragon Themberchaud, who heats the stones powering Gracklstugh's furnaces. Described as the most prized of the Deepking's advisors.
- **First Appearance:** Materialized behind Zalthir after the party's battle with a crazed stone giant. Offered them safe passage and protection from imprisonment in exchange for a service.

## Personality & Motivations
- **Core Goal:** Recover the stolen red dragon egg — the Keepers' insurance policy for eventually replacing Themberchaud — and destroy the Gray Ghosts who stole it. Seeks to use evidence of demonic worship among the Derro to convince the Deepking to wage a genocidal war against them.
- Politically shrewd and manipulative. Presents coerced arrangements as willing partnerships ("delighted" the party accepted a role they had no real choice in). Maintains a careful public fiction that the Keepers serve Themberchaud, when in reality the dragon serves them. Capable of warmth — laughed genuinely at Grygum's joke, noting he hadn't heard a good one in a long time — but turns cold and threatening the moment he's crossed. Keeps pre-prepared dossiers on the party's legal vulnerabilities. His authority is significant enough that flashing his badge causes other Duergar to immediately scatter.

## History with the Party
1. **First Contact:** Appeared after the stone giant battle, offered safe passage and protection in exchange for service. Gave a next-day ultimatum and warned that refusing would make future encounters unfriendly. Disappeared.
2. **Dragon's Cavern & Briefing:** Attempted to lead the party to a building outside Themberchaud's cavern but was interrupted by the dragon's arrival; introduced Themberchaud with full reverence. After the dragon dismissed him (visibly displeased, but compliant), he briefed the party in his chambers. Revealed the stolen egg situation, identified Droki as a Gray Ghosts agent, and tasked the party with recovering the egg and finding proof of the Gray Ghosts' involvement. Gave the party holy symbols of Laduguer and gold Themberchaud pins for city travel. When Thorin threatened refusal, Gartokkar read off eight pre-prepared legal charges; when Thorin threatened to reveal the egg's existence to the Stone Guards, Gartokkar turned dark before smiling and dismissing the threat.
3. **Flumph & Negotiation:** The party brought a flumph to him, which trauma-dumped on him — he was "curiously relieved" by this. Demanded the party also retrieve a statue of Demogorgon as proof of demonic worship. Negotiated payment: 2,000 gold for the job plus a 1,000-gold confidentiality rider, 30% upfront (resisted attempts to raise it to half). Issued a direct threat: *"If you betray me, there is no cave, no pool of still water, no river, no place in the dark that I will not find you and hunt you down."*

## Current Status
- **Location:** Keepers of the Flame headquarters, Gracklstugh.
- **Active Operations:** Waiting on the party to retrieve the red dragon egg and the Demogorgon statue from the Whorlestone Caves. Cannot enter the caves himself without revealing the egg's loss — a crucial pillar of his power.
- **Hidden from the Party:** The truth about what "moving on" means for Themberchaud (the Keepers kill and replace the dragon; Grygum already suspects this). His secret war with the Council of Savants. The full extent of his plans to use the Demogorgon statue politically.

## Relationships
- **Themberchaud:** Publicly serves the dragon with reverence; privately, the dragon is a tool of the Keepers. Themberchaud believes the Keepers work for him.
- **The Deepking:** Serves as one of his most prized advisors. Plans to leverage demonic evidence to influence royal policy against the Derro.
- **Council of Savants:** Considers them his worst enemies; engaged in a secret war with them.
- **Gray Ghosts (thieves' guild):** Primary antagonists — stole the dragon egg, humiliating the Keepers. Droki identified as one of their agents.
- **The Party:** Treats them as coerced agents. Maintains a veneer of cordiality but has made explicit threats against betrayal. Holds legal leverage over Thorin specifically. Showed genuine warmth toward Grygum's humor.

## Arc Score Events
- None explicitly noted in source material.
