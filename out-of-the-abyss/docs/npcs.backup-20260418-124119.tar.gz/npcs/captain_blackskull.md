---
name: Captain Blackskull
aliases: []
---

# Captain Blackskull

## Identity
- Referenced by title "Captain"; no faction affiliation explicitly stated beyond a connection to the Deepking's court/domain
- Has not appeared directly; known only through a stolen contract found on Eldgrim's desk

## Personality & Motivations
- Ambitious — the Deepking believes she has long coveted his throne. Her core drive appears to be a claim to or desire for power at the highest level.
- No direct personality observations exist yet, as the party has not met her.

## History with the Party
- **Discovered via stolen contract:** The party found (or learned of) a contract on Eldgrim's desk written by the Deepking. The contract names Captain Blackskull as a suspected traitor and orders that she "receive what's coming to her." The Deepking states she has been suspected of treason since she was young and has "always had an eye on my throne."

## Current Status
- **Last known location:** Unknown
- **Active plans:** Unknown; the contract implies the Deepking has ordered action against her — potentially assassination or arrest
- **Party knowledge:** The party knows the Deepking considers her a long-standing rival and traitor, and that he has issued orders (via Eldgrim's contract) to deal with her. They do not know her current whereabouts, her side of the story, or whether the Deepking's accusations are justified.

## Relationships
- **The Deepking:** Views her as a traitor and threat to his throne; has suspected her since childhood. Has ordered consequences for her.
- **Eldgrim:** Possesses (or possessed) the contract targeting Blackskull, suggesting Eldgrim may be tasked with carrying out the Deepking's orders against her.
- **The Party:** No direct contact. Known to them only as a name on a document.

## Arc Score Events
No arc score events recorded.
