---
name: Brannam
aliases: []
---

# Brannam

## Identity
- Duergar delivery courier
- First appeared on the evening of the 10th of Myrtul, delivering magical weapons and items to the party's location

## Personality & Motivations
- No personality details observed; interaction was purely transactional.

## History with the Party
- Arrived at the party's location on the evening of the 10th of Myrtul to deliver magical weapons and items that had been previously requested by Thorin and Zalthir.

## Current Status
- Last seen completing his delivery to the party
- No further plans or operations noted
- The party knows nothing about him beyond his role as a delivery courier

## Relationships
- **Thorin**: Recipient of the delivered goods; presumably the one who arranged the order
- **Zalthir**: Co-requester of the magical weapons and items delivered by Brannam
