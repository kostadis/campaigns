---
name: Protanther
aliases: []
---

# Protanther

## Identity
- Gold Dragon
- Connected to the events at the Well of the Dragons
- Referenced in historical/legendary context; has not appeared directly before the party

## Personality & Motivations
- A being of immense intellect and patience, having studied a single chess board for 400 years. His true motivations surrounding his famous defeat remain debated — some believe he deliberately chose to lose to align with forces opposing Tiamat, while others attribute the loss to divine intervention by Bahamut.

## History with the Party
- No direct interaction with the party. Protanther is known through the story of the Well of the Dragons and the legendary chess match.

## Current Status
- **Last known status:** Unknown; referenced only in historical/legendary accounts.
- **What the party knows:** The story of his 400-year chess study and his defeat at the hands of the Dwarf Stroud. The competing theories about whether his loss was deliberate or divinely orchestrated.

## Relationships
- **Stroud (Dwarf):** Defeated Protanther in the legendary chess match — a result that stunned chess grandmasters.
- **Bahamut:** Potentially intervened to hide the losing move from Protanther; Protanther's defeat ultimately led to Bahamut gaining a wider following among non-dragon faithful.
- **Tiamat:** Protanther's loss is interpreted by some as a deliberate move to side with those who opposed Tiamat.

## Arc Score Events
None recorded.
