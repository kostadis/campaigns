---
name: Runc
aliases: []
---

# Runc

## Identity
- Orc prisoner held at Velkynvelve
- First encountered by the party as a fellow captive in the drow outpost

## Personality & Motivations
- Devout follower of Gruumsh; deeply troubled by his poor performance in battle and seeking religious absolution. His faith and sense of honor as an orc warrior appear to be central to his identity.

## History with the Party
- Met the party as a fellow prisoner at Velkynvelve.
- Approached Grygum hoping to find a cleric of Gruumsh who could grant him absolution, but was disappointed to learn Grygum serves Bahamut instead.
- Was mocked by Eldeth for the orcish defeat at Gauntlygrym.
- Buppido suggested using Runc as a sacrificial distraction during an escape attempt.

## Current Status
- **Location:** Imprisoned at Velkynvelve.
- **Situation:** Still a captive; no indication he has a role in any escape plan beyond being proposed as expendable bait by Buppido.
- **Hidden information:** None noted beyond what the party has observed.

## Relationships
- **Grygum:** Sought him out for spiritual guidance but was let down by the mismatch in faith (Bahamut vs. Gruumsh).
- **Eldeth:** Hostile dynamic; she taunted him over the orcish loss at Gauntlygrym.
- **Buppido:** Views Runc as disposable — proposed using him as a sacrificial distraction.

## Arc Score Events
None noted.
