---
name: Kaelira
aliases: []
---

# Kaelira

## Identity
- Sister of Nym Duskryn
- Affiliated with Lolth (identified by Daz as a "friend of Lolth")
- First appeared during the battle to extract Daz alive, as part of a contract

## Personality & Motivations
- Direct, physical, and action-oriented — she grabbed Daz and bodily hauled him through danger rather than negotiating. Her blunt declaration ("Come with me if you want to live, you idiot") suggests impatience and a no-nonsense attitude. She is willing to risk poisonous gas and an insect-choked cavern to fulfill her objective.

## History with the Party
- **Extraction Battle:** Kaelira was part of a contract to extract Daz alive. During a battle in an insect-choked cavern, she physically seized Daz's arm and dragged him northeast through poisonous gas to a safer position where her brother Nym Duskryn was waiting. When Asha challenged her presence, Daz identified her as a "friend of Lolth."

## Current Status
- **Last Known Location:** The safer position northeast of the cavern battle, near Nym Duskryn.
- **Active Plans:** Fulfilling the extraction contract — delivering Daz alive.
- **Hidden Information:** The details of the extraction contract (who hired them, the terms, and the ultimate destination for Daz) remain unknown to the party.

## Relationships
- **Nym Duskryn:** Her brother; they are working together on the extraction contract. She delivered Daz to Nym's position.
- **Daz:** The target of her extraction contract. He recognized her and vouched for her, suggesting prior acquaintance or at least awareness of her allegiance.
- **Asha:** Challenged Kaelira's presence during the battle; no established trust.
- **Lolth:** Affiliated in some capacity — the nature of this connection is unclear beyond Daz's identification.

## Arc Score Events
- None recorded.
