---
name: Rumpadump
aliases: []
---

# Rumpadump

## Identity
- Myconid sprout from Stool's circle
- First encountered by the party when Zalthir spotted him looking upset and not dancing, unlike the other myconids in the area

## Personality & Motivations
- Close companion to Stool; the two are frequently seen chatting together. His core drive is returning home to his myconid kin. He expressed pure delight upon arriving at Neverlight Grove, running in and shouting "We're home!"

## History with the Party
1. **Initial Sighting:** Zalthir spotted Rumpadump looking upset and apart from the other dancing myconids. Stool identified him by description and became frantic, believing Rumpadump could explain the strange dancing behavior. The party agreed to attempt a rescue after dealing with assassins.
2. **Traveling Companion:** Rumpadump joined the party and traveled with them. He was seen chatting with Stool as the group left the Whorlestone Caves and passed through the Derro slums.
3. **Arrival at Neverlight Grove:** Rumpadump ran into the Grove alongside Stool with delight. Basidia assured the party that Rumpadump is happy among his kind. Grygum expressed concern about the sprouts' safety and asked if both could continue traveling with the party.

## Current Status
- **Last known location:** Neverlight Grove, reunited with his myconid kin
- Basidia confirmed he is happy there
- His future is uncertain — Grygum raised concerns about the sprouts' safety and suggested they keep traveling with the party

## Relationships
- **Stool:** Close friend and fellow sprout from the same circle; the two are inseparable companions
- **Basidia:** Myconid leader at Neverlight Grove who vouched for Rumpadump's happiness
- **Grygum:** Expressed protective concern for Rumpadump's wellbeing
- **Zalthir:** First party member to spot him
- **The Party:** Traveled with them as a companion; the group undertook a rescue effort to retrieve him
