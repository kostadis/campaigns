---
name: The Pudding King
aliases: []
---

# The Pudding King

## Identity
- Small deep gnome, now warped and transformed; self-styled ruler of an ooze kingdom
- Allied with **Juiblex** (the Faceless Lord, demon lord of oozes); also confirmed in communication with **Zuggtmoy** (Queen of Rot)
- Central source of the ooze plague threatening **Blingdenstone**
- First discovered by the party via Daz's bat familiar, seated on a slime-covered throne deep in caves south of Blingdenstone

## Personality & Motivations
- Driven by vengeance, pride, and madness, all amplified by Juiblex's demonic influence. He seeks to "cleanse" Blingdenstone by converting its population into ooze biomass. He holds court like a deranged king, monologuing and gloating to his ooze henchmen. He is paranoid about Zuggtmoy trying to usurp his promised kingdom, believing Juiblex's claim supersedes hers.

## History with the Party
1. **Scouting phase:** Daz's bat familiar located him on his slime throne in a phosphorescent cave. He was heard broadcasting a disembodied voice welcoming visitors and proclaiming Juiblex's coming.
2. **Intelligence gathering:** Chief Chipgrin revealed the Pudding King was once an ordinary gnome tunnel worker before his transformation. The party learned his demonic corruption is bleeding outward, amplifying greed and aggression across Blingdenstone's population.
3. **Zuggtmoy connection:** The party intercepted a psychic message from Zuggtmoy addressed to him, discussing plans to use oozes to "soften the shell" so her garden could "take root in the flesh beneath."
4. **Assault:** The party observed him through the ochre jelly barricade, monologuing to Princess Ebonheir and Prince Livid about Blingdenstone's imminent fall. He ranted that Zuggtmoy would not take what Juiblex promised him. When Zalthir reached and grappled him, the Pudding King **transformed into an amorphous ooze form**, but Zalthir maintained his grip and dragged him fifteen feet south, isolating him from his henchmen.

## Current Status
- **Last known:** Being grappled by Zalthir in ooze form, dragged away from his throne and henchmen during the assault
- **Active threat:** Controls hundreds of oozes; if incapacitated without coordination, the uncontrolled army would swarm Blingdenstone
- **Party's plan:** Full-scale army distraction at the ooze amphitheater while covertly snatching the Pudding King via magic (plan was in progress at last note)
- **Hidden from party:** The full extent of his arrangement with both Juiblex and Zuggtmoy, and whether those two demon lords are cooperating or competing through him

## Relationships
- **Juiblex:** Primary patron; promised the Pudding King dominion over Blingdenstone in exchange for converting biomass to ooze
- **Zuggtmoy:** In psychic communication with him; wants to use his ooze work as preparation for her own fungal colonization — he resents and distrusts her
- **Princess Ebonheir & Prince Livid:** His two ooze henchmen, present in the throne room during the assault
- **Chief Chipgrin:** Knew him before his transformation; former acquaintance from the tunnels
- **Blingdenstone:** His demonic influence is passively corrupting the entire gnome community
- **Zalthir:** Currently grappling him in combat
- **Daz:** First party member to locate him via bat familiar

## Arc Score Events
- No explicit arc score changes noted in source material.
