---
name: Suushar
aliases: []
---

# Suushar the Awakened

## Identity
- Kuo-toa; self-styled spiritual seeker
- Fellow prisoner / NPC companion traveling with the party
- Aligned with the worship of the Sea Mother; admires Archpriest Ploopploopeen of Sloopbludop

## Personality & Motivations
- Core goal: Reach Sloopbludop and connect with Archpriest Ploopploopeen, whom he regards as a spiritual kindred spirit. He sees his own "awakening" as aligned with the Sea Mother's teachings.
- Calm, earnest, and somewhat naïve. Genuinely confused when others find kuo-toa names difficult to pronounce, happily repeating "Ploopploopeen" multiple times to demonstrate how simple it is. Offers practical opinions (e.g., on corpse disposal and tracker behavior) with quiet confidence. Has no apparent ambition beyond Sloopbludop and the Darklake.

## History with the Party
1. **Thorin's Madness:** Witnessed Thorin suffer a bout of madness and recommended the party seek out Archpriest Ploopploopeen in Sloopbludop for aid, praising the archpriest as a follower of the Sea Mother who could help end the kuo-toa's madness.
2. **Name Tongue-Twister Moment:** When Grygum called the archpriest's name a tongue twister, Suushar was genuinely baffled and repeated the name several times as proof of its simplicity.
3. **Corpse Disposal Debate:** Argued that natural scavenging would obscure any evidence, so trackers couldn't discern anything meaningful from remains left behind.
4. **Travel Plans Discussion:** Stated clearly he has no interest in traveling past Sloopbludop, though he offered that he might be willing to help the party with travel on the Darklake.

## Current Status
- Traveling with the party, destination: **Sloopbludop**
- No known plans beyond reaching the kuo-toa settlement
- **Party knows:** He is a willing guide to Sloopbludop and may assist on the Darklake, but will not continue further.

## Relationships
- **Archpriest Ploopploopeen:** Deep admiration; sees the archpriest as a spiritual leader and ally.
- **Buppido:** Had some kind of calming or enlightening influence on the derro. Buppido later claimed he "learned from Suushar that I was mad," suggesting Suushar helped Buppido recognize his own instability.
- **Thorin:** Showed concern for Thorin's wellbeing during his madness episode.
- **Grygum:** Light comedic rapport over the name pronunciation exchange.

## Arc Score Events
No explicit arc score changes noted.
