---
name: Fargas Rumblefoot
aliases: []
---

# Fargas Rumblefoot

## Identity
- Halfling adventurer, member of a lost adventuring band
- First encountered alive inside a moving spider cocoon in the Silken Paths; communicated telepathically via Stool's rapport spores

## Personality & Motivations
- Core goal: survival — willing to trade valuable secrets in exchange for rescue
- Resourceful and pragmatic; immediately offered treasure knowledge when the party hesitated to free him. Proud and easily offended — was "very miffed" when Zalthir touched his belly to check for gnoll spawn. Attempted to backtrack on his promises when pressed but was smart enough to read the room and cooperate.

## History with the Party
1. **Silken Paths (Discovery):** Found cocooned by spiders, described as "spider snack for later." Explained his adventuring band had been searching for a lost tomb when they were attacked by gnolls. Claimed he escaped the gnolls without being infected. Offered treasure information to incentivize rescue. Thorin was preparing to cut him free as spiders closed in.
2. **Interrogation by Zalthir:** Pressed to reveal the treasure he'd mentioned. Tried to deny his earlier words but was caught out by Grygum's notes. Revealed detailed knowledge of the **floating tomb of Brysis of Khaem** — a half-elf sorcerer from the great empires of magic, whose tomb fell into the Underdark when Netheril collapsed. Shared the critical secret: most treasure hunters find a **false tomb** with a fake sarcophagus, but the real treasure is in a hidden chamber accessible via a secret passageway from the servants' tomb. Said the tomb is on the eastern edge of the Darklake but doesn't know the precise location. Grygum assessed he was telling the truth.
3. **Tomb Validation:** His warning about the false tomb later proved accurate — the party encountered the fake sarcophagus, which was suspiciously easy to open and contained a magical trap.

## Current Status
- Last known status: freed from the cocoon (presumed) and traveling with or near the party
- His adventuring band's fate is unknown
- His key intelligence about the **real treasure chamber** in Brysis's tomb may or may not have been fully exploited yet
- The party knows everything he's shared; no indication of further hidden knowledge

## Relationships
- **Zalthir:** Adversarial dynamic — Zalthir pressed him hard for information and physically checked him for gnoll spawn, which offended him
- **Grygum:** Took detailed notes on Fargas's promises, preventing him from backtracking; also served as a lie detector (assessed Fargas was truthful)
- **Thorin:** Moved to cut him free from the cocoon
- **Stool:** Served as communication intermediary via rapport spores
- **His adventuring band:** Status unknown; were attacked by gnolls before Fargas was captured by spiders

## Arc Score Events
No arc score events noted.
