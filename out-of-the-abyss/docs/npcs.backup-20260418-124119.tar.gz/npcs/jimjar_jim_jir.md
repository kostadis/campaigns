---
name: Jimjar (Jim Jir)
aliases: []
---

# Jimjar (Jim Jir)

## Identity
- Fellow prisoner and escapee
- First appeared during the group's captivity; escaped alongside the party during the sacrificial event

## Personality & Motivations
- Compulsive gambler — immediately frames life-or-death situations in terms of bets. Even as the group is herded toward a sacrificial depression, his instinct is to wager on the outcome. His flippant attitude in dire circumstances suggests either deep fatalism or a coping mechanism built around humor and risk.

## History with the Party
- **Escape Event:** Jimjar was among the prisoners herded toward a sacrificial depression. Before the battle broke out, he offered a bet on how many escapees would survive. After the group fought free and all survived, he noted, "We all made it alive." His comment prompted Grygum to wonder whether Jimjar would cheat on a bet — or even let someone die — to avoid losing one. He fled with the group toward the docks.

## Current Status
- **Last Known Location:** Fleeing with the party toward the docks after the escape
- **Active Plans:** None stated beyond immediate survival
- **Hidden Information:** Grygum's suspicion about Jimjar's willingness to let someone die over a bet remains unresolved — the party does not yet know how far his gambling compulsion truly goes

## Relationships
- **Grygum:** Already distrustful of Jimjar; suspects he might prioritize his bets over the lives of fellow escapees
- **Other Escapees:** Traveling companion by circumstance; no deeper bonds established yet

## Arc Score Events
- None recorded yet.
