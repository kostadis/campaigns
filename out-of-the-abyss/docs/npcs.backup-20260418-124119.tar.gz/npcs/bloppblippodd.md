---
name: Bloppblippodd
aliases: []
---

# Bloppblippodd

## Identity
- Archpriest of the Deep Father (Leemoogoogon) faction in Sloobludop
- Daughter of Ploopploopeen; sister of Glooglugogg
- Kuo-toan religious leader and rival to the Sea Mother faction
- Has not yet appeared in person

## Personality & Motivations
- Driven by a powerful vision of "Leemooggoogoon the Deep Father," which she proclaimed as the new god of the kuo-toan people. She has backed these claims with a tremendous increase in magical power, drawing new followers. Her brother considers her mad and disrespectful of kuo-toan traditions. She refused a diplomatic overture from her own father, suggesting zealous conviction or intransigence.

## History with the Party
- The party has not yet met or seen Bloppblippodd directly. They know of her only through Ploopploopeen's account and Glooglugogg's contemptuous remarks. She is the central target of Ploopploopeen's plan: the party will be presented to her as sacrificial offerings, and when she accepts them, they are to disrupt her rituals so the Sea Mother faction can launch an ambush.

## Current Status
- **Location:** Sloobludop, leading the Deep Father faction
- **Active operations:** Conducting escalating blood sacrifices—killing humanoid offerings and casting bloody chum into the Darklake, where something unknown consumes it
- **Plans in motion:** She is expected to demand to see the offering of prisoners in the morning, triggering Ploopploopeen's planned ambush
- **Known vs. hidden:** The party knows the outline of the plan against her and that she has significant magical power. They do not know the true nature of "the Deep Father," what is consuming the sacrifices in the Darklake, or the full extent of her capabilities. Her hardcore supporters are few, but broader village allegiance is uncertain.

## Relationships
- **Ploopploopeen** (father): Rival faction leader; he plans to use the party to destroy her cult. She refused his diplomatic overture.
- **Glooglugogg** (brother): Holds her in deep contempt; considers her mad and disrespectful of tradition. Blames their father for being too deferential toward her.
- **The Party:** No direct interaction yet; they are pawns in her father's plan against her and will be presented as sacrifices.
- **Leemoogoogon / the Deep Father:** The entity she serves and whose worship she has championed, the true nature of which remains unknown.
