---
name: Ploopploopeen
aliases: []
---

# Ploopploopeen

## Identity
- Archpriest of the Sea Mother, leader of the traditionalist kuo-toa faction in Sloobludop
- First encountered by the party about an hour outside Sloobludop, accompanied by kuo-toan followers moving in a choreographed school-of-fish formation

## Personality & Motivations
- Core goal: Destroy the upstart Deep Father cult led by his daughter Bloppblippodd and restore the Sea Mother as the sole faith of Sloobludop.
- Ploopploopeen is restless and constantly in motion, walking around while speaking. He stares unblinkingly and is deeply proud of the Sea Mother faith, taking offense when it is called a "weird religion." He is pragmatic and manipulative — willing to use the party as bait — but also genuinely hospitable, feeding and housing them. He was delighted when Grygum and Thorin spat on the Sea Mother's altar as an offering, showing cultural openness to outsiders' gestures of respect.

## History with the Party
1. **Suushar's recommendation:** Before meeting Ploopploopeen, Suushar suggested the archpriest could help Thorin with a bout of madness and would welcome Suushar's spiritual awakening.
2. **First meeting (outside Sloobludop):** Ploopploopeen declared the party an answer to the Sea Mother's prayers. A companion cast a spell granting the party understanding of kuo-toan language and body language. He explained the factional split caused by his daughter Bloppblippodd's vision of "Leemooggoogoon the Deep Father" and the escalating blood sacrifices being consumed by something unknown in the Darklake.
3. **The proposal:** He asked the party to pose as a peace offering/sacrifice to the Deep Father faction, serving as infiltrators to distract Bloppblippodd while his faithful launch an ambush. He noted a previous "white flag" approach with his daughter had failed. He clarified that unwilling sacrifices are more valuable to Leemoogoogon, meaning the party's reluctance would actually sell the ruse.
4. **Negotiation:** Initially offered 500 gold and two potions of healing; sweetened the deal with two boats and Darklake guides when the party seemed unimpressed.
5. **Hospitality in Sloobludop:** Fed the party cooked fish, was pleased by their altar offering. Slept standing up outside (kuo-toan custom).
6. **Morning of Day 2:** Admitted a kuo-toa monitor and arranged for himself, his whip, and the "prisoners" to accompany the monitor's group to see the archpriest of the Deep Father — the plan set in motion.

## Current Status
- **Last known:** Accompanying the party as they are escorted toward Bloppblippodd and the Deep Father faction, with the ambush plan active.
- **Active plan:** Present the party as false sacrifices, accompany them personally, then signal his Sea Mother followers to attack and eliminate the Deep Father cult.
- **Hidden from party:** The true scale and danger of the Deep Father faction's power; what is actually consuming the bloody chum in the Darklake; the full extent of Bloppblippodd's increased magical abilities.

## Relationships
- **Bloppblippodd (daughter):** Deeply strained. She leads the rival Deep Father cult and refused his earlier peace overture. He intends to personally "take care of her" during the ambush.
- **Glooglugogg (son):** Believes Ploopploopeen was too lenient with Bloppblippodd, contributing to the current crisis.
- **Suushar:** Fellow Sea Mother faithful; Suushar spoke highly of Ploopploopeen and expected a warm welcome.
- **The Party:** Transactional alliance. He sees them as useful tools — bait for his ambush — but has been hospitable and mostly forthcoming. He dismissed their concerns about enemy numbers.
- **Grygum & Thorin:** Specifically pleased by their altar offering; assured Thorin about kuo-toan eating habits.
