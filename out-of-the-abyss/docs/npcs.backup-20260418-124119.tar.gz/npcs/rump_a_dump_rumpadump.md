---
name: Rump-a-dump (Rumpadump)
aliases: []
---

# Rump-a-dump (Rumpadump)

## Identity
- Myconid, companion of the party
- Traveled with the party alongside fellow Myconid, Stool

## Personality & Motivations
- Opinionated and surprisingly verbose for a Myconid — delivered approximately fifty specific pieces of unsolicited self-improvement advice to Zalthir upon departure. Practical-minded (e.g., dietary advice about Zurkhwood) but also emotionally perceptive, valuing good listening and open-mindedness. Showed genuine emotional attachment to party members, particularly Daz.

## History with the Party
- Traveled with the party as a companion alongside Stool.
- Grygum convinced Rump-a-dump and Stool that Neverlight Grove was no longer safe.
- Before departing, delivered an extensive list (~50 items) of self-improvement suggestions to Zalthir, including advice on listening to Stool, humility, and eating more Zurkhwood.
- Said a sad goodbye to Daz before leaving with the other Myconids.

## Current Status
- **Last known location:** Departed with the Myconid people, away from Neverlight Grove.
- **Status:** No longer traveling with the party.
- No known hidden information.

## Relationships
- **Stool:** Fellow Myconid companion; Rump-a-dump clearly respects Stool ("Listen to Stool, he knows what he is doing").
- **Zalthir:** Felt compelled to deliver extensive constructive criticism before parting — suggests a mix of care and exasperation.
- **Daz:** Showed genuine sadness when saying goodbye; an emotional bond formed during their travels.
- **Grygum:** Trusted Grygum's warning about Neverlight Grove enough to leave.
