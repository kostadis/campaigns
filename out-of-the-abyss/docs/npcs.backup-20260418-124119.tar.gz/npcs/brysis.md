---
name: Brysis
aliases: []
---

# Brysis

## Identity
- Wraith, ancient undead entity
- Encountered trapped within a sarcophagus tomb in an underground location
- First appeared when the party opened or disturbed her tomb

## Personality & Motivations
- Driven by a desperate desire for freedom after millennia of imprisonment. Reacted with immediate hostility and fear upon seeing Dawnbringer, suggesting prior knowledge of—and vulnerability to—the weapon. Defiant and unwilling to accept defeat even when outmatched.

## History with the Party
- **Pre-encounter:** Fargas Rumblefoot warned the party about a false tomb with a magical trap—a decoy set up by Brysis.
- **Encounter:** When Thorin activated Dawnbringer, Brysis screamed "Not Dawnbringer!" revealing her fear of the weapon. She declared she had waited millennia to be free and would not be denied. Daz struck her with spells, and the party fought her as a group. Grygum delivered the killing blow with an acid breath attack (described memorably by Zalthir as "killed by barf").
- **Aftermath:** With Brysis's destruction, the magical trap in her false/decoy tomb dissipated. The party looted her real tomb, recovering a **necklace of fireballs**, a **potion of greater healing**, and **gold**.

## Current Status
- **Dead.** Destroyed by the party in combat.
- The false tomb trap has dissipated; the real tomb has been looted.

## Relationships
- **Fargas Rumblefoot:** Knew enough about Brysis's lair to warn the party about the false tomb trap.
- **Dawnbringer:** Brysis recognized and feared the weapon on sight, implying a historical connection or known vulnerability.
- **Party members involved:** Thorin (activated Dawnbringer), Daz (spell damage), Grygum (killing blow), Zalthir (present, provided colorful commentary).
