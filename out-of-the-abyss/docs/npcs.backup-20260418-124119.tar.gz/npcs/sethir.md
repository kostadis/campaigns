---
name: Sethir
aliases: []
---

# Sethir

## Identity
- NPC companion/fellow traveler in the Underdark escape party
- No stated faction affiliation or title
- Encountered as part of the group traveling through the Underdark (exact first meeting not specified in notes)

## Personality & Motivations
- Core goal: Reaching the Lost Tomb of Khem to find treasure — he brings this up repeatedly and with enthusiasm.
- Sethir is impulsive and treasure-motivated, often steering group decisions toward loot opportunities. He has a practical streak, noting that the Darklake route would be safer than tunnels. Other party members find him "a bit off," and he seems susceptible to the strange magical influences of the Underdark.

## History with the Party
1. **Faerzress Tunnels:** Sethir was noticeably affected by the Faerzress's eerie magic while the group traveled through tunnels saturated with it.
2. **Destination Debate:** Advocated strongly for exploring the lost temple for treasure. Also suggested traveling along the Darklake as a safer alternative to tunnel routes.
3. **Post-Ambush (Kuo-toa encounter):** After the kuo-toan ambush, Sethir spoke up briefly — "Should we continue?" — before the group pressed on toward Sloobludop.
4. **Gracklstugh:** Present in the city. Openly discussed the party's plans aloud, stating they intended to get equipment and then head to the Lost Tomb of Khem for treasure.
5. **Daz's Suspicion:** At some point, Daz flagged Sethir as suspicious, noting he "seems a bit off."

## Current Status
- **Last known location:** Gracklstugh, with the party.
- **Active plans:** Wants to acquire equipment in Gracklstugh and then travel to the Lost Tomb of Khem.
- **Hidden information:** The nature of his "off" behavior and his susceptibility to Faerzress remain unexplained. It is unclear whether his oddness is simply personality, Faerzress influence, or something more sinister.

## Relationships
- **Daz:** Daz is suspicious of Sethir and has voiced this to the group.
- **The Party (general):** Travels with them but is not deeply trusted. His habit of blurting out plans (e.g., loudly announcing intentions in Gracklstugh) may be a liability.

## Arc Score Events
- No explicit arc score changes noted in the source material.
