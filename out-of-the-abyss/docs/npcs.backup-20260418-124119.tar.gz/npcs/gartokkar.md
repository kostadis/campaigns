---
name: Gartokkar
aliases: []
---

# Gartokkar

## Identity
- Duergar member (or associate) of the Keepers of the Flame
- First encountered through a prior arrangement to retrieve a dragon egg; the party met him at his house in Gracklstugh when they delivered it

## Personality & Motivations
- Described in Narrak's letter as paranoid and harboring desires for a "genocidal war" against the Derro. In person, he was eager and transactional — pleased to receive the egg and quick to honor the deal. He showed genuine fear about the city's instability, warning the party earnestly about the dangers of the Ember Vanguard and the potential for civil war. Daz assessed his warnings as coming from a place of real concern, not manipulation.

## History with the Party
1. **Pre-session arrangement:** Gartokkar had an existing deal with the party to retrieve a dragon egg.
2. **Egg delivery:** The party brought him a mutated dragon egg with strange occult markings. He was worried by the markings but asked Grygum (cleric of Bahamut) to evaluate it. He was satisfied by Grygum's assessment that the chromatic egg would produce an evil creature.
3. **Payment and NDA:** He honored the deal — provided a bag of coins and upheld their non-disclosure agreement.
4. **Warning:** Before the party left, he issued a serious warning about the Deepking's agents searching for the Ember Vanguard (shadowy assassins from Menzoberanzan with powerful magic and soul-rending blades). He stressed that the Derro, Stone Guard, and Grey Ghosts are all on edge, and some factions actively want conflict.
5. **Escape plan:** The party used the transaction with Gartokkar as a stepping stone to flee Gracklstugh via the ports before Errde Blackskull could imprison them. Grygum's cover story was that the egg had been stolen not by the Derro but by "some other crazed group."

## Current Status
- **Last known location:** His house in Gracklstugh
- **Active plans:** Unknown beyond his Keepers of the Flame affiliation and his apparent desire (per Narrak's letter) for conflict with the Derro
- **Hidden from the party:** The full extent of his paranoia and his alleged ambitions for genocidal war against the Derro (known only through Narrak's letter, not confirmed firsthand)

## Relationships
- **Keepers of the Flame:** Affiliated; exact rank unknown
- **Narrak:** Narrak's letter discusses Gartokkar's paranoia and war ambitions — suggests they are known to each other within faction politics
- **Grygum:** Respected his clerical authority enough to ask for an evaluation of the egg; dealt with him fairly
- **The Party (general):** Transactional but not hostile; warned them out of what appeared to be genuine concern
- **Errde Blackskull:** No direct relationship noted, but the party used Gartokkar as a way to avoid Blackskull's reach
- **The Derro:** Antagonistic — allegedly wants war against them

## Arc Score Events
- None explicitly noted.
