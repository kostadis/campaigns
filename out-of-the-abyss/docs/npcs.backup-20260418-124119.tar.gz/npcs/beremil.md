---
name: Beremil
aliases: []
---

# Beremil

## Identity
- Drow guard stationed at the Drow outpost
- Oversees the water-carrying chore for prisoners
- First encountered when he escorted a work detail (Ront, Prince Derendil, and Thorin) to the waterfall

## Personality & Motivations
- A rank-and-file enforcer carrying out routine duties at the outpost. Barks short, direct orders at prisoners with no patience for delay. Shows no particular cruelty beyond the baseline authority expected of a Drow guard — he has a job and he does it.

## History with the Party
- Took Ront, Prince Derendil, and Thorin on a water-carrying chore: first to fill buckets at the waterfall, then to deliver the water to Ilvara's quarters.

## Current Status
- **Location:** Drow outpost
- **Activity:** Performing guard duties, including supervising prisoner work details
- **Party knowledge:** The party knows his name, his role in the chore rotation, and that the water route passes by the waterfall and leads to Ilvara's quarters — potentially useful intelligence for an escape or infiltration attempt

## Relationships
- **Ilvara:** Serves under her authority; delivers water directly to her quarters
- **Ront, Prince Derendil, Thorin:** Prisoners he has supervised on work detail
