---
name: Prince Derendil
aliases: []
---

# Prince Derendil

## Identity
- Quaggoth prisoner at Velkynvelve who claims to be a cursed elven prince
- Claims his true identity is a prince of the "Kingdom of Nelrindenvane" in the High Forest, transformed into Quaggoth form by an evil wizard named Terrestor
- First appeared as a fellow prisoner in the Velkynvelve slave pen

## Personality & Motivations
- Core goal: escape captivity and presumably reverse his "curse"
- Speaks with a rarefied upper-kingdom elven accent and demands respect befitting his claimed royal station. Refers to his Quaggoth body as "hideous," fully committed to his identity as a transformed prince. Brave to the point of recklessness — volunteered eagerly for combat during the escape. Politically astute, offering sharp observations about Drow society and Lolth worship.

## History with the Party
1. **Velkynvelve (Slave Pen):** Met the party as a fellow prisoner. Provided tactical intel — noted three Drow guards stationed across from the cell door. Daz identified him as a liar (no Kingdom of Nelrindenvane exists) but chose not to confront him, seeing him as a useful "Fake Prince" ally.
2. **Work Duties:** Assigned to water-carrying duty under Beremil alongside Ront and Thorin. Recalled Ilvara's arrival speech in vivid detail. Was threatened by Ilvara with a knife when he objected to his enslaved status.
3. **Escape Planning:** Contributed political insight, noting "no abolitionist movement amongst those who worship Llolth" and warning that Jorlan's offer to help must be self-serving.
4. **Escape Attempt — Death:** Declared himself "already armed in this hideous form" and charged elite Drow warrior Imbros with great enthusiasm. Was struck twice with Drow Poison and ultimately stabbed to death by Imbros.
5. **Posthumous:** Remembered later by Zalthir upon encountering quaggoth spore servants, referred to as "the mad quaggoth, who was a polymorphed elf."

## Current Status
- **Dead.** Killed by Imbros during the Velkynvelve escape.
- His death deeply affected Serith and was noted as a significant loss to the party.

## Relationships
- **Daz:** Saw through his claims but kept silent for strategic reasons; viewed him as a useful ally.
- **Serith:** Deeply affected by Derendil's death.
- **Zalthir:** Remembered him with some fondness posthumously.
- **Thorin / Ront:** Fellow work-detail prisoners under Beremil.
- **Ilvara:** Antagonistic; she personally threatened him with a knife.
- **Imbros:** His killer.

## Arc Score Events
- Derendil's death during the escape — likely a negative emotional beat for party morale and individual character arcs (notably Serith's).
