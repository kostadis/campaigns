---
name: Hargaam
aliases: []
---

# Hargaam

## Identity
- Associated with stone giants; appears to hold a leadership or authority role over a group of stone giants
- Not yet directly encountered by the party

## Personality & Motivations
- Unknown. Hargaam has only been referenced indirectly and has not appeared in play.

## History with the Party
- No direct interactions. The party learned that at least one of Hargaam's stone giants was driven mad as a result of Narrak's ritual, which involved a two-headed stone giant statue and a text called *The Rituals of the Two-Headed Beast*.

## Current Status
- Last known location: Unknown
- Active plans: Unknown
- **What the party knows:** One of Hargaam's stone giants was affected by Narrak's ritual. The party likely understands Hargaam as a stone giant leader whose followers are being targeted or corrupted.
- **What remains hidden:** Nearly everything — Hargaam's location, disposition, goals, and awareness of the party are all unknown.

## Relationships
- **Narrak:** Antagonistic (at minimum indirect). Narrak's ritual drove one of Hargaam's stone giants mad.
- **Stone giants:** Commands or is affiliated with a group of stone giants.
- **The Party:** No direct relationship yet.
