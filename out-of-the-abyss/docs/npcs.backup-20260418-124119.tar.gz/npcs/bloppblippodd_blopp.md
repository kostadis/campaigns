---
name: Bloppblippodd (Blopp)
aliases: []
---

# Bloppblippodd (Blopp)

## Identity
- Archpriest of the Deep Father (Leemooggoogoon/Demogorgon)
- Young kuo-toa cleric; daughter of Ploopploopeen
- First encountered at the sacrificial altar in the kuo-toa settlement, where she presided over a ritual involving the party as intended sacrifices

## Personality & Motivations
- Fanatically devoted to the Deep Father, willing to oversee blood sacrifice without hesitation. Commanding and authoritative despite her youth, she directed subordinates with confidence and fury. Even in death, her final act was one of zealous devotion — completing the summoning ritual with her dying breath.

## History with the Party
- **Sacrificial Ritual:** The party was brought before Blopp as offerings by her father Ploopploopeen. She accepted them eagerly, declaring "May their blood nourish and strengthen him!" and called for the sacrificial knife, ordering the escapees herded toward the blood-stained altar.
- **Betrayal & Battle:** When Ploopploopeen turned on her and attacked, Blopp screamed at her kuo-toa subordinates to block the party's escape. She and her father exchanged curses and spells in combat.
- **Death & Summoning:** Ploopploopeen struck the fatal blow. With her dying breath, Blopp cried out "Leemooggoogoon!" — her death completing the profane ritual and triggering the summoning of Demogorgon from the Darklake.

## Current Status
- **Dead.** Killed by her father Ploopploopeen at the altar of the Deep Father.
- Her death was the final catalyst that summoned Demogorgon into the material world.

## Relationships
- **Ploopploopeen (father):** Bitter enemies despite blood relation. He used the party as pawns in a scheme to eliminate her, ultimately killing her himself — though this played directly into her ritual's design.
- **The Party:** Viewed them solely as sacrificial offerings. No personal connection.
- **Kuo-toa subordinates:** Commanded their loyalty as archpriest; at least one second-in-command followed her orders during the battle.
- **Demogorgon (the Deep Father / "Leemooggoogoon"):** The entity she worshipped and ultimately summoned through her own sacrificial death.

## Arc Score Events
- Blopp's death and the subsequent summoning of Demogorgon represent a major campaign-altering event — the demon lord's emergence into the Underdark likely serves as an inciting incident or escalation point for the broader narrative.
