---
name: Burrow Warden Jadger
aliases: []
---

# Burrow Warden Jadger

## Identity
- Spectral leader of the Burrow Warden ghosts in Blingdenstone
- First encountered during the party's time in Blingdenstone, participating in a council meeting

## Personality & Motivations
- Deeply protective of sacred ground and the burial sites of the Burrow Wardens. Willing to engage in political negotiation to defend these places rather than resort to obstruction alone.
- Commands respect and ceremony — demonstrated by the formal banner salute upon the party's departure.

## History with the Party
- **Council Meeting:** Jadger's ghost faction objected to the Miners Guild's plans to strip-mine the sanctum, which the ghosts considered sacred burial grounds. A sustainable mining compromise was ultimately brokered that respected the burial sites.
- **Departure from Blingdenstone:** Jadger and the Burrow Warden ghosts dipped their spectral banners in salute as the Ember Vanguard left the city — a gesture of honor and respect.

## Current Status
- Last known location: Blingdenstone
- Presumably continuing to watch over the sacred burial grounds under the terms of the mining compromise
- No hidden agendas indicated in the notes

## Relationships
- **Miners Guild (Blingdenstone):** Tension over use of the sanctum; resolved through a sustainable mining compromise, though underlying friction may remain.
- **The Ember Vanguard (the party):** Respectful, possibly grateful — the formal banner salute suggests the party earned the ghosts' regard, likely through helping broker or support the compromise.
