---
name: Princess Ebonheir
aliases: []
---

# Princess Ebonheir

## Identity
- One of the Pudding King's two ooze henchmen
- Present in the Pudding King's throne room

## Personality & Motivations
- Serves the Pudding King as a loyal enforcer/companion. No independent personality traits observed beyond her role as his ooze minion.

## History with the Party
- **Throne Room Encounter:** Present during the Pudding King's monologue about victory. When Zalthir grappled the Pudding King and dragged him fifteen feet south, Princess Ebonheir was separated from her master.

## Current Status
- **Last Known Location:** The Pudding King's throne room, separated from the Pudding King after Zalthir's grapple maneuver.
- **Active Situation:** Combat likely ongoing; positionally isolated from the Pudding King.
- **Party Knowledge:** The party knows she is one of two ooze henchmen and that she is now separated from her master.

## Relationships
- **The Pudding King:** Loyal ooze henchman; serves alongside a second unnamed ooze companion.
- **Zalthir (Party Member):** Indirectly affected by Zalthir's grapple of the Pudding King, which created distance between her and her master.
