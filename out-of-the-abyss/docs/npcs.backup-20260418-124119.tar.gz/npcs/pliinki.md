---
name: Pliinki
aliases: []
---

# Pliinki

## Identity
- Derro devotee of Demogorgon; cult authority figure and experimentalist
- Faction ties to the Gray Ghosts and Council of Savants through her co-conspirators
- Never encountered alive by the party; found dead (killed by the party off-screen or in passing) at the obelisk chamber guard post

## Personality & Motivations
- Core goal: conquer Gracklstugh and offer it as a sacrificial gift to Demogorgon. She pursued this through destabilization — stolen eggs, assassination lists, and sowing discord among the Derro and Duergar.
- Driven by religious fanaticism and Derro liberation rhetoric, promising her followers that Demogorgon's power would free the Derro from Duergar bondage. She was ambitious enough to attempt mutating a stolen red dragon egg into a two-headed wyrmling as a mount for Demogorgon.

## History with the Party
- **Obelisk Chamber:** The party killed Pliinki (details sparse) and passed through her guard post. Zalthir recovered her journal and letters from a desk in the northwest corner of the obelisk chamber, revealing the full scope of her plans.
- **Prior References:** Before reaching the chamber, the party encountered Skiit and Ulnara, both of whom answered to Pliinki. Skiit cited Pliinki's promises of a better job and her declarations that followers of Demogorgon would make the Derro proud and powerful. Ulnara hoped the party would tell Pliinki she had been helpful.

## Current Status
- **Dead.** Killed by the party.
- Her journal revealed her plans, experiments, and co-conspirators — all now known to the party.
- The Obelisk (which she called "The Stone of Diirinka") remains; her attempts to mend its fractures using Thrazgad ore failed.

## Relationships
- **Uskvil** — Leader of the Gray Ghosts; co-conspirator in the destabilization plot.
- **Aliinka** — Member of the Council of Savants and Gray Ghosts; co-conspirator.
- **Narrak** — Cult leader; co-conspirator.
- **Skiit** — Derro underling who sought her approval and believed her promises.
- **Ulnara** — Derro underling who wanted to be seen as helpful by Pliinki.
- **Derro guards (double doors)** — Loyal followers she had promised liberation from Duergar rule.
- **Zalthir** — Party member who recovered her journal and letters.
