---
name: Nym Duskryn
aliases: []
---

# Nym Duskryn

## Identity
- Drow mercenary/contractor, one of the Duskryn sisters (alongside Kaelira)
- Hired under contract to extract Daz alive from the Underdark
- First appeared in a cavern battle, working alongside her sister to fulfill their extraction contract

## Personality & Motivations
- **Core goal:** Complete the contract — deliver Daz alive and get paid. Everything else is secondary.
- Nym is coolly professional, transactional, and pragmatic. She calculates cost-benefit in real time, visibly assessing whether the contract remains viable even amid battlefield chaos. Her frustration manifests not as emotion but as redirected efficiency — when Daz won't cooperate, she simply finds someone she *can* kill. She holds open contempt for Jorlan Duskryn, whom she considers the family idiot.

## History with the Party
- **Cavern Battle:** Present alongside Kaelira to extract Daz. Urged Daz to stay out of combat to preserve her payday. Daz refused, insisting he wouldn't abandon his companions and telling her the best way to get paid was to keep fighting.
- Frustrated by Daz's stubbornness, she asked with genuine professional inquiry whether she could kill Jorlan Duskryn — her own kin — calling him "always the dumber of the ones" and noting he was covered in fungus. She struck Jorlan with a lightning bolt during the fight, sending him staggering.
- When Asha Vandree confronted the Duskryn sisters as potential traitors to Lolth, Daz defused the situation by introducing Nym and Kaelira as "friends of Lolth" who were there to help, folding them into his ongoing cover identity.

## Current Status
- **Last known location:** The cavern battlefield.
- **Active operations:** Still under contract to extract Daz alive. Contract viability is uncertain given Daz's refusal to prioritize his own survival.
- **Party knowledge:** The party knows she and Kaelira are mercenaries hired to extract Daz, and that their motivation is purely financial. It is unknown who hired them or what happens if the contract fails.

## Relationships
- **Kaelira Duskryn** — Her sister and partner on this contract. They operate as a unit.
- **Daz** — Her extraction target and source of professional frustration. He refuses to cooperate with her plan to keep him safe, insisting on fighting alongside his companions. She respects (or at least tolerates) his resolve enough to keep working.
- **Jorlan Duskryn** — A relative she holds in open contempt. She asked permission to kill him and then hit him with a lightning bolt. Described him as "always the dumber of the ones."
- **Asha Vandree** — Asha suspected Nym of being a traitor to Lolth. The confrontation was defused by Daz's cover story, not by Nym herself.
- **The Party** — Nominally allied through Daz. Her loyalty extends exactly as far as her contract.
