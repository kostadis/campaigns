---
name: Dawnbringer
aliases: []
---

# Dawnbringer

## Identity
- Sentient sunblade (magical weapon); appears as a sword hilt that manifests a shimmering blade of light when wielded
- Discovered in a sarcophagus, held by a mummified corpse; the party found her and she pleaded for help after millennia of imprisonment
- Currently wielded by Thorin

## Personality & Motivations
- Desperately fears confinement and darkness after millennia of imprisonment; initially refused to extinguish her light even at night. Loves open air and bright light.
- Opinionated and chatty — quick to dismiss those she deems unsuitable ("You're a monk! Get the fighter over here!") and eager to assert her usefulness, sometimes impulsively (shouting about lesser restoration before anyone asked).
- Pragmatic about self-preservation; argued against Thorin jumping across an acid pit and negotiated concessions before entering dark chambers.
- Shows a compassionate side, agreeing that mercifully killing Xinaya was a kind gesture.

## History with the Party
1. **Discovery**: Found in a sarcophagus. Pleaded for help, rejected Zalthir (a monk), and bonded with Thorin when he picked her up. The wraith Brysis screamed "Not Dawnbringer!" — indicating she is a known and feared weapon against undead.
2. **Early friction**: Refused to extinguish her light at night, keeping the party visible and driving Daz crazy. Thorin compassionately kept her lit.
3. **Neverlight Grove**: Enjoyed the open air; her sunlight hurt fungal creatures as actual sunlight during the Circle of Welcome battle. However, her bright light was counterproductive in the Inner Circle, causing Myconids to retreat and undermining stealth.
4. **Lesser Restoration**: Impulsively cast lesser restoration on Zalthir to cure his madness before Grygum could act.
5. **Xinaya**: Agreed with Thorin that a mercy kill was a kind gesture.
6. **Earth Elemental chamber**: Negotiated with Thorin — agreed to enter the dark chamber in exchange for a finer scabbard.
7. **Scabbard commissioned**: Valimor Brightgem crafted a proper locking scabbard; Dawnbringer was finally pleased with a secure, presentable home. Prior to this, her flaming appearance had been attracting attention from local children.
8. **Black Pudding pit**: Argued against Thorin jumping across acid; convinced him to use the bridge instead.

## Current Status
- Carried by Thorin in her new locking scabbard (crafted by Valimor Brightgem)
- Active and chatty; continues to provide combat utility and lesser restoration
- No hidden agenda evident from notes

## Relationships
- **Thorin**: Primary wielder and closest bond. Relationship is affectionate but occasionally contentious — they negotiate and bicker like partners. Thorin shows her compassion; she respects his fighting ability.
- **Zalthir**: Dismissed him immediately as a monk; later cast lesser restoration on him (impulsively but helpfully).
- **Daz**: Source of friction — Dawnbringer's refusal to dim her light drove Daz crazy.
- **Brysis (wraith)**: Feared Dawnbringer by name — a known nemesis of undead.
- **Valimor Brightgem**: Craftsman who made her scabbard; Dawnbringer was pleased with his work.
