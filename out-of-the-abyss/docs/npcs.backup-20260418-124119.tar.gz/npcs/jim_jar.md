---
name: Jim Jar
aliases: []
---

# Jim Jar

## Identity
- NPC companion traveling with the party
- No specific role, title, or faction affiliation noted

## Personality & Motivations
- Shows visible concern for the party's safety, as evidenced by his worried expression when told to stay behind. Core goals and deeper motivations not yet revealed.

## History with the Party
- Traveled with the party as one of several NPC companions.
- Was instructed by Daz to wait outside the final cavern entrance — one that reeked of brimstone and chemicals — along with other companions. He visibly looked worried at being told to stay behind.

## Current Status
- **Last known location:** Waiting outside the final cavern entrance (brimstone/chemical smell).
- **Activity:** Standing by with other NPC companions per Daz's instruction.
- **Hidden information:** None noted; very little is known about him overall.

## Relationships
- **The Party (general):** Loyal companion; follows directions but shows emotional investment in the group's well-being.
- **Daz:** Responds to Daz's commands/directions; deferred to Daz's motion to stay behind despite apparent concern.

## Arc Score Events
None noted.
