---
name: Shuushar the Awakened
aliases: []
---

# Shuushar the Awakened

## Identity
- Kuo-Toa, fellow prisoner at Velkynvelve
- Claims to have "found enlightenment" and discovered a way to resist the madness common among his people
- First encountered as one of the captives held alongside the party in Velkynvelve

## Personality & Motivations
- Core goal: return to his home settlement of Sloobludop, located near the Darklake
- Speaks in a soothing manner; presents himself as calm, philosophical, and self-aware — unusual for a Kuo-Toa. Projects an air of peaceful detachment from the dire circumstances of captivity.

## History with the Party
- **Velkynvelve (imprisonment):** Met the party as a fellow prisoner. Offered to serve as a guide through the Underdark to Sloobludop, citing extensive knowledge of the winding roads. His offer is currently under consideration.

## Current Status
- **Last known location:** Prisoner at Velkynvelve
- **Active plans:** Wants to travel to Sloobludop near the Darklake; has offered to guide the party there
- **Known vs. hidden:** The party knows his stated goal and his claim of enlightenment. Whether his claims are genuine or whether he can truly be trusted remains unverified.

## Relationships
- **Daz (party member):** Cautiously interested in Shuushar's offer but uncertain whether a Kuo-Toa can be relied upon.
- **Other Velkynvelve prisoners:** Fellow captive; no specific alliances or conflicts noted yet.

## Arc Score Events
None recorded yet.
