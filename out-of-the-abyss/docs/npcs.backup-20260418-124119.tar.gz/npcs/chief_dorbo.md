---
name: Chief Dorbo
aliases: []
---

# Chief Dorbo

## Identity
- Leader of the mining coalition in Blingdenstone
- Based in Diggermattock Hall
- First encountered during a heated discussion with Senni about the settlement's future

## Personality & Motivations
- Primarily driven by mining operations, economic concerns, and the material prosperity of Blingdenstone. His obsession with money has been noted as seemingly unhinged given the existential threats facing the settlement. Chipgrin suggested this greed is amplified by demonic corruption bleeding through the Pudding King's influence, affecting the community's leadership. He is territorial about his personal space (annoyed when Thorin intruded into his private kitchen) and stubborn in his stances, particularly regarding the Gold Whisker clan.

## History with the Party
1. **Diggermattock Hall (First Meeting):** Explained the ooze infestations hindering mining and housing construction. After being confronted by Senni about his failure to address the ooze problem, agreed the party would need to deal with the ooze threat before he could help them. Shared suspicions that the Gold Whisker clan are wererats and refused to cooperate with them.
2. **Planning Session:** Agreed to support Daz's plan. Was annoyed when Thorin intruded into his private kitchen, directing the party to the Foaming Bug inn instead.
3. **Grand Moot:** Proposed attacking from the Temple of the Steadfast Stone as a staging area to keep oozes away from population centers. Offered a **Stone of Controlling Earth Elementals** as reward for dealing with Ogremoch's Bane and cleansing the temple.
4. **Elemental Labor Debate:** Present when the party argued against enslaving Earth Elementals, comparing it to Drow slavery. Witnessed religious leaders agreeing that enslaving summoned creatures violated their beliefs.

## Current Status
- **Location:** Diggermattock Hall, Blingdenstone
- **Active concerns:** Mining operations stalled by ooze infestations; awaiting the party's resolution of the ooze/Pudding King threat
- **Hidden from party:** The extent to which demonic corruption may be influencing his judgment and amplifying his greed and aggression

## Relationships
- **Senni:** Frequent disagreements; she confronts him about his failures and his refusal to work with the Gold Whisker clan
- **Gold Whisker Clan:** Refuses cooperation; suspects them of being wererats
- **Chipgrin:** Chipgrin views Dorbo's behavior as evidence of demonic corruption
- **Thorin:** Minor friction after the kitchen intrusion
- **The Party:** Transactional relationship; willing to reward them for solving the ooze problem but prioritizes his own agenda

## Arc Score Events
- No explicit arc score changes noted in source material.
