---
name: Rumpadump (Rump-a-dump)
aliases: []
---

# Rumpadump (Rump-a-dump)

## Identity
- Myconid child; associated with the Neverlight Grove
- Likely encountered as a fellow captive or companion during Underdark travel

## Personality & Motivations
- Core goal: Return to the Neverlight Grove, which he considers home
- Deeply trusting and naïve, holding an unshakeable faith in the myconid sovereign and the sanctity of the Grove. His childlike innocence leads him to dismiss warnings of danger outright, insisting the circle "cannot be corrupted."

## History with the Party
- Expressed a strong desire, alongside Stool, to travel to the Neverlight Grove.
- When Zalthir warned that a very dangerous and mighty demon was present at the Grove, Rumpadump refused to believe it, declaring that the sovereign would never allow such corruption. Zalthir considered correcting him but chose not to, recognizing that Rumpadump is just a child.

## Current Status
- Last known status: Traveling with or near the party, intent on reaching Neverlight Grove
- Remains completely unaware of the demonic threat at the Grove
- **What the party knows:** Zalthir has warned them about a powerful demon at Neverlight Grove
- **What remains hidden (from Rumpadump):** The true danger awaiting at the Grove; Zalthir deliberately withheld the full truth from him

## Relationships
- **Stool:** Fellow myconid child and travel companion; shares the same goal of reaching Neverlight Grove
- **Zalthir:** Zalthir is aware of the danger at the Grove but chose to spare Rumpadump the truth out of compassion for his youth
- **The Myconid Sovereign:** Rumpadump holds absolute faith in the sovereign's ability to protect the Grove

## Arc Score Events
- No arc score changes noted in the source material.
