---
name: Tappy Foamstrap
aliases: []
---

# Tappy Foamstrap

## Identity
- Owner of the Foaming Mug Tavern, a massive cave converted into an inn with human-sized rooms
- Deep gnome
- First appeared when the party stayed at her tavern overnight

## Personality & Motivations
- Deeply bored, having heard every local patron's stories dozens of times over. Desperate for fresh tales and new faces. Protective of her tavern's reputation — she agreed to sell the party spoiled booze but only on the condition it wouldn't reflect poorly on her establishment.

## History with the Party
1. **Evening stay:** Hosted the party at the Foaming Mug Tavern, engaging with them as a welcome source of new stories.
2. **Next morning:** Negotiated a deal to sell the party barrels of spoiled booze, which they planned to use as improvised weapons against oozes. The agreement was contingent on protecting the tavern's reputation.

## Current Status
- **Location:** The Foaming Mug Tavern
- **Activity:** Running her tavern as usual
- **Party knowledge:** The party knows her as a friendly, story-hungry innkeeper willing to make unconventional deals. No hidden information noted.

## Relationships
- **The Party:** Amicable; views them as entertaining newcomers and viable trade partners. Trusts them enough to sell off-menu goods so long as her business name stays clean.
