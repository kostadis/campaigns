---
name: Dorbo Diggermattock
aliases: []
---

# Dorbo Diggermattock

## Identity
- Chief of Clan Diggermattock and de facto leader of Blingdenstone
- Found at Diggermattock Hall, seated behind a stone desk on a raised dais
- First encountered when the party was escorted to him after a sergeant failed to properly read his memo about Drow escapees being brought to him immediately

## Personality & Motivations
- Profit-driven and focused on protecting the mines and extracting mithral; his economic priorities often clash with his wife Senni's people-first concerns. Blunt and opinionated — he openly called Grygum's gnome army distraction plan "the dumbest he had ever heard." He can be argumentative and territorial (seen bickering with Chipgrin over newly opened territory even as oozes threatened), but he is capable of being moved to genuine sentiment, as when he sewed a Diggermattock Miners patch onto Thorin's gear. He yields to forceful leadership when outmatched in a debate, as demonstrated when Daz seized control of a discussion and stunned him into agreement.

## History with the Party
1. **First Meeting:** The party was chased down by guards after a sergeant failed to read Dorbo's memo about Drow escapees. Dorbo greeted them in Diggermattock Hall and argued with Senni over whether to help the party reach the Overbright versus leveraging them for the community's needs.
2. **Ooze Problem Commission:** Hired the adventurers to investigate the ooze threat. When the party reported back about the Pudding King and his army of hundreds of oozes, Dorbo reacted with alarm, calling it catastrophic. He objected to plans involving the Gold Whisker wererats (whom he considered squatters) and doubted gnome soldiers could fight oozes. Daz forcefully demanded his cooperation, and after a stunned silence, Dorbo agreed to the party's terms.
3. **Battle Plan Address:** Stood before assembled forces and declared the day of victory against the Pudding King. He publicly pointed to Daz as the one who would lead them to triumph. Unveiled a two-pronged battle plan — the party infiltrating via a southern wall breach while his forces diversified as a diversion. Offered three allied groups: an elemental imbued with Entemoch's power, wererats led by Chipgrin, and the Pickshine Miners. Accepted the party's proposal for a minimal distraction over a full-scale assault.
4. **Trader's Grotto Argument:** Caught arguing with Chipgrin over dividing newly opened territory while oozes threatened defenses. Thorin tried to redirect them but was initially ignored.
5. **Post-Battle Council:** Pushed for aggressive economic recovery and mithral extraction. The party brokered several compromises on his behalf: a wage agreement between the miners guild and working class, a wererat defense force arrangement (removing his need to fund military protection), and sustainable mining practices respecting the ghosts' sacred grounds. Dorbo agreed to the peace arrangement and announced plans to reopen Blingdenstone for trade with the surface world.
6. **Honorary Gesture to Thorin:** Moved by Thorin's physical effort winching a support beam into place, Dorbo personally sewed a Diggermattock Miners patch onto Thorin's gear, declaring him an honorary member of the mining crew.

## Current Status
- **Location:** Blingdenstone, likely at Diggermattock Hall
- **Active Plans:** Reopening Blingdenstone for trade with the surface world; overseeing economic recovery and mithral extraction under the compromises brokered by the party
- **Known vs. Hidden:** The party understands his profit-driven motivations clearly. No hidden agenda indicated beyond his known economic priorities.

## Relationships
- **Senni (Quartermaster, wife):** Frequent collaborator and foil. They argue openly — she checks his worst impulses and prioritizes the common people where he prioritizes wealth. She silenced him during the planning session when he dismissed Grygum's plan.
- **Chipgrin / Gold Whisker Wererats:** Hostile — considers them squatters. Argued with Chipgrin over territorial claims. Eventually accepted a wererat defense arrangement brokered by the party.
- **Daz (Party Member):** Respects or at least defers to Daz's forcefulness. Publicly credited Daz as the leader who would bring victory against the Pudding King.
- **Thorin (Party Member):** Genuinely moved by Thorin's efforts; awarded him an honorary Diggermattock Miners patch — a personal and rare gesture of respect.
- **Blingdenstone Citizens:** Some accuse him of caring only for wealth and neglecting common people.

## Arc Score Events
- **Daz demanding cooperation** — shifted Dorbo from obstruction to compliance (likely positive arc progression for the party's standing in Blingdenstone).
- **Party brokering council compromises** — Dorbo agreed to peace arrangement and trade reopening (positive arc resolution for Blingdenstone's future).
- **Thorin's support beam effort** — earned the honorary mining crew patch (positive personal relationship milestone with Thorin).
