---
name: Kaelira (Duskryn)
aliases: []
---

# Kaelira (Duskryn)

## Identity
- Member of House Duskryn; one of the Duskryn sisters
- Sent specifically to extract Daz from a dangerous situation
- First encountered during a battle involving an insect swarm and poisonous gas

## Personality & Motivations
- Core goal: Ensure Daz's survival, seemingly under orders from House Duskryn.
- Direct, physical, and no-nonsense in approach. She grabbed Daz bodily and hauled him to safety without waiting for his agreement. Her quip — "Come with me if you want to live, you idiot" — suggests a blunt, impatient personality with little tolerance for hesitation.

## History with the Party
- **Extraction Battle:** Appeared mid-combat alongside her sister Nym. Physically seized Daz's arm and dragged him northeast through an insect swarm and poisonous gas to where Nym was waiting. Daz did not consent to the extraction; she enforced his survival regardless.
- **Accusation by Asha Vandree:** Asha Vandree identified Kaelira as a potential traitor to Lolth. Daz intervened and defused the situation by claiming both Kaelira and Nym were Lolth-aligned allies.

## Current Status
- **Last known location:** Northeast of the battlefield, with Nym, after successfully extracting Daz.
- **Active plans:** Unknown beyond the completed extraction mission.
- **Party knowledge vs. hidden:** The party knows she is a Duskryn operative sent for Daz. Asha Vandree's accusation of treachery against Lolth remains unresolved — the party does not know whether the accusation has merit or was baseless. Daz publicly vouched for her loyalty to Lolth, but whether that claim is true is unclear.

## Relationships
- **Nym (Duskryn):** Sister and mission partner. Nym waited at the extraction point while Kaelira did the physical retrieval.
- **Daz (Party):** Extraction target. She treated him with rough familiarity. He protected her reputation by lying (or telling the truth) to Asha Vandree on her behalf.
- **Asha Vandree:** Adversarial. Asha publicly accused Kaelira of being a traitor to Lolth, creating a tension point that Daz only superficially resolved.
- **House Duskryn:** Operates on behalf of the house; extraction mission implies she answers to Duskryn leadership.

## Arc Score Events
- Asha Vandree's accusation of Lolth-treachery against Kaelira is a potential arc-relevant flag — direction unclear pending future developments.
