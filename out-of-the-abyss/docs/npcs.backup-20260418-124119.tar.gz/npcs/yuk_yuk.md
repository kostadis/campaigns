---
name: Yuk-Yuk
aliases: []
---

# Yuk-Yuk

## Identity
- Goblin hireling / companion
- First joined the party after being convinced by Jimjar to follow the group into the dangerous tunnels, along with fellow goblin Spiderbait, in exchange for 20 gold

## Personality & Motivations
- Motivated by coin — agreed to venture into dangerous territory for 20 gold. Little else is known of his personality, as his time with the party was cut short.

## History with the Party
- **Hired:** Jimjar convinced Yuk-Yuk and Spiderbait to join the group for 20 gold before entering the Silken Tunnels.
- **Traveled** with the party through the Silken Tunnels and into the Underdark.
- **Murdered:** On the 1st day of the 3rd Tenday of Taraskh 1493, Yuk-Yuk was found dead — throat cut with a shortsword while the group slept. Spiderbait discovered the body and was screaming. Grygum observed that any member of the group could have been the killer.

## Current Status
- **Dead.** Murdered in his sleep.
- The killer has not been identified. Grygum noted that anyone in the group could be responsible.
- The murder weapon was a shortsword — this detail may help narrow suspects if the party investigates.

## Relationships
- **Spiderbait:** Fellow goblin companion; discovered Yuk-Yuk's body and was visibly distraught (screaming).
- **Jimjar:** The one who recruited Yuk-Yuk and Spiderbait into the group.
- **Grygum:** Commented on the murder, noting any group member could be guilty.

## Arc Score Events
None noted.
