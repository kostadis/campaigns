---
name: Rihaud
aliases: []
---

# Rihaud

## Identity
- Stone giant, former apprentice to Stonespeaker Hgraam
- Faction affiliation: Stone giants of the Underdark (associated with Stonespeaker Hgraam's community)
- First appeared alongside Dorhun, flanked by Duergar Stone Guards, arriving after the party's battle with a crazed two-headed giant

## Personality & Motivations
- No direct speech or actions recorded beyond his arrival. Motivations and personality remain unobserved.

## History with the Party
- Appeared with Dorhun and Duergar Stone Guards in the aftermath of the party's fight against a crazed two-headed giant. Dorhun introduced him. No further interaction documented.

## Current Status
- Last seen at the site of the two-headed giant battle, alongside Dorhun and Duergar Stone Guards
- No known active plans or operations
- The party knows only his name, his race, and that he was formerly apprenticed to Stonespeaker Hgraam

## Relationships
- **Stonespeaker Hgraam**: Former master; Rihaud served as his apprentice
- **Dorhun**: Associate; the two arrived together and Dorhun made the introduction
- **Duergar Stone Guards**: Accompanied Rihaud and Dorhun as escorts or allies
- **The Party**: Minimal interaction; introduced but no substantive engagement recorded

## Arc Score Events
None recorded.
