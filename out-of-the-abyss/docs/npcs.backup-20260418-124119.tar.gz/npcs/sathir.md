---
name: Sathir
aliases: []
---

# Sathir

## Identity
- No specific role, title, or faction affiliation noted
- A member or associate of the party group

## Personality & Motivations
- Appears pragmatic and forward-looking, immediately turning attention to next steps after the group fled Sloopbludop. Limited information available to assess deeper motivations or personality traits.

## History with the Party
- Present with the group when they fled Sloopbludop. Participated in the post-escape discussion about where to go next.

## Current Status
- **Last known location:** With the party, having just fled Sloopbludop
- **Active plans:** None specified; was seeking group consensus on their next destination
- **Known vs. hidden:** Very little is documented about Sathir beyond this single interaction

## Relationships
- Travels with the party group; no specific individual relationships noted

## Arc Score Events
- None recorded
