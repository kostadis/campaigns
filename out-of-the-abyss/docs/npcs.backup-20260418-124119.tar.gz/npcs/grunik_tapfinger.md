---
name: Grunik Tapfinger
aliases: []
---

# Grunik Tapfinger

## Identity
- Cleric, associated with Diggermattock Hall
- First encountered as the quest-giver who sent the party to hallow Ogremoch's temple

## Personality & Motivations
- Supportive of the party's efforts and generous in rewarding their success. Greeted them warmly upon their return, suggesting a genuine appreciation for their work rather than a purely transactional relationship.

## History with the Party
1. **Quest Assignment:** Tasked the party with hallowing Ogremoch's temple.
2. **Quest Completion & Reward:** Welcomed the party back to Diggermattock Hall upon their successful return. Presented them with an empty fourth-level spell gem as a reward. The party chose to imbue it with a healing spell for emergencies.

## Current Status
- **Last known location:** Diggermattock Hall
- **Activity:** Presumably continuing his duties as a cleric at the Hall; no further active plans noted.
- **Party knowledge:** The party knows him as a reliable quest-giver and ally who rewards good work.

## Relationships
- **The Party:** Positive relationship; trusted them with the important task of hallowing Ogremoch's temple and rewarded them generously upon completion.
- **Diggermattock Hall:** Appears to hold a position of some authority or respect, given his ability to commission quests and distribute valuable magical items.
