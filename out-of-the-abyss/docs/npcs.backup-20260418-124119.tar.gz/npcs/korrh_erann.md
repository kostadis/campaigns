---
name: Korrh Erann
aliases: []
---

# Korrh Erann

## Identity
- Monk of Zalthir's monastic order (historical figure)
- Referenced in Zalthir's retelling of monastic lore; never encountered directly by the party

## Personality & Motivations
- Pragmatic survivalist who valued caution over confrontation. When trapped in the Underdark with drow in pursuit, he insisted that fighting the scouts was a dangerous gamble and chose to flee instead. He was the only member of his group to survive.

## History with the Party
- **No direct interaction.** Korrh Erann's story was invoked by Zalthir as a parable to justify his own decision to flee from pursuing drow scouts rather than stand and fight. The tale served as moral precedent drawn from their shared monastic tradition.

## Current Status
- Historical figure; presumably deceased. Exists only as a story within the monastic order's teachings.

## Relationships
- **Zalthir:** Fellow monk of the same order (separated by time). Zalthir knows Korrh's story well enough to cite it in a moment of crisis, suggesting it holds significant weight in the order's oral tradition.
