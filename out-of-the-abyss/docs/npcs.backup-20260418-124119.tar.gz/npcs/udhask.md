---
name: Udhask
aliases: []
---

# Udhask

## Identity
- Deep gnome ghost; one of the spirits Burrow Warden Jadger tasked the party with recovering
- First encountered as a fleeing ghost that led the party to his burial site in a burrow

## Personality & Motivations
- Unknown in life. As a spirit, he fled from the party rather than engaging, suggesting a timid or avoidant nature even in death.

## History with the Party
- The party pursued a ghost that fled into a burrow area, leading them to Udhask's skeletal remains on a stone bed.
- They discovered a hidden compartment beneath the bed containing six gems (worth 600 gp each) and a potion of invisibility.
- His bones showed no signs of violent death — his end appeared peaceful or natural.
- The party collected his bones to fulfill Burrow Warden Jadger's quest.

## Current Status
- **Deceased.** Bones recovered by the party for return to Jadger.
- Quest objective fulfilled regarding his remains.

## Relationships
- **Burrow Warden Jadger:** One of the spirits Jadger specifically asked the party to rescue/recover.
- **The Party:** No direct interaction beyond the chase; served as a quest objective.

## Arc Score Events
None noted.
