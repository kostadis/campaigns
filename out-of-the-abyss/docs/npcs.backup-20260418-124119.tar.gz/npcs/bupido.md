---
name: Bupido
aliases: []
---

# Bupido

## Identity
- Derro prisoner, fellow captive during the party's imprisonment
- First appeared during the prison escape, where he helped lead the other prisoners

## Personality & Motivations
- Initially presented as a cooperative ally during the escape. His true nature was far darker — he secretly worshipped a demonic power and maintained a hidden lair with an altar and collected bones. He ultimately betrayed the party, killing one of their group members.

## History with the Party
1. **Prison Escape:** Bupido led the other prisoners in rushing the guard chamber during the distraction created by Thorin, Zalthir, and Daz's confrontation with the guards. He participated in the scramble into the armory and fired a crossbow at the guard Imbros (missed).
2. **Betrayal (off-screen in notes):** At some point after the escape, Bupido betrayed the party and killed one of their group members. The details of this event are not captured in the provided notes.
3. **Death (off-screen in notes):** Bupido was killed at some point, as he is later referenced posthumously.

## Current Status
- **Dead.**
- His former lair — a grim space filled with dead bones and an altar to a demonic power — was later used by the party as a resting place before their assault on a cultist cavern.
- His betrayal remains a lasting scar on the party's trust; Daz explicitly cites Bupido as the reason they tie up unfamiliar companions at night.

## Relationships
- **The Party (general):** Deep distrust stemming from his betrayal. His name is invoked as a cautionary tale.
- **Daz:** Particularly vocal about the lesson learned from Bupido — uses the betrayal to justify caution with new allies (e.g., the Pelek/Derro ghost).
- **Pelek/Derro ghost:** No direct relationship, but Bupido's legacy directly affects how the party treats this entity.

## Arc Score Events
- No explicit arc score changes noted in the source material.
