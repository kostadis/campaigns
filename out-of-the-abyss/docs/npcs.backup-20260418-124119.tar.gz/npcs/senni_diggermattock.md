---
name: Senni Diggermattock
aliases: []
---

# Senni Diggermattock

## Identity
- Quartermaster of Clan Diggermattock; assistant to Chief Dorbo Diggermattock
- Member of the Gold Whisker clan and Dorbo's wife
- Leader aligned with Blingdenstone's labor groups (not the business faction)
- First appeared at Diggermattock Hall, seated alongside Dorbo on the raised dais when the party arrived in Blingdenstone

## Personality & Motivations
- Deeply people-focused; her primary concern is the safety of Blingdenstone's civilians and the community they've built. This stands in deliberate contrast to Dorbo's profit-driven motivations. She is pragmatic and politically savvy, willing to build alliances across faction lines—including with the wererats—if it serves the common good. She is assertive enough to silence Dorbo publicly when she thinks he's being shortsighted.

## History with the Party
1. **First Meeting:** Addressed the party from the dais after arguing with Dorbo, confirming the ooze problem and framing the party's assistance as a condition for receiving help reaching the Overbright—presenting their conscription as a "gracious volunteering."
2. **Strategic Advocacy:** When Dorbo dismissed the party's plan to deal with the oozes, Senni overruled him and proposed a full clan meeting including the Stoneheart Enclave and Miners Guild. She advocated for working with the Gold Whisker clan and tasked the party with bringing the wererats on board.
3. **Council Meeting on Gold Whiskers:** Supported a functional alliance between gnomes and the Gold Whisker wererats, helping Dorbo reach the peace arrangement.
4. **Earth Elemental Debate:** Sided firmly with the party's arguments against using Earth Elementals for mining labor. Seized control of the meeting by shouting "Gnome Labor, not Summoned Labor!" The outcome restricted elementals to defense/warfare only, disrupting Blingdenstone's economic plans.
5. **Ooze Assault Planning:** Expressed concern about civilian safety if the party's assault on the oozes failed. Was pleased when the party proposed a minimal distraction plan rather than a full-scale assault.

## Current Status
- **Location:** Blingdenstone, serving in her leadership role
- **Active concerns:** Civilian safety during the ooze offensive; managing the fallout of the elemental labor ban on city rebuilding
- **Known vs. hidden:** The party has a clear read on Senni—she has been consistently transparent about her priorities and motivations

## Relationships
- **Chief Dorbo Diggermattock:** Her husband. She serves as his assistant but frequently overrules or redirects him. He is profit-driven; she is people-driven. Their dynamic involves open, heated disagreement in public.
- **Gold Whisker Clan:** She is a member and advocated for their inclusion in Blingdenstone's alliance, bridging the gap between the gnome factions and the wererats.
- **Stoneheart Enclave / Miners Guild:** Called for their inclusion in strategic planning; aligned with labor groups over business interests.
- **The Party:** Pragmatic ally. Initially leveraged their need for passage to conscript them, but has since consistently supported their proposals and used their arguments to advance her own political goals.

## Arc Score Events
- **Earth Elemental Debate (Increase):** Senni sided with the party, and their combined effort shifted Blingdenstone policy—elementals banned from labor, restricted to defense. This fundamentally disrupted the city's economic plans, a significant political shift driven by the party's influence.
