---
name: Aliza Argot
aliases: []
---

# Aliza Argot

## Identity
- A woman found by the party in caves (likely during their Underdark travels)
- First encountered in caves prior to the events at Neverlight Grove

## Personality & Motivations
- No personality traits or motivations have been demonstrated in the notes so far. She has been a quiet, background presence among the party's group.

## History with the Party
- **Found in the caves:** The party discovered Aliza in a cave system at some unspecified earlier point.
- **Neverlight Grove:** She traveled with the party to Neverlight Grove, though she took no notable actions during those events.

## Current Status
- Last known to be traveling with the party as of the Neverlight Grove visit.
- No active plans or operations noted.
- Very little is known about her background or intentions.

## Relationships
- Travels with the party as part of their broader group of companions/rescued NPCs.
- No specific relationships with individual party members or other NPCs noted.

## Arc Score Events
None recorded.
