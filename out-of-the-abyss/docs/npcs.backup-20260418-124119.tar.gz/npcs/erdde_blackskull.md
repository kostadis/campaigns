---
name: Erdde Blackskull
aliases: []
---

# Erdde Blackskull

## Identity
- Captain of the Stone Guards
- Duergar authority figure in the city
- First encountered through her professional relationship with Grygum; met the party in the context of issuing gate passes

## Personality & Motivations
- Projects an aura of paranoia and suspicion. Attempts to maintain a veneer of nonchalance and authority, but personal stakes betray her composure — two of the victims of the "empty scabbard killers" were her own clan members, including her uncle. She is deeply rationalist, refusing to accept supernatural explanations and insisting the killings must be the work of a government agency using legend as cover. She is guarded with information and only shares when pressed to the point of necessity.

## History with the Party
- **Gate Passes:** Provided the party with passes allowing them through gates that restrict non-Duergar access to the city.
- **Veiled Threat:** Has threatened that she could set the Drow on the party, establishing a power dynamic.
- **Meeting with Grygum:** Tasked Grygum with investigating the "empty scabbard killers" — mysterious assassins whose victims are found with puzzling wounds. Her underlings reported the bodies. She was initially reluctant to share details but relented when Grygum argued he couldn't investigate blind, at which point she brought in her subordinate **Grimholl Forgebrand** to brief him further.
- **Droki:** She is actively searching for someone named **Droki**, who has separately been identified by the **Keepers of the Flame** as a **Gray Ghosts** agent.

## Current Status
- **Location:** Presumably operating from her Stone Guard post in the city.
- **Active Operations:** (1) Hunting the "empty scabbard killers" via Grygum; (2) Searching for Droki.
- **Known vs. Hidden:** The party knows she issued their passes, that she's investigating the killers, and that she wants Droki found. Her personal connection to the victims (clan members, uncle) was revealed to Grygum. She dismisses the empty scabbard killers as myth — it is unclear whether this is genuine disbelief or deliberate misdirection.

## Relationships
- **Grygum:** Professional relationship; she delegates sensitive investigative work to him. Appeared disappointed during their meeting.
- **Grimholl Forgebrand:** Her subordinate in the Stone Guards; brought in to share details about the killings.
- **The Party:** Transactional and wary. She holds leverage (gate passes, Drow threat) and views them as useful but expendable.
- **Keepers of the Flame:** No direct relationship noted, but both she and the Keepers are independently interested in Droki.
- **Gray Ghosts:** Droki is linked to the Gray Ghosts; her pursuit of him may put her in conflict with this faction.
- **Her Clan:** Personally affected — her uncle and another clan member were among the victims.

## Arc Score Events
No explicit arc score changes noted in the source material.
