---
name: Gorg'Bahamut (Grog'Bahamut)
aliases: []
---

# Gorg'Bahamut

## Identity
- Mentor to Grygum; appears to be a follower or devotee of Bahamut
- Has not appeared in person; known only through Grygum's memories

## Personality & Motivations
- A teacher and keeper of draconic lore, particularly regarding cosmic threats to Bahamut's order. Values the accumulation of hoards as sacred practice, viewing them as blessings from Bahamut. Demonstrates a detailed, dramatic storytelling style when conveying knowledge about dangerous entities.

## History with the Party
- **Referenced only:** Grygum recalled Gorg'Bahamut's teachings during play. He taught Grygum extensively about Demogorgon — the Prince of Demons — describing his two heads (one whispering lies, the other roaring with fury), tentacles dripping with chaos venom, and his nature as the antithesis of Bahamut. He also instilled the belief that "a hoard is always a valuable thing and a blessing from Bahamut."

## Current Status
- **Last known status:** Unknown; has not appeared in person
- **What the party knows:** Only what Grygum has shared from memory — his teachings on Demogorgon and hoards
- **What remains hidden:** His current whereabouts, whether he is alive, and the full extent of his relationship with Grygum

## Relationships
- **Grygum:** Student/mentee; Gorg'Bahamut shaped Grygum's worldview regarding Bahamut, hoards, and demonic threats
- **Bahamut (deity):** Apparent devotee; frames teachings through a Bahamut-centric lens
