---
name: Suushar the Awakened
aliases: []
---

# Suushar the Awakened

## Identity
- Kuo-Toan prisoner held in the slave pen at the Drow outpost
- Serves as translator and cultural guide for party members who don't speak Undercommon
- First encountered as a fellow prisoner; introduced himself to Gyrgum in the slave pen

## Personality & Motivations
- Core goal: Return to his people at Darklake and "share the enlightenment" with them
- Claims a spiritual practice centered on finding balance and coping with "the madness of my race." Professes to omit offensive words when translating as part of this practice — but then translates every insult anyway, undermining the sincerity of the claim. Enthusiastic and socially eager, quick to flatter (told Gyrgum his cooking might make the Kuo-Toa "imagine a god like you"). Generally reassuring and calm under stressful circumstances.

## History with the Party
- **Slave pen interactions:** Reassured Gyrgum when Ront and Prince Derendil were taken away for chores, explaining these were routine daily tasks. Identified each Drow taskmaster by name and assignment (Beremil — water, Balok — winch, Guldor — chamber pots, Imbros — cooking).
- **Kitchen duty:** Acted as translator between the party and Drow during cooking chores. Relayed Topsy and Turvy's request for Gyrgum to create a distraction so they could steal food. Lavishly praised Gyrgum's cooking.
- **Escape planning:** Advocated strongly for traveling to Darklake first, arguing the direct route to Blingdenstone passes through Menzoberranzan. Insisted the group must visit his people.

## Current Status
- **Location:** Slave pen at the Drow outpost
- **Active plans:** Pushing for the escape route to go through Darklake so he can return to his Kuo-Toan settlement
- **Known vs. hidden:** The party knows his translation habits, his knowledge of the Drow guards, and his desire to reach Darklake. His true spiritual beliefs and what "sharing the enlightenment" actually entails remain unclear.

## Relationships
- **Gyrgum:** Primary relationship; acts as his translator and cultural interpreter. Flatters him enthusiastically, especially regarding his cooking.
- **Topsy & Turvy:** Cooperative; willing to relay their schemes (food theft) to the party.
- **Ront & Prince Derendil:** Aware of their situation; reassured Gyrgum about their safety during chores.
- **Drow taskmasters (Beremil, Balok, Guldor, Imbros):** Knows them by name and routine — suggests he has been a prisoner long enough to learn the outpost's daily operations.
