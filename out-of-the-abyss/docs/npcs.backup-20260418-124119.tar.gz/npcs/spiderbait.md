---
name: Spiderbait
aliases: []
---

# Spiderbait

## Identity
- Goblin guide of the Silken Paths, paired with his partner Yukyuk
- Color motif: pink; tattoo-covered, casual attire; speaks with rolled R's and oddly clipped vowels
- First met the party at the Silken Paths, where he and Yukyuk agreed to serve as guides in exchange for 20 gold (a debt owed by Jimjar)

## Personality & Motivations
- Core goal: getting paid the 20 gold Jimjar owes; secondary drive is survival and loyalty to his companions
- Confident and boastful about his skills — bragged about taking a harder route through the webs ("I went around the spider and through its legs"). Enthusiastic and positive when things go well, volatile and emotional when they don't. Quick to assign blame (accused Shuushar of Yukyuk's murder). Has strong opinions about fighting fair, criticizing the use of magic as "kind of a cheat." Deeply loyal to Yukyuk and devastated by his death.

## History with the Party
1. **Silken Paths** — Hired as a guide after devising the solution to Jimjar's unpaid bet: he and Yukyuk would stay with the group until the debt was settled. Enthusiastically high-fived Yukyuk. Took mental notes on Eldeth's rope-tying safety innovation. Warned the group about the lethal danger of burning webs.
2. **Spider Fight** — Critiqued the party's use of magic, advocating for skill-based solutions. Explained the Drow pursuit would depend on guide quality and that he and Yukyuk knew the best routes.
3. **Yukyuk's Murder (1st day, 3rd Tenday of Taraskh 1493)** — Discovered Yukyuk's body and screamed, waking the group. Raged at Jimjar demanding money and threatening to leave. Calmed down by Jimjar. When questioned by Daz, described Yukyuk as "the kindest, gentlest goblin you could imagine." Accused Shuushar of being the killer, claiming Kuo-toans go mad and kill people. Was tempted to leave but stayed, reportedly impressed by Zalthir.
4. **Kuo-toa Civil War** — Fled with the other escapees toward Grygum.
5. **Keelboat Ambush** — Captured by duergar; a duergar dragged him away, but Zalthir killed the creature holding him. Afterward, was "seething with rage" and wanted to kill Buppido on the spot.
6. **Gracklstugh / Underlake Hold** — Armed by Errde alongside Jimjar, Sarith, and Eldeth. Ordered to wait outside the assassin's chambers by Rust. Traveled with the group past the Derro caves. Skiit (a derro?) specifically pointed at Spiderbait and asked "Can I kill that one over there?"
7. **Blingdenstone** — Volunteered alongside Glabbagool, Eldeth, and Jimjar to tackle the ghost problem.

## Current Status
- **Location:** Blingdenstone, volunteering for the ghost problem
- **Emotional state:** Still grieving Yukyuk; carries deep anger (wanted to kill Buppido). Functionally loyal to the group but volatile.
- **Open thread:** Jimjar's 20-gold debt remains a simmering issue.

## Relationships
- **Yukyuk** — Best friend and partner. Devastated by his murder; described him in glowing terms.
- **Jimjar** — Creditor-debtor relationship. Source of ongoing tension over the unpaid 20 gold, but Jimjar has managed to calm him down in moments of crisis.
- **Zalthir** — Impressed by Zalthir; this admiration kept him from leaving the group. Zalthir also directly saved his life during the keelboat ambush.
- **Shuushar** — Accused him of murdering Yukyuk. Deeply distrustful.
- **Buppido** — Wanted to kill him. Seething hostility.
- **Eldeth** — Cooperative; Spiderbait was intrigued by her rope-tying innovation. Both volunteered for the Blingdenstone ghost mission.
- **Daz** — Questioned by Daz about the murder; cooperated with the investigation.
- **Skiit** — Skiit singled him out as a target ("Can I kill that one over there?").

## Arc Score Events
- **Yukyuk's murder** — Major emotional blow; triggered rage and near-departure (relationship with group strained, decrease).
- **Zalthir saving him from the duergar** — Reinforced loyalty to the group, particularly Zalthir (increase).
- **Being impressed by Zalthir earlier** — Kept him from leaving after payment disputes (increase).
