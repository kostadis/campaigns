---
name: Jorlan Duskryn
aliases: []
---

# Jorlan Duskryn

## Identity
- Scarred drow warrior; brother of Nym Duskryn
- Former lover of Ilvara, discarded after receiving facial scarring (drow society rewards beauty, punishes everything else)
- First encountered fighting alongside or near the party during the battle in the fungal cavern

## Personality & Motivations
- Driven by a deeply personal grudge against Ilvara that overrides tactical thinking. When she appeared wounded, he abandoned his position and charged across swarm-infested terrain screaming her name — described not as rage but as "a wound reopening, something uglier and more honest." His vendetta is romantic betrayal dressed in the chaos of battle.

## History with the Party
- **Fungal Cavern Battle:** Fought near the party during the engagement. When Ilvara appeared wounded, he broke position and charged her directly. Thorin had an opportunity attack on him (rolled an 8) but chose to let him pass, reasoning Jorlan was functionally useful going after Ilvara. Zalthir assessed the situation as "the tides have turned."
- Jorlan and Ilvara traded blows on the cavern floor after both survived the bridge collapse.
- Was struck by a lightning bolt from his own sister, Nym Duskryn, and left staggering.

## Current Status
- **Last known:** Staggering on the fungal cavern floor after being hit by Nym's lightning bolt. Final fate after the battle is **not explicitly stated** — status unknown.
- Not a formal ally of the party; acted as a co-belligerent against Ilvara out of personal vendetta.

## Relationships
- **Ilvara:** Former lover. She discarded him after his scarring. His hatred for her is visceral and personal, not strategic.
- **Nym Duskryn:** Sister. She hit him with a lightning bolt during the battle, described as channeling professional frustrations — suggesting a strained or hostile sibling relationship.
- **Thorin:** No formal relationship; Thorin pragmatically allowed him to pass during the fight.
- **Zalthir:** Observed and commented on Jorlan's charge; no direct interaction noted.

## Arc Score Events
- None explicitly noted.
