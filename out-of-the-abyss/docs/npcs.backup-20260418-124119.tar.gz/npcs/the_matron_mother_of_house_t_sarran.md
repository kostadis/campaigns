---
name: The Matron Mother of House T'sarran
aliases: []
---

# The Matron Mother of House T'sarran

## Identity
- Matron Mother of House T'sarran, a drow noble house with significant military resources
- Has not appeared directly; known only through the warnings and threats of her subordinates
- First referenced during the battle at Velkynvelve, when T'sarran forces were defeated by the party

## Personality & Motivations
- Core goals and drives are unknown, but House T'sarran had a vested interest in the outcome of the Velkynvelve fight — their forces were sent there under contract, expecting an easy kill
- The calm, unhurried nature of her subordinates' threats suggests a house culture of confidence and long-term thinking rather than rash retaliation

## History with the Party
- House T'sarran dispatched five drow warriors and a mage to Velkynvelve, apparently under contract. The party destroyed most of this force, largely through Daz's Fireball and combined efforts.
- The T'sarran mage warned before dying that the matron mother would hear about the defeat. The last surviving warrior withdrew calmly, delivering the same promise: "We will meet again. Enjoy your victory for the moment."
- Grygum noted the credibility of the threat — delivered without heat — and resolved to learn who the matron mother is before she learns who the party is.

## Current Status
- **Last known location:** Unknown; she has not appeared in person
- **Active plans:** Presumably will receive a report from the surviving warrior about the party's destruction of her forces
- **What the party knows:** Her title, her house name, and that she commands enough resources to field a mage and five warriors on a contract job. They do not know her personal name, location, or broader agenda.
- **What remains hidden:** Her identity, the nature of the contract that brought T'sarran forces to Velkynvelve, and what retaliatory action she may take.

## Relationships
- **The Party:** Unaware of them specifically (for now), but will likely learn of them through the surviving warrior's report. The party destroyed most of her deployed forces.
- **Grygum:** Views her as a priority intelligence target — wants to identify her before she identifies the party.
- **House T'sarran forces:** Commands their loyalty; subordinates reference her authority with respect and certainty rather than fear.
- **Unknown contractor:** Someone hired House T'sarran for the Velkynvelve operation, suggesting external alliances or mercenary dealings.
