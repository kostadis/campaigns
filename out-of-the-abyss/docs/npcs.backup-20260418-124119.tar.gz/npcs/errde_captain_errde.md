---
name: Errde (Captain Errde)
aliases: []
---

# Captain Errde

## Identity
- Captain in Gracklstugh, likely commanding the Stone Guard or affiliated military/intelligence force
- Connected to the Ember Vanguard faction
- Not met directly by the party; referenced by a Stone Guard stationed at the docks

## Personality & Motivations
- Operates as an intelligence coordinator in Gracklstugh, receiving reports and relaying information to relevant parties. Her willingness to pass information about the party to the Drow suggests she prioritizes political alliances or obligations over any sympathy toward surface-dwellers or fugitives.

## History with the Party
- **Gracklstugh docks encounter:** A lone Stone Guard recognized the party from an Ember Vanguard poster and stated he needed to warn "Captain Errde" immediately. The party did not interact with Errde directly.
- **Aftermath:** It is believed Errde subsequently informed the Drow that the party passed through Gracklstugh, re-igniting Drow pursuit.

## Current Status
- **Last known location:** Gracklstugh
- **Active operations:** Coordinating intelligence; has likely already alerted the Drow to the party's movements
- **Party knowledge:** The party knows her name and that she was warned of their presence. They likely suspect (or know) she tipped off the Drow. They have not met her face-to-face.
- **Hidden:** Her exact rank, full authority, and the nature of her relationship with the Drow remain unknown to the party.

## Relationships
- **Stone Guard:** Commands their loyalty; at least one guard at the docks reports directly to her.
- **Ember Vanguard:** Connected — the wanted poster that identified the party was from this faction.
- **The Drow:** Maintains a communication channel with Drow forces; passed along intelligence about the party's passage through Gracklstugh.
- **The Party:** Adversarial by implication — her actions have put the Drow back on the party's trail.

## Arc Score Events
- Errde alerting the Drow to the party's presence in Gracklstugh represents an escalation of external pursuit pressure (increase in Drow pursuit/threat arc).
