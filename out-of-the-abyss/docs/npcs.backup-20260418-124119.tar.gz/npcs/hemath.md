---
name: Hemath
aliases: []
---

# Hemath

## Identity
- Duergar arms dealer
- First encountered as a sacrificial captive bound at the kuo-toa altar

## Personality & Motivations
- Core drive: survival above all else
- Pragmatic and transactional — his instinct is to offer future value (find him in Gracklstugh) in exchange for present rescue. Carries the innate cultural cynicism of the duergar, but desperation overrides it. Willing to cooperate and take direction when his life is on the line.

## History with the Party
- **Kuo-toa Altar Encounter:** Found bloodied and bound among sacrificial captives. He had been dealing weapons to the Archpriest of the Deep Father (Bloppblippodd), who betrayed him — declaring his sacrifice would be "weapon enough." He pleaded with Grygum for help. Grygum told him cryptically, "there's more than meets the eye," which surprised and comforted him. He agreed to act on the party's signal and asked them to find him in Gracklstugh if they survived. A battle then broke out.

## Current Status
- **Last known location:** Among the captives at the kuo-toa altar when fighting began
- **Fate unknown** — it is unclear whether he escaped, was killed, or was recaptured during the battle
- **Standing offer:** Told the party to seek him out in Gracklstugh, implying he has resources or connections there (likely arms dealing operations)

## Relationships
- **Grygum:** Pleaded directly with Grygum for rescue; received cryptic reassurance. Appears to trust Grygum as a result.
- **Bloppblippodd (Archpriest of the Deep Father):** Former business partner turned betrayer. She reneged on their weapons deal and marked him for sacrifice. Likely harbors significant resentment.
- **Gracklstugh:** Has a presence or base of operations there — potential contact point for the party in duergar territory.

## Arc Score Events
None recorded.
