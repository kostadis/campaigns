---
name: Sarith
aliases: []
---

# Sarith

## Identity
- Drow warrior, former member of Lolth's guard (warrior caste)
- Prisoner at Velkynvelve, convicted of murdering a fellow Drow
- First encountered by the party as a fellow prisoner in the slave pen at Velkynvelve

## Personality & Motivations
- Sarith was deeply unstable from the start — Daz assessed him as "not sane." He oscillated between lucid tactical advice and bouts of cackling, muttering, and raving. He insisted his murder conviction was a setup yet simultaneously questioned whether he actually committed the crime. His core drives were escaping Velkynvelve (terrified of being sent to Menzoberranzan to be sacrificed or turned into a drider), and increasingly, answering the compulsive call of Zuggtmoy's spores. He took pride in his drow warrior training and eagerly offered his torture expertise, revealing a casual cruelty beneath his cooperative exterior.

## History with the Party
- **Velkynvelve:** Met as a fellow prisoner; Grygum determined he was a genuine prisoner, not a spy. Assigned to chamber pot duty with Daz and Stool. Provided intelligence about the gray ooze in the pools and Jorlan's backstory (disfigurement, fall from Ilvara's favor, Shoor's rise). Participated in escape planning.
- **Escape from Velkynvelve:** Armed himself with studded leather armor, shield, and hand crossbow. Identified a vial of Drow poison. Advised the group to move quickly, warning Ilvara would pursue them. Suggested the route to the Darklake via Sloobludop (eight days away).
- **Silken Paths:** Confirmed the route and described the massive chasm crossing. Directed the goblin guides toward Sloobludop.
- **Buppido's Interrogation:** Complimented Daz's Mind Sliver technique as "excellent torturing" and offered to employ more brutal methods from his guard training.
- **Post-Shuushar's Departure:** Admitted he had Shuushar's navigational instructions but was unsure he could follow them, leaving Darklake navigation uncertain.
- **Darklake Journey:** Traveled with the party by boat; shouted warnings about a sandbar; provided moments of dark humor.
- **Duergar Interrogation:** Claimed expertise from Lolth's guard training but recommended Daz take first crack at the prisoner.
- **Gracklstugh:** Armed by Errde at Underlake Hold. Followed party through the city; waited outside the assassin's lair and the final brimstone cavern as ordered.
- **Approach to Myconid Cave:** Became compelled, walking involuntarily toward the myconids. Shouted about "the Dark Lady" calling him, raving about "the bloom," "the becoming," liberation, revenge, and transformation. Zalthir physically restrained him. His compulsion intensified with proximity.
- **Neverlight Grove:** Entered looking "unhappy and serene." Sovereign Basidia could not recognize his spores — highly unusual. Daz concluded he was infected by Zuggtmoy's demonic spores.
- **Circle of Welcome (Death):** His head exploded during battle and he transformed into a Drow spore servant, turning against the party. Killed by Jimjar.

## Current Status
- **Dead.** Killed by Jimjar after transforming into a Drow spore servant in the Circle of Welcome at Neverlight Grove.
- His fungal infection, present since Velkynvelve, was Zuggtmoy's influence — it drove his madness throughout the journey and ultimately consumed him.

## Relationships
- **Daz:** Worked alongside him on chamber pot duty; respected Daz's interrogation abilities; Daz assessed him as insane and later diagnosed his Zuggtmoy infection.
- **Zalthir:** Physically restrained Sarith during his compulsion episode near the myconid cave.
- **Jimjar:** Fellow armed companion; ultimately Sarith's killer after his transformation.
- **Stool:** Shared chamber pot duty at Velkynvelve.
- **Shuushar:** Received navigational instructions from him before Shuushar departed.
- **Ilvara:** Feared her pursuit; warned the party she would be honor-bound to hunt them.
- **Zuggtmoy ("The Dark Lady"):** Unknowingly (and later consciously) under her influence via fungal spore infection. Called to "the bloom" and "the becoming."
- **Sovereign Basidia:** Basidia could not recognize Sarith's spores, flagging his infection as anomalous.

## Arc Score Events
- No explicit arc score changes noted in source material.
