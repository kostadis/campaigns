---
name: Princess Ebonmire
aliases: []
source_extracts: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54]
---

# Princess Ebonmire

## Identity
- Ooze ally of the Pudding King
- Encountered in the Pudding King's throne room battle

## Personality & Motivations
- Served as a combatant loyal to the Pudding King. No deeper motivations were revealed; she acted as a hostile creature attacking the party on sight, targeting Thorin specifically during the fight.

## History with the Party
- **Throne Room Battle:** Princess Ebonmire fought alongside the Pudding King. She opened by hurling acidic ooze blobs at Thorin but missed. During the mopping-up phase, she charged at Thorin again. She sustained heavy damage from Daz's Fireball (29 damage), Grygum's Inflict Wounds (18 damage), and Zalthir's grapple attacks before Thorin delivered the killing blow.
- **Post-Death Loot:** The party discovered a spellbook containing numerous magical formulas inside her stomach.
- **Ongoing Legacy:** Daz claimed the spellbook and has been studying it, considering its spells as part of his level-up options (notably in conjunction with the Fey Touched feat). He describes it as sitting in his pack "like a promissory note I hadn't finished reading."

## Current Status
- **Deceased.** Killed by Thorin in the Pudding King's throne room.
- Her spellbook remains in Daz's possession and is actively being studied.

## Relationships
- **The Pudding King:** Served as one of his ooze allies in battle.
- **Thorin:** Targeted him repeatedly during the fight; Thorin landed the killing blow.
- **Daz:** Dealt major damage to her with Fireball; now carries and studies her spellbook.
- **Grygum:** Struck her with Inflict Wounds during the battle.
- **Zalthir:** Grappled her during the fight.
