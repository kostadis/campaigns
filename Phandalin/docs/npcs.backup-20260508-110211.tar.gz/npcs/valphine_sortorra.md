---
name: Valphine Sortorra
aliases: []
source_extracts: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40]
---

# Valphine Sortorra

## Identity
- **Role/Title:** Drow cleric of Lathander (Morninglord)
- **Faction:** None current; formerly a denizen of Menzoberranzan
- **First Appearance:** 1/1 Taraksh — encountered Vukardin at the First Flophouse and approached him outside to offer her services

## Personality & Motivations
- **Core Goals:** Serves Lathander, though her understanding of the faith's ethical demands is still developing; drawn to plunder and pragmatic violence by instinct, tempered by conscious self-correction
- Interprets divine doctrine with a drow's natural skepticism — she initially assumed Lathander's prohibition on assassination was a cover story
- Cheerful about violence and near-death; described being knocked unconscious as "glorious," unsettling at least one party member
- Privately judgmental of others' ethics (labeling the gnomes Dazlyn and Norbus as grave robbers) while suppressing her own plunder instincts with visible effort

## History with the Party
- **1/1 Taraksh:** Observed Vukardin at the First Flophouse, felt compelled to follow him, and joined the party by offering her services outside the inn.
- **8/1 Taraksh:** Verified quest payment at the townmaster's hall. Wanted the Gnomengarde quest for plunder potential; deferred to Vukardin's choice of the Dwarven Excavation Quest as a concession to her faith.
- **9/1 Taraksh:** Located two secret doors in the temple. Healed Vukardin twice after he was knocked unconscious by orcs. Was herself knocked unconscious by Soma's misfired ice knife; regained consciousness smiling.
- **10/1 Taraksh:** Provided background on ogres as Menzoberranzan slaves; suggested freeing the roadside ogre. Expressed amusement at party dynamics in Phandalin. Described her near-death to Linene Graywind as "glorious." Listened quietly to Vukardin's music at the Stonehill Inn with no notable reactions.
- **1/2 Taraksh:** Used a recovered magical bullet to knock a blocking ogre prone on the road to Gnomengarde.

## Current Status
- **Last Known Location:** Sword Mountains, road to Gnomengarde — in active combat with an ogre
- **Active:** Mid-combat; resourceful (used recovered ammunition tactically)
- **Known to Party:** Converting drow cleric, still adapting to Lathander's ethics; combat-capable but inconsistent offensively
- **Hidden:** Full depth of her instincts toward plunder and violence; how sincere vs. performative her religious deference actually is

## Relationships
- **Vukardin:** Primary reason she joined the party; felt mysteriously compelled toward him. Finds his moral lectures eye-roll-worthy but follows his lead on quest selection.
- **Soma:** Harbors no apparent grudge for being knocked unconscious by the miscast ice knife, though her delighted reaction to it was unsettling to Soma.
- **Dazlyn & Norbus (gnomes):** Privately considers them grave robbers.
- **Linene Graywind:** Brief social interaction; Valphine was casually open about enjoying her near-death experience.
- **Harbin Wester (Townmaster):** Transactional; verified his quest payments. Silently amused by Vukardin's lecture to him.

## Arc Score Events
*(No arc score events recorded in source notes.)*
