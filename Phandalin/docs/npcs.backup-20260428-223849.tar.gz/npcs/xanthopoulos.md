---
name: Xanthopoulos
aliases: []
source_extracts: [39]
---

# Xanthopoulos

## Identity
- Centaur elder or emissary; unaffiliated with any druid faction
- First appeared at the druid council, arriving unexpectedly

## Personality & Motivations
- Deliberate in the way of very old creatures — considered, unhurried, precise. He carries no banner and aligns with no faction, positioning himself as a neutral observer and truth-teller. He has watched both pure interventionism and pure naturalism become follies when held too tightly, and seems motivated by a desire to report what is real rather than to advocate. He commands quiet authority and speaks plainly.

## History with the Party
- **Druid Council session:** Arrived unexpectedly and immediately recognized Meril's Staff in Soma's possession. Told the council he understood the significance of Meril choosing Soma — "He did not give it for sentiment. He gave it because he… picked her." His recognition of the staff visibly affected Soma.
- Delivered critical intelligence to the council: **Corbin is dead**, and **Sister Kayla has walked out and disappeared** ("gone to the wind").
- Stated clearly to the council that he represents neither faction — only reporting what his people witnessed.
- Upon departing, told Soma quietly: "Perhaps Meril made the right choice." Soma took this remark to heart and kept it carefully.

## Current Status
- **Last known:** Departing the druid council after delivering his news
- **Active plans:** Unknown; he came to report, not to join
- **Party knowledge vs. hidden:** The party knows he recognized the staff, knew Meril personally, and has a network of "his people" who observe events. His deeper history with Meril, the full extent of his knowledge, and the nature of his people remain unknown.

## Relationships
- **Meril:** Knew him well enough to recognize his staff on sight and understand the weight of his choices. Speaks of Meril with respect and familiarity.
- **Soma:** Regards her with cautious approval. His parting words suggest he sees potential in her that aligns with Meril's judgment. Soma found his recognition deeply meaningful.
- **Druid council factions:** Explicitly neutral. Neither interventionist nor naturalist — a deliberate outsider.
- **"His people":** References a group (presumably centaurs) who serve as witnesses and observers of events, including Corbin's death and Kayla's departure.
- **Corbin / Sister Kayla:** Knew of them; reported Corbin's death and Kayla's disappearance as factual intelligence.

## Arc Score Events
- No explicit arc score changes noted.
