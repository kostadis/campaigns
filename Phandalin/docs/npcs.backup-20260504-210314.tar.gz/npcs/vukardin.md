---
name: Vukardin
aliases: []
source_extracts: [1, 2]
---

# Vukardin

## Identity
- **Role:** Aasimar Bard, avant-garde musician; recruited adventurer operating in the Phandalin hinterlands under Lord Neverember's vanguard program
- **Faction:** Loosely aligned with Neverember's initiative, though deeply skeptical of it
- **First Appearance:** Performing unpaid at the First Flophouse in Heapside, Neverwinter; recruited by a Wintershield watchman on 8/3 of Ches, 1495; formally joined the party on 1/1 of Taraksh

## Personality & Motivations
- **Core Goals:** Earn honest coin, gain recognition for his original music, and avoid participating in what he views as state-sanctioned banditry
- Moralistic and argumentative — he pushed back on Neverember's scheme at every stage before accepting out of financial desperation, and harangued the townmaster publicly after collecting a legitimate quest reward
- Conflict-averse in combat, twice attempting to parley with orcs and once with an ogre, each time with disastrous results
- Genuinely passionate about music; negotiates lodging and payment through performance, plays original compositions for anyone who will listen, and was persuaded to accept sending stones partly for their musical utility

## History with the Party

**Pre-Campaign (8/3 of Ches, 1495)**
Recruited by a Wintershield watchman while performing for no pay at the First Flophouse. Objected strenuously to Neverember's adventurer vanguard scheme on moral grounds; accepted only because he was broke.

**1/1 of Taraksh**
Quit the flophouse, recruited Brewbarry, and accepted Valphine into the group. Declared the party's goal would be earning honest coin.

**8/1 of Taraksh — Phandalin Arrival**
Negotiated free meals at the Stonehill Inn by playing crowd-pleasing songs; earned a free beer and an audience for one original composition. Received warning about a white dragon from Toblen Stonehill. Selected the Dwarven Excavation Quest at the townmaster's hall for its 50 gp payout, overriding Valphine's preference for Gnomengarde on ethical grounds.

**9/1 of Taraksh — Dwarven Ruin**
Warned the dwarves Dazlyn and Norbus about the white dragon and attempted to leave; convinced to stay when offered sending stones as payment (partly on Valphine's argument about musical uses). Inside the temple, attempted to parley with orcs twice, was knocked unconscious both times, and was revived by Valphine both times. Used Starry Wisp offensively once. Played original compositions for Dazlyn and Norbus that evening.

**10/1 of Taraksh — Return to Phandalin**
Attempted to speak with a whistling ogre on the road, assuming it might be a musician or enslaved; was immediately charged. Cast Starry Wisp to illuminate it and hid while the party killed it. Collected the 50 gp quest reward from Townmaster Harbin Wester, then publicly accused adventurers of being glorified thugs, upsetting Wester. Attempted to solicit a protection contract from Linene Graywind at the Lionshield Coster — unsuccessful. Played popular music again at the Stonehill Inn at Toblen's urging.

**1/2 of Taraksh — Road to Gnomengarde**
Attempted to intimidate an ogre blocking the mountain path; failed and accidentally convinced it the party was easy prey. Combat initiated.

## Current Status
- **Last Known Location:** Sword Mountains, road to Gnomengarde
- **Active Situation:** Mid-combat with an ogre that Vukardin inadvertently provoked through a failed intimidation attempt
- **What the Party Knows:** His goals, his moral objections to the Neverember arrangement, his musical ambitions
- **What Remains Hidden:** Nothing significant surfaced yet — his motivations and history have been relatively transparent

## Relationships
- **Valphine:** Party member; she twice revived him after he was knocked unconscious, and she helped persuade him to stay at the dwarven ruin. She advocated for the Gnomengarde quest over his choice.
- **Brewbarry:** Recruited by Vukardin on 1/1 of Taraksh; no further interaction detailed
- **Toblen Stonehill:** Friendly patron; repeatedly convinces Vukardin to shelve his originals in favor of crowd-pleasing sets, rewarding him with food, drink, and goodwill
- **Dazlyn & Norbus:** Paid him in sending stones; received an original performance from him
- **Townmaster Harbin Wester:** Relationship damaged — Vukardin publicly berated adventurers to his face after collecting a reward
- **Linene Graywind (Lionshield Coster):** Rebuffed his unsolicited protection pitch; no relationship established
- **Lord Neverember:** Vukardin's nominal patron; Vukardin accepted his terms under duress and remains morally opposed to the arrangement

## Arc Score Events
*(None recorded in source notes)*
