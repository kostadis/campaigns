---
name: Valphine
aliases: []
source_extracts: [3, 4, 5, 19]
---

# Valphine

## Identity
- **Role:** Cleric of Lathander (surface convert, Drow origin)
- **Faction:** Party member; nominally aligned with Lathander's clergy
- **First Appearance:** Battle on the mountain path, morning of 02-01 Taraskh 1495; joined the party against the ogre

## Personality & Motivations
- **Core Goals:** Serving Lathander while navigating the tension between her Underdark instincts and her adopted faith; acquiring resources and influence through the party
- Pragmatic and calculating — she reads people like gamblers and exploits social dynamics with visible pleasure (turning Pog and Ulla against each other, comparing Vukradin's political maneuvering to "good Drow practice")
- Her Underdark instincts — hunting, dominance, sacrifice, the thrill of killing — surface regularly and she is consciously managing them against Lathander's expectations
- Holds contempt for inefficiency and weakness in others, though she respects competence wherever she finds it

## History with the Party

**Mountain Path (02-01 Taraskh 1495)**
Participated in the ogre fight; missed a mace strike on a prone ogre and was mocked by Soma for it. Hit the fleeing ogre with a crossbow bolt. Looted the body, recovering a whistle, coins, and a key.

**Gnomengarde**
Declined to climb the cliff without a rope (required Soma to rig one). Did not engage the entry negotiations with guards Pog and Ulla. Inside, identified herself as a cleric to inventors Fibblestib and Dabbledob, who dismissed her. Privately concluded she could not cure King Korboz and that the party lacked the funds to try anyway. On hearing of missing gnomes Warren and Orrin, she instinctively favored torture as a remedy for the king's madness — finding herself aligned with Brewbarry before Vukradin redirected the group to music.

When confronting guards Pog and Ulla near the barrel room, she deliberately weaponized Ulla's own words to turn the two gnomes on each other in mutual paranoid accusation. She found this amusing.

In the cellar, she triggered the mimic by pointing her crossbow at a barrel, provoking its transformation. She called out the discovery, positioned herself clear of Soma's Ice Knife, and quoted a childhood rhyme after watching Vukradin's verbal attacks visibly wound the creature.

**Dual Monarchy (post-Gnomengarde)**
Observed Vukradin's political destabilization of the gnome kings with amusement, comparing his technique to Drow practice. Inserted herself once to suggest the kings needed "a clear approver structure," drawing on experience watching commune-style cultures collapse into betrayal.

**Umbrage Hill Approach**
Annoyed at the 25-gold rate for rescuing Adabra. Spotted a shadow behind a boulder during the approach; suppressed the instinct, reminding herself she was not in the Dark Realms. Struck by a crossbow bolt during a bandit ambush; coolly returned fire, shooting a fleeing bandit in the back to enable Vukradin's kill.

**Manticore Fight at Umbrage Hill**
Fired the opening shot against the manticore; hit but dealt minimal damage. Took a full volley of tail spikes when the creature singled her out. Missed a second shot later. Internally noted the manticore's offer to take Corbin in exchange for the rest — reflected it was "a fair trade" she would have considered in a different life. Observed Vukradin's uncertainty in combat with the eye of someone who reads gamblers. When Adabra emerged, immediately offered to teach her about Lathander. Attributed the quality of Adabra's food to Lathander's glory.

**Orc Scout Ambush (return to Phandalin)**
Led the march; first to spot the poorly concealed orc scout. Remarked that orcs make fine slaves. Fired multiple crossbow shots during the battle, missing several before landing a hit. Expressed open contempt for Soma's Moonbeam, comparing it unfavorably to Lathander's searing light. Noted the fleeing orc appeared to recognize her as a Drow worshipping Lathander and panicked at the sight. Pursued him into the forest but lost him — surface terrain gave him equal visibility. Returned to interrogate the captured orc (with the necklace) alongside Brewbarry; upon hearing his account of Talos-worshipping orc cultists, asserted dominance by declaring he now worked for the party.

## Current Status
- **Last Known Location:** Returning to Phandalin from Umbrage Hill
- **Active Concerns:** Orc cultists of Talos operating in the region; the orc scout who fled having recognized her as a Drow cleric of Lathander
- **What the Party Knows:** She is a Drow cleric of Lathander; she is competent, ruthless, and tactically cold
- **What Remains Hidden:** The depth of her internal conflict between Underdark instincts and Lathander's doctrine; her private calculation that sacrificing Corbin to the manticore would have been "a fair trade"; the full weight of what she is adjusting away from

## Relationships
- **Soma:** Friction — Soma mocked her early miss; she holds contempt for the Moonbeam spell and has compared it unfavorably to Lathander's power
- **Vukradin:** Mutual respect — she admires his political manipulation, comparing it to Drow technique; she reads his combat uncertainty but has not challenged him on it
- **Brewbarry:** Instinctive alignment — both reached for torture first at Gnomengarde; they partnered in interrogating the captured orc
- **Corbin:** Privately assessed as expendable (manticore exchange); no overt conflict noted
- **Adabra:** Immediate missionary impulse — offered to teach her about Lathander upon first meeting

## Arc Score Events
- *(No arc score system referenced in source notes — no entries recorded)*
