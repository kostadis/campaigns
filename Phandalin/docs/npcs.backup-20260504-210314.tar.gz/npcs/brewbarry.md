---
name: Brewbarry
aliases: []
source_extracts: [3, 4, 10, 19]
---

# Brewbarry

## Identity
- **Role:** Adventuring companion; former Uthgardt Barbarian
- **Faction:** None current; formerly Uthgardt (estranged/exiled)
- **First Appearance:** Fought alongside the party against an ogre; has traveled with them since

## Personality & Motivations
- **Core Goals:** Unclear beyond immediate companionship with the party; appears driven by a personal rejection of Uthgardt cruelty and a desire to find something better
- **Personality:** Loud, physical, and direct — he announces himself boldly and leads with his halberd. Beneath the bluster is genuine empathy, particularly for those hurt by the Uthgardts. He is capable of surprising compassion mid-combat and deescalates instinctively when he recognizes shared suffering. He takes small ownership instincts seriously (the cart, the prisoner) and has a dry, oblivious comic streak.

## History with the Party

**Ogre Fight (Early Sessions)**
Brewbarry fought the ogre alongside the party. He absorbed a full axe blow without harm through barbarian rage, which spooked the ogre enough to trigger its retreat. He pursued but couldn't land the killing blow — Vukradin finished it.

**Gnomengarde Entry**
Announced himself as "Brewbarry, killer of Ogres" to prove he wasn't a shapeshifter. When gnomes identified him as Uthgardt, his clarification that he *used to be* one inadvertently resolved a bureaucratic loophole in the gnomes' standing attack order, allowing the party entry.

**Inventors' Workshop / Mimic Fight**
Shut down any implied suggestion of torture from Valphine with "We talk! We cure!" Charged the mimic in the cellar, wounded it but got his halberd stuck. Struggled to free it throughout the fight; eventually produced handaxes after prompting from Vukradin.

**Bandit Ambush**
Decapitated a bandit with his halberd, emerged covered in blood, then chased the fleeing spider-phobic bandit. Instead of killing him, he dropped his weapon and offered: *"I am so sorry that the Uthgardts hurt you. They were mean to me, too."* The gesture disarmed the bandit emotionally.

**Stonehill Tavern (Phandalin)**
Helped defuse tension over the ambush accusation by reminding Vukradin of the patrons' goodwill. Participated in a betting pool on party survival (with a side bet on whether Vukradin would be ditched or killed). Joined a musical session, using his halberd percussively in Uthgardt tribal style — the performance earned the group extra coin.

**Supply Cart Ambush / Orc Prisoner**
Pulled the supply cart for Tribar Wester; refused to let anyone else touch it after the Falcon Hunter filled it with alcohol. Stumbled through the woods during the ambush and gave away the party's position. Snapped a thrown javelin in two bare-handed. Became enraged when the orc attacked Valphine and swung wide to defend her (missed). Called the orc "shrimp," baffling the creature. After the battle, took charge of the prisoner — named him "Shrimpy," bound his hands to the cart, and made him pull it. Was briefly moved by the orc's lament about clan exile, which echoed his own.

## Current Status
- **Last Known Location:** Phandalin, most recently seen at the Stonehill Tavern; traveling with the party toward Tribar Wester
- **Active:** Transporting the supply cart; managing prisoner "Shrimpy"
- **Party Knows:** Former Uthgardt, exiled or estranged; has personal trauma connected to the clan
- **Hidden:** Full circumstances of his exile remain unspoken

## Relationships
- **Vukradin:** Companionable; prompted Brewbarry to switch weapons during the mimic fight; Brewbarry backed him socially at the tavern. Subject of a side bet regarding his survival.
- **Valphine:** Some tension — Brewbarry cut off her implied torture suggestion. He also moved to defend her instinctively when the orc attacked her, despite missing.
- **"Shrimpy" (orc prisoner):** Self-appointed captor and namer. Relationship complicated by personal identification with the orc's exile.
- **Uthgardt Barbarians:** Estranged. Source of personal pain; he recognizes the harm they've caused others and has publicly distanced himself from them twice.

## Arc Score Events
- *(No arc score changes recorded in source notes)*
