---
name: Vukradin
aliases: []
source_extracts: [3, 4, 5, 22]
---

# Vukradin

## Identity
- **Role/Title:** Bard; aspiring theatrical producer and studio founder
- **Faction:** Loosely affiliated with the Emerald Enclave (used as a persuasive framing device); acquainted with the Church of Lathander
- **First Appearance:** Present from early sessions; first notable independent action was the killing blow on the fleeing ogre at Gnomengarde's entrance

## Personality & Motivations
- **Core Goals:** Fund and construct a personal studio; stage a revival of a legendary Triboar play featuring a demon named Bob; accumulate wealth through what he considers ethical means ("organic, conflict-free, fair-trade gold")
- Vukradin is intellectually combative — he dismantles arguments, drives wedges in negotiations, and rarely lets a flawed premise go unchallenged. He is capable of genuine charm but deploys it with visible calculation.
- He holds strong aesthetic and moral opinions: he objects to looting monsters, insists on returning stolen property to rightful owners, and takes personal offense when his "poetic license" is dismissed.
- His bravado in combat frequently outpaces his spellcasting reliability, and he covers failed magic with confident declarations and verbal aggression.

## History with the Party

**Gnomengarde**
- Killed a fleeing ogre, justifying it on moral grounds to Soma. Looted and identified mushrooms from entrance pools (red oily — unclear use; green — flour; purple — fermentable into wine). Found nothing behind the waterfall despite insisting on checking.
- Negotiated entry past guards Pog and Ulla using logical argument and music; reported the blade room as a death trap to Ulla, who revealed a northern alternate route.
- Chose to disable Facktore's automatic crossbow device rather than kill the gnome inventor.
- Explained the party's dragon-fighting mission to inventors Fibblestib and Dabbledob; proposed music therapy for King Korboz's madness and prompted Fibblestib to offer to build a modified piano.
- Negotiated with co-King Gnercli for a hat of wizardry in exchange for eliminating the shapeshifter; objected to the reward's limited utility against a dragon but accepted after Soma reframed the terms.
- Dismantled the logic of the dual monarchy through pointed questioning, successfully driving a wedge between Korboz and Gnercli — with Korboz erupting that he deserved preferential treatment as senior king. Collected the hat amid an enraged Gnercli's dismissal.
- During the mimic fight, used verbal invective laced with enchantment that visibly caused the mimic to flinch. Mid-combat, engaged Soma in a philosophical debate about naturalist druidism, Aasimar, and Tieflings.
- After the fight, questioned Soma's decision to take gold from the chests, citing his own wealth via sending stones.

**Travel and Bandit Ambush**
- Pushed to negotiate higher pay than 25 gold for the Adabra rescue mission, explicitly citing studio funding; was overruled.
- Was briefly paralyzed during the bandit ambush, then killed a fleeing bandit at Valphine's prompting.
- Invited a surrendered bandit to dinner to extract information about their boss, the Carver.
- Reminded Soma that a druidic scroll taken from the bandits should be returned to its rightful owner.
- Expressed strong desire to travel to Triboar to find the script for the legendary play featuring demon character Bob.

**Umbrage Hill**
- Interrogated Corbin on first meeting, recognizing stolen armor from a dead man; commanded Corbin to remove it before relenting and promising to find him fair-trade armor.
- Led the group toward Adabra's windmill quietly. Attempted twice to negotiate with and then magically affect the manticore — both spell attempts failed. Briefly blamed Soma for encouraging his second attempt.
- After Brewbarry killed the manticore, Vukradin severed its head and presented it to Adabra as proof.
- Repeatedly interrogated Adabra about whether Corbin had robbed her; challenged her claimed ownership of the dwarven house.
- Attempted to persuade Adabra to return to Phandalin via music — she praised the performance but her resolve was unchanged.
- Ultimately secured Adabra's agreement by framing the mission as a joint undertaking by fellow members of the Emerald Enclave.
- His explicit motivation throughout: funding his studio with ethically sourced gold.

**Woodland Manse**
- Reunited with Falcon, who was visibly relieved to see him safe.
- Recounted Teega's rescue with moderate success; took a gentle approach with Teega, offering her a position with the Church of Lathander.
- Persuaded Falcon to provide free lodging for the entire party by invoking their future business partnership.

## Current Status
- **Last Known Location:** Woodland Manse clearing, mid-combat
- **Active Plans:** Secure studio funding; locate the Triboar play script; find Corbin proper armor; pursue information on the Carver gathered from the surrendered bandit
- **What the Party Knows:** He wants gold for a studio, has ethical restrictions on how he acquires it, owns sending stones, and has a contact/business partner in Falcon
- **Hidden from the Party:** The full scope of his sending stone network and what business arrangements with Falcon actually entail

## Relationships
- **Soma:** Frequent philosophical sparring partner; tension over naturalist druidism, the nature of Aasimar/Tieflings, looting ethics, and poetic license. Complicated but engaged dynamic
- **Falcon:** Established prior relationship; Falcon was noticeably relieved at Vukradin's safety. Business partnership framing used to extract free lodging
- **Corbin:** Wary; recognized stolen armor immediately and moralized at Corbin, but softened and made a promise to help him
- **Adabra:** Interrogated her over property ownership and Corbin; used Emerald Enclave framing to secure her cooperation despite failed musical persuasion
- **Teega:** Gentle; offered her a Lathander church position
- **Valphine:** Acted on her prompting during the bandit ambush (killed the fleeing bandit at her signal)
- **Brewbarry:** Benefited from Brewbarry killing the manticore Vukradin could not affect magically
- **The Carver:** Knows the name; gathering information

## Arc Score Events
- *(No arc score changes explicitly noted in source material)*
