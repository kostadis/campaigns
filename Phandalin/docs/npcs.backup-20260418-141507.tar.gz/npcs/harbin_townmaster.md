---
name: Harbin (Townmaster)
aliases: []
---

# Harbin (Townmaster)

## Identity
- Townmaster of Phandalin
- Operates under the authority of Lord Neverember
- Appears to serve as the local administrator handling bounties and civic matters

## Personality & Motivations
- Cowardly and easily intimidated — cowered at the party's approach and mistook Vukradin for a dragon. Avoids confrontation but will hold firm on financial matters until sufficiently pressured. Defers to Lord Neverember's authority and wishes as his primary justification for decisions, using the lord's name as a shield against demands.

## History with the Party
1. **Bounty Dispute:** The party returned to collect payment from Harbin, who resisted paying beyond the original agreement. He cited Lord Neverember's arrangement that adventurers claim monster treasure as their compensation. Under intense pressure from Adabra, he relented and offered free room and board at the Stonehill Inn instead of coin, blaming bandit activity for his lack of funds.
2. **Lighthouse Discussion:** The following morning, Vukradin intercepted Harbin in the street before he reached his office. Vukradin pressed him about destroying a cursed lighthouse. Harbin dismissed the rumors of evil but was firm that Lord Neverember would want the curse removed rather than the structure destroyed. He directed the party to find Ser Kaelen at Barthen's Provisions before Kaelen left town.

## Current Status
- **Location:** Phandalin, conducting his duties as Townmaster
- **Active concerns:** Bandit activity affecting the town's finances; the cursed lighthouse situation
- **Party knowledge:** The party knows he is stingy, cowardly, and deferential to Lord Neverember. They know he won't sanction destroying the lighthouse. They have been directed to Ser Kaelen regarding the lighthouse matter.

## Relationships
- **Lord Neverember:** Harbin's superior and the authority he constantly invokes to justify his decisions
- **Adabra:** She was able to pressure him into concessions; he appears to buckle under her fury
- **Vukradin:** Harbin is visibly afraid of him (mistook him for a dragon)
- **Ser Kaelen:** Someone Harbin knows and directed the party toward; apparently connected to the lighthouse situation, located at Barthen's Provisions
- **Stonehill Inn:** Harbin has enough pull to arrange free room and board there for the party
