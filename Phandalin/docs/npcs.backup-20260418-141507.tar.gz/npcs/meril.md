---
name: Meril
aliases: []
---

# Meril

## Identity
- Druid teacher / mentor to Soma
- Has not appeared directly in sessions; known only through Soma's references

## Personality & Motivations
- Core goals and drives are unknown; motivations for sending Soma away prematurely remain unexplained.
- Implied to be deliberate and enigmatic — gave Soma a staff of significant power without explanation, and cut short a druidic education that typically spans decades after only one year.

## History with the Party
- **Referenced in conversation (not present):** Soma spoke about Meril as her druid teacher. Soma trained under Meril for only one year — extraordinarily brief for druidic training that normally takes decades. Meril gave Soma her staff before sending her out, but never explained why Soma was being sent away or what the staff truly was. Soma described Meril's hands as being "in the grain" of the staff, suggesting a deep personal or magical connection Meril imbued into it. The staff now has fewer leaves than it once did, a detail Soma has noticed but not yet understood.

## Current Status
- **Last known location:** Unknown. Soma did not mention where Meril is or whether she can be reached.
- **Active plans:** Unknown.
- **Party knowledge vs. hidden:** The party knows Meril is Soma's teacher and gave her the staff. The reasons behind Soma's abbreviated training, the true nature of the staff, and Meril's current whereabouts all remain mysteries. Soma herself believes the staff's significance is something she needs to work out on her own.

## Relationships
- **Soma:** Mentor-student relationship. Soma holds deep reverence for Meril and treats the staff as her last physical connection to her teacher. There is an undercurrent of unresolved questions — why the short training, why the staff, why now.

## Arc Score Events
No direct arc score events recorded.
