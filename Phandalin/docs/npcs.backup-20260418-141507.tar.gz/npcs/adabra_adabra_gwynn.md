---
name: Adabra (Adabra Gwynn)
aliases: []
---

# Adabra Gwynn

## Identity
- Druid; connected to broader druidic circles in the region
- Has not appeared directly in session; known through secondhand reports (primarily via Ser Kaelen)

## Personality & Motivations
- Core goal: Hold the party accountable for what she sees as reckless interventionism that has harmed the forests, particularly events at the Whispering Grove (involving a treant and a concealment).
- She experienced the consequences of the party's wartime actions but not the planar incursions that provoked them, leading her to identify the defenders as the problem rather than the actual threats. Kaelen described her as "confused" in this regard. Soma characterized her actions as "bringing her own war out here."

## History with the Party
- **Prior interaction with Soma:** Adabra had a conversation with Soma at some earlier point. During it, she looked at Soma with an expression meaning "you understand" — Soma let her believe that without correcting her. Soma now feels uneasy about this tacit deception.
- **Discovery of the Whispering Grove truth:** Adabra learned what really happened at the Whispering Grove, including the treant incident and the concealment. This catalyzed her decision to act against the party.
- **Rallying druids:** She began gathering druidic allies and is organizing a conclave to argue that the party's actions have brought harm to the forests.

## Current Status
- **Last known location:** Somewhere in the wilds, rallying support among druids.
- **Active plans:** Convening a druid gathering/conclave to make the case against the party's "reckless interventionism." Some attendees have suggested that Soma's right to retain Meril's staff should be evaluated at this conclave.
- **Known vs. hidden:** The party knows her general intent and that she is gathering allies. Her specific location, the full list of her supporters, and the exact arguments she plans to present remain unknown.

## Relationships
- **Soma:** A complicated dynamic. Soma allowed Adabra to believe they shared a mutual understanding, which was not fully genuine. Soma now views Adabra's campaign as adversarial — "bringing her own war."
- **Ser Kaelen:** Kaelen is the party's source of information about Adabra's movements. He views her as "confused" — sympathetic to her pain but dismissive of her conclusions.
- **Druidic circles:** Actively recruiting allies among druids; has enough credibility to convene a gathering and put the party's actions (and Soma's possession of Meril's staff) on the agenda.

## Arc Score Events
- Adabra's discovery of the Whispering Grove truth and her decision to rally druids against the party represent a clear escalation — likely an arc score increase toward conflict with druidic factions.
