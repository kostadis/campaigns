---
name: Toblen Stonehill (Spiderman)
aliases: []
---

# Toblen "Spiderman" Stonehill

## Identity
- Tavern keeper of the Stonehill Inn
- First encountered when Vukradin approached him about performing music at the inn

## Personality & Motivations
- Sociable and open—willing to share personal stories with newcomers. His calm demeanor is reflected in the childhood anecdote that earned him his nickname: he walked out of a hatching spider's nest covered in baby spiders without panicking.

## History with the Party
- **Initial meeting:** Vukradin approached Toblen about performing music at the Stonehill Inn. Toblen shared the story behind his nickname "Spiderman."
- **Ser Kaelen's recruitment:** Toblen served drinks to the party while Ser Kaelen held a recruitment conversation at the inn.

## Current Status
- **Location:** Stonehill Inn, operating as usual
- **Activity:** Running the tavern; no known plans or schemes beyond daily business
- **Party knowledge:** The party knows his nickname origin and has had casual, friendly interactions with him

## Relationships
- **Vukradin:** Friendly rapport; Vukradin initiated contact about performing music
- **Ser Kaelen:** Hosted Kaelen's recruitment meeting at the inn (nature of personal relationship unclear)
- **The Party (general):** Hospitable; served them drinks and shared stories
