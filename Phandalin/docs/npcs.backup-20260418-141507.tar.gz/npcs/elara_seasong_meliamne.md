---
name: Elara 'Seasong' Meliamne
aliases: []
---

# Elara 'Seasong' Meliamne

## Identity
- Located in Neverwinter
- Appears to possess the ability to unlock or identify magical loot
- Has not yet appeared directly in play

## Personality & Motivations
- No direct interactions recorded yet; personality and motivations unknown.

## History with the Party
- The party has not yet met Elara in person. She was discussed as a contact the party plans to visit in Neverwinter, with Vukradin specifically advocating to seek her out in order to unlock or identify some of the party's acquired loot.

## Current Status
- **Last known location:** Neverwinter
- **Active plans:** The party intends to travel to Neverwinter and seek her services
- **What the party knows:** She can apparently help unlock or identify their loot; beyond this, no further details are established
- **What remains hidden:** Virtually everything — no direct interaction has occurred yet

## Relationships
- **Vukradin:** Championed seeking her out; may have prior knowledge of her or her reputation
- **Rest of party:** Aware of her as a destination contact in Neverwinter

## Arc Score Events
None recorded.
