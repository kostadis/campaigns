# New notes for Soma (from dossier_extract_043.md)

Soma appeared throughout the session, providing tactical assessment, dark humor, and practical support.

During the planning discussion, when Vukradin announced he refused to act without an apology from Falcon, Soma's response was immediate: "The Falcon? Yeah, fuck that guy." She offered a fallback option — clear the lodge infestation without protecting it — framing it as a way out if the apology didn't come. She provided direction for Vukradin's Sending by implying Falcon would likely apologize.

At the lodge, Soma settled Boney near the stables on arrival: "Here you go, Boney. Chill out here." She observed Vorga's calculating look moving between Valphine and Prutha and said nothing, waiting. During the evacuation debate, she offered to carry refugees herself: "And you can ride the elk, I can carry a couple." She waited through Vorga's third iteration of "Creature will catch up" until Vukradin heard it. She noted she hadn't expected Gorthok until the summoning was complete, in a tone implying the party had created the problem by choosing the lodge over the manse. She described the grouped enemy positions as "Convenience."

During the storm's arrival, Soma's staff sprouted a new leaf. She held it up and commented: "Guys, it's sprouting!" and then: "It means an angel got its wings, don't worry." She confirmed to Vukradin that she had nothing to resist lightning. Last seen positioned in the courtyard as the gate was destroyed and Gorthok's forces began the assault.

---
