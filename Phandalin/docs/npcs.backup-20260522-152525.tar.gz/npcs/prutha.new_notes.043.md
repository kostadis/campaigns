# New notes for Prutha (from dossier_extract_043.md)

Prutha appeared in both the equipment discussion and the lodge arrival.

During the shield discussion, Prutha watched the exchange with the expression he gets when adults are doing something confusing. He enthusiastically suggested: "Valphine, use good shield! Valphine, cleric of sun!" He was rebuffed by both Valphine and Vukradin. When he protested, Vukradin looked at him directly and said "Not yours either." Prutha went quiet.

At the lodge, Prutha moved before anyone else spoke. He had been watching the banners and identified them aloud: "Eastern Heart! Three banners on the wall! I see one! Sun and Stone! My uncle's clan march! They are family!" He walked deliberately to the gate with hands open, brought his right fist to his left shoulder, lowered his head in formal greeting, drew the bone whistle from inside his armor, and blew the dawn prayer. The sentry returned the gesture, lowered her bow, and called down to open the gate. He exchanged verbal recognition with her before the invitation was extended to the whole party. The sentry's invitation — "Bring your drow, bring your Aasimar, bring all of them. We are listening" — framed him as the entry point: *your drow*, *your Aasimar*, possessive to Prutha.

Prutha provided intelligence on the lodge from orc songs: the orcs had taken it, there were dogs, and he knew of three factions — former tribe, Talosian-aligned, and independent. He confirmed the Anchorites had moved their own people through. A recovered note mentioned a boy from the East described as a good recruit, which Soma observed while looking at Prutha, though she said nothing aloud. Vukradin also noted this detail without acting on it.

During the pre-siege period, Prutha was standing quietly, having apparently learned that stillness is safer than motion. Last known position: inside the palisade as the siege began.

---
