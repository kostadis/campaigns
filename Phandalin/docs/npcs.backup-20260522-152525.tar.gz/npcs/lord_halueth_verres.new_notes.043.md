# New notes for lord_halueth_verres (from dossier_extract_043.md)

Lord Halueth Verres does not appear in this chunk. He was referenced by Vukradin during the planning discussion as a rhetorical model for the tone Vukradin wanted to strike in his Sending to Falcon. Vukradin described the story: during Verres's confirmation hearing for elevation to Lord Magister of Neverwinter, a war-mage from Waterdeep testified against him on matters involving an artifact and a contract with apprentices. Verres received the seat anyway. Ten years later, Lady Verres contacted the war-mage on a Sending to ask whether she was finally ready to apologize to her husband for what she said at his confirmation. The war-mage actually replied. Vukradin used this story to identify the register he wanted — "Lady Verres on a Sending" — meaning indignant, as if doing the recipient a favor by asking at all. No further information about Verres or his current status was provided.

---
