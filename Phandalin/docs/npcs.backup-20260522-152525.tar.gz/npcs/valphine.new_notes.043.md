# New notes for Valphine (from dossier_extract_043.md)

Valphine appeared throughout the session as a tactician, theologian, and social mediator.

During the shield examination, Valphine tilted her head with suppressed interest, then reached out and wiggled the Talosian bolt free — it had been stuck on crookedly from the start and came loose immediately. She turned the shield over, examined the newer leather straps smelling of pine tar and wet dog, and found the half-orc tally on the inside rim. When Vukradin declared the shield not theirs, she confirmed: "Done." She deflected Prutha's suggestion she use it — "You can use my shield" — and when Vukradin overrode that offer too, she stated without warmth: "It's not mine. Be sure." She tucked the shield under her arm to hold until the owner turned up. She added to the halberd cover story: "And it looks a little waterlogged."

Valphine then spoke at length about Lathander. Her argument: people misunderstand what light is. It burns twelve hours a day, hurts everything at full strength, and people worship it because the alternative is worse — worship of power in plain sight, unashamed, causing harm constantly, called good because the dark is worse. This provoked Vukradin's observation about the cleric changing the god rather than the reverse.

Valphine had done background groundwork with Falcon in advance — Vukradin felt the apology was ready when it came, and attributed it to her preparation. She added context to Vukradin's Sending, suggesting he clarify that the party was considering clearing the lodge.

She reviewed the Talosian documents alongside Vukradin, sorted the two scenarios regarding the lodge attack (Talosian and then destroyed by the party, or not Talosian and yielding intel), and suggested approaching the lodge from the south. She recommended obscuring mist or darkness as a counter to lightning targeting.

At the lodge, Valphine opened negotiations in Orcish with Vorga and the elder. She answered the elder's single word — *Dawn* — with: "Yes. I'm the bringer of the dawn. A painful dawn." She let him see her holy symbol clearly. She relayed in Common that the clan came from the southern mountains and had been told about the nearby Talosian threat. She flagged to Vukradin that Falcon's hunter cloak on Vorga's back was "not worthy" of pressing on — not a trophy but a practical garment — and Vukradin agreed. She cast a defensive working on the party during the pre-siege lull, described as bracing rather than healing, making bodies harder to drop. She positioned three orc archers at the gatehouse arrow slits, noting the fantastically defensible positions there.

During the storm's arrival, Valphine's staff sprouted a new leaf, which she noted with dry humor: "Guys, it's sprouting!" and "It means an angel got its wings, don't worry." Last seen with the party in the courtyard as the gate came apart and Gorthok's forces moved through.

---
