# New notes for Brewbarry (from dossier_extract_043.md)

Brewbarry appeared throughout the session across multiple scenes at Falcon's Hunting Lodge and the approach to it. He is the narrator of the first and third sections, providing a first-person account of events.

During the post-battle equipment discussion, Brewbarry examined the recovered shield — dark oak with iron bands, druidic carvings, and a Talosian bolt nailed crookedly over the face. He supported Vukradin's position that the shield was not theirs to keep, agreeing it belonged to whoever had left the half-orc tally (four notches and a slash) carved on the inside rim. When the group turned attention to his new halberd taken from the shipwreck, he deflected with the line "I got a divorce" and allowed Vukradin to supply the cover story that it was his original halberd, recently sharpened. He said nothing further and let the matter close.

Brewbarry listened to Valphine's theology of Lathander — the argument that light is power rather than tenderness, that it burns and harms and is worshipped out of fear of the dark. He reflected on this privately in terms of his own Uthgardt relationship to Talos, noting he was sober when found guilty, which was a long time ago. He did not share these thoughts aloud.

At the lodge, Brewbarry discovered a broken cask whose contents — alcohol — had soaked into the floor planks and been wasted rather than consumed. He emerged from the lodge interior screaming, announced "I will kill them all!" to the courtyard, and was talked down by Vukradin, who promised more alcohol would be found. Brewbarry accepted this reluctantly.

During the siege, Brewbarry observed the storm arrive wrongly — sudden darkness, panicking boars, and lightning strikes inside the compound. He received a defensive working from Valphine that he felt as an extra layer of protection. He checked his grip on the Dragon Slayer, noted his Dread Helm's red-glow effect, and positioned for combat. When Vukradin revealed Gorthok was already present among the attacking forces, Brewbarry's response was direct: *They are savages. We kill them all.* He had his sword in hand when the gate was destroyed by a directed lightning bolt and the Talosian forces began their assault.

Brewbarry reflected privately on Uthgardt stories of the Great Boar — a thing conjured from storm and lightning, older than the gods claiming to own it — and concluded that you probably don't stop something like that. You just get in front of it.

---
